"""Create a dedicated Python/R environment without machine-specific paths."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
from tempfile import TemporaryDirectory
from urllib.parse import quote, urldefrag, urlsplit
from miniforge_runtime import (APPLICATION, MARKER_NAME, PYTHON_VERSION, find_miniforge,
                               package_from_forge, prefix_conda, prefix_python)
from certificate_trust import certificate_bundle, certificate_environment, check_python_https

ROOT = Path(__file__).resolve().parent
USER_DATA = Path(os.environ.get('LOCALAPPDATA', str(Path.home()/'AppData/Local'))) if os.name=='nt' else Path.home()/'.local/share'
DEFAULT_PREFIX = USER_DATA/'BlueFood/environments'/hashlib.sha256(str(ROOT).encode()).hexdigest()[:10]
CONDA_TOOL_PINS = {'setuptools==80.9.0', 'wheel==0.45.1'}
WINDOWS_TORCH = 'torch==2.2.2+cpu'
TORCH_WHEEL_HOSTS = ('download-r2.pytorch.org', 'download.pytorch.org')

def process_env(prefix):
    env = os.environ.copy()
    folders = [prefix, prefix / 'Scripts', prefix / 'Library/bin', prefix / 'bin']
    env['PATH'] = os.pathsep.join(str(p) for p in folders if p.exists()) + os.pathsep + env.get('PATH', '')
    env.pop('PYTHONPATH',None)
    env.pop('PYTHONHOME', None)
    env.update(PYTHONUTF8='1', PYTHONNOUSERSITE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
    return env

def run(command, dry=False, env=None):
    print(' '.join(json.dumps(str(c)) if ' ' in str(c) else str(c) for c in command), flush=True)
    if not dry:
        subprocess.run([str(c) for c in command], check=True, cwd=ROOT, env=env)


def verify_package(path, expected, algorithm):
    digest = hashlib.new(algorithm)
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    if digest.hexdigest() != expected:
        raise ValueError(f'Package checksum mismatch: {path}')


def offline_conda_entries(lock, archives):
    entries = []
    for line in lock.read_text(encoding='ascii').splitlines():
        if not line or line.startswith('#') or line == '@EXPLICIT':
            continue
        url, digest = urldefrag(line)
        url_parts = urlsplit(url)
        name = Path(url_parts.path).name
        if (url_parts.scheme != 'https' or url_parts.netloc != 'conda.anaconda.org' or
                not re.fullmatch(r'/conda-forge/(win-64|noarch)/[\w.+-]+(?:\.conda|\.tar\.bz2)', url_parts.path) or
                not re.fullmatch(r'[a-f0-9]{32}', digest)):
            raise ValueError(f'Unexpected package entry in the Windows Conda lock: {line}')
        direct = archives / name
        nested = archives / 'https' / url_parts.netloc / url_parts.path.lstrip('/')
        package = direct if direct.is_file() else nested
        if not package.is_file():
            raise FileNotFoundError(f'Missing locked Conda archive: {name}')
        verify_package(package, digest, 'md5')
        entries.append(f'{package.as_uri()}#{digest}')
    if not entries:
        raise ValueError('The Windows Conda lock lists no packages')
    return ['@EXPLICIT', *entries]


def offline_pip_entries(lock, wheelhouse):
    records = json.loads((ROOT/'windows-offline-wheel-hashes.json').read_bytes())
    pins = set()
    for line in lock.read_text(encoding='ascii').splitlines():
        if line and not line.startswith('#'):
            name, version = line.split('==')
            pins.add(re.sub(r'[-_.]+', '-', name).lower() + '==' + version)
    if set(records) != pins - CONDA_TOOL_PINS or not CONDA_TOOL_PINS <= pins:
        raise ValueError('The offline wheel hashes do not cover the Windows requirements lock')
    entries = []
    for requirement, (name, digest) in sorted(records.items()):
        if not re.fullmatch(r'[\w.+-]+\.whl', name) or not re.fullmatch(r'[a-f0-9]{64}', digest):
            raise ValueError(f'Invalid offline wheel record: {requirement}')
        path = wheelhouse / name
        if not path.is_file():
            raise FileNotFoundError(f'Missing locked Python wheel: {name}')
        verify_package(path, digest, 'sha256')
        entries.append(f'{requirement} --hash=sha256:{digest}')
    return entries


def run_offline_conda(command, entries, dry, env):
    if dry:
        run(command + ['--file', '<verified-local-conda-lock>'], True, env)
        return
    with TemporaryDirectory(prefix='bf-') as temp:
        lock = Path(temp) / 'local-explicit.txt'
        lock.write_text('\n'.join(entries) + '\n', encoding='ascii')
        env = {**env, 'CONDA_PKGS_DIRS': str(Path(temp) / 'p')}
        run(command + ['--file', lock], False, env)


def run_offline_pip(python, wheelhouse, entries, dry, env):
    verify_tools = ('import importlib.metadata as m,sys; '
                    'assert all(m.version(n)==v for n,v in (p.split("==") for p in sys.argv[1:])), '
                    '"Conda Python tools differ from the locked versions"')
    run([python, '-I', '-c', verify_tools, *sorted(CONDA_TOOL_PINS)], dry, env)
    command = [python, '-I', '-m', 'pip', '--isolated', '--disable-pip-version-check', 'install',
               '--no-index', '--no-deps', '--force-reinstall', '--no-cache-dir', '--find-links', wheelhouse, '--require-hashes']
    if dry:
        run(command + ['--requirement', '<verified-local-wheel-lock>'], True, env)
        return
    with TemporaryDirectory(prefix='bf-') as temp:
        lock = Path(temp) / 'wheel-requirements.txt'
        lock.write_text('\n'.join(entries) + '\n', encoding='ascii')
        run(command + ['--requirement', lock], False, env)


def install_windows_torch(python, dry, env):
    records = json.loads((ROOT / 'windows-offline-wheel-hashes.json').read_bytes())
    name, digest = records[WINDOWS_TORCH]
    wheel = ROOT / 'offline-wheels' / name
    command = [python, '-m', 'pip', '--disable-pip-version-check', 'install',
               '--no-index', '--no-deps', '--require-hashes', '--retries', '1', '--timeout', '30']
    if wheel.exists():
        verify_package(wheel, digest, 'sha256')
        print(f'Using verified local PyTorch wheel: {wheel}', flush=True)
        run(command + [f'{wheel.as_uri()}#sha256={digest}'], dry, env)
        return

    for host in TORCH_WHEEL_HOSTS:
        url = f'https://{host}/whl/cpu/{quote(name)}#sha256={digest}'
        try:
            run(command + [url], dry, env)
            return
        except subprocess.CalledProcessError:
            print(f'PyTorch installation from {host} did not complete.', file=sys.stderr, flush=True)
    raise RuntimeError(
        f'Could not install the locked CPU PyTorch wheel from either official host. '
        f'Copy {name} to {wheel.parent} and rerun Setup Environment. '
        'For a fully offline Python package installation, use -Wheelhouse.'
    )


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--conda', help='Conda executable in the Miniforge installation, if it is not detected automatically')
    p.add_argument('--prefix', type=Path, help='Dedicated environment folder; an earlier managed selection is reused')
    p.add_argument('--rscript', help='Optional existing native Rscript; otherwise R is installed in the dedicated environment')
    p.add_argument('--conda-archives', type=Path, help='Windows: directory of Conda archives matching the explicit lock')
    p.add_argument('--wheelhouse', type=Path, help='Windows: directory of wheels matching the released SHA-256 inventory')
    p.add_argument('--ca-bundle', type=Path, help='Trusted PEM certificate bundle, including any organization CA')
    p.add_argument('--check-online', action='store_true', help='Also verify HTTPS to PyPI and CRAN')
    p.add_argument('--dry-run', action='store_true')
    args = p.parse_args()
    config_path = Path(os.environ.get('BLUEFOOD_CONFIG', ROOT/'bluefood.json')).expanduser()
    if not config_path.is_absolute():
        config_path = ROOT/config_path
    config = json.loads(config_path.read_text(encoding='utf-8-sig')) if config_path.exists() else {}
    if args.prefix is None:
        previous = Path(config['python']) if config.get('python') else None
        if previous and not previous.is_absolute():
            previous = ROOT/previous
        previous_prefix = previous.parent if previous and os.name=='nt' else previous.parent.parent if previous else None
        args.prefix = previous_prefix if previous_prefix and (previous_prefix/MARKER_NAME).exists() else DEFAULT_PREFIX
    if not args.rscript and config.get('rscript'):
        args.rscript = str(config['rscript'])
    prefix = args.prefix.expanduser().resolve()
    if prefix in (ROOT, Path.home().resolve(), Path(sys.prefix).resolve()):
        raise ValueError('Choose a dedicated environment folder, separate from the source and your existing Python')
    if platform.machine().lower() not in ('amd64', 'x86_64'):
        raise RuntimeError('This preserved Python 3.9 package set targets Windows/Linux x64 and Intel macOS. Apple Silicon/ARM needs a separately validated package set or an x64 environment.')
    python = prefix_python(prefix)
    marker = prefix / MARKER_NAME
    transaction = prefix.with_name(prefix.name + '.bluefood-setup.json')
    ownership = json.loads(transaction.read_text()) if transaction.exists() else {}
    owned = ownership.get('application') == APPLICATION and ownership.get('prefix') == str(prefix)
    if prefix.exists() and any(prefix.iterdir()) and not marker.exists() and not owned:
        raise FileExistsError('The selected environment folder already contains unrelated files. Choose a new --prefix; setup preserves existing environments.')
    miniforge = find_miniforge(args.conda, config.get('miniforge_root'))
    if Path(sys.executable).resolve() != prefix_python(miniforge).resolve():
        raise ValueError('Run Setup Environment using the selected Miniforge installation Python.')
    conda = prefix_conda(miniforge)
    custom_bundle = args.ca_bundle or config.get('ca_bundle')
    base_bundle, bases = certificate_bundle(miniforge, custom_bundle)
    print(f'Miniforge CA bundle verified ({bases} CA certificates): {base_bundle}', flush=True)
    conda_env = certificate_environment(process_env(miniforge), base_bundle)
    if args.check_online and not args.dry_run:
        check_python_https(base_bundle)
    packages = [f'python={PYTHON_VERSION}', 'pip', 'ca-certificates', 'openssl', 'curl']
    if not args.rscript:
        packages += ['r-base=4.5.2', 'r-desolve', 'r-openxlsx', 'r-jsonlite']
    explicit = ROOT/'environment-win64-explicit.txt'
    windows_lock = os.name=='nt' and not args.rscript and explicit.exists()
    if (args.conda_archives or args.wheelhouse) and not windows_lock:
        raise ValueError('Local archives and wheels require the Windows x64 lock with its bundled R packages')
    lock = ROOT/'requirements-lock-win64.txt'
    conda_entries = offline_conda_entries(explicit, args.conda_archives.expanduser().resolve()) if args.conda_archives else None
    wheelhouse = args.wheelhouse.expanduser().resolve() if args.wheelhouse else None
    wheel_entries = offline_pip_entries(lock, wheelhouse) if wheelhouse else None
    if windows_lock:
        packages = ['--file', str(explicit)]
    if not args.dry_run:
        prefix.parent.mkdir(parents=True, exist_ok=True)
        transaction.write_text(json.dumps({'application': APPLICATION, 'prefix': str(prefix)}, indent=2), encoding='utf-8')
    conda_action = 'install' if (prefix / 'conda-meta').is_dir() else 'create'
    repair = (['--force-reinstall'] if conda_action == 'install'
              and (not python.is_file() or python.stat().st_size == 0) else [])
    if conda_entries:
        run_offline_conda([conda, conda_action, '--yes', '--offline', '--copy', '--prefix', prefix, *repair],
                          conda_entries, args.dry_run, conda_env)
    else:
        run([conda, conda_action, '--yes', '--prefix', prefix, *repair,
             '--override-channels', '--channel', 'conda-forge', '--strict-channel-priority'] + packages, args.dry_run, conda_env)
    env = process_env(prefix)
    if not args.dry_run:
        if (not python.is_file() or python.stat().st_size == 0
                or not package_from_forge(prefix, 'python', PYTHON_VERSION)):
            raise ValueError(f'Miniforge did not install a complete Python {PYTHON_VERSION} executable at {python}. Rerun Setup Environment to repair it.')
        bundle, count = certificate_bundle(prefix, custom_bundle)
        print(f'BlueFood CA bundle verified ({count} CA certificates): {bundle}', flush=True)
        certificate_environment(env, bundle)
        if custom_bundle:
            env['BLUEFOOD_CA_BUNDLE'] = str(bundle)
        run([python, '-E', '-s', '-c',
             'import ssl, sys; actual = ".".join(map(str, sys.version_info[:3])); '
             'assert actual == sys.argv[1], actual; '
             'assert ssl.create_default_context(cafile=sys.argv[2]).cert_store_stats()["x509_ca"] > 0',
             PYTHON_VERSION, bundle], env=env)
    if args.rscript:
        env['BLUEFOOD_RSCRIPT'] = args.rscript
    if wheel_entries:
        run_offline_pip(python, wheelhouse, wheel_entries, args.dry_run, env)
    else:
        run([python, '-m', 'pip', 'install', 'pip==24.3.1'], args.dry_run, env)
        locked_windows_requirements = os.name == 'nt' and lock.is_file()
        if locked_windows_requirements:
            install_windows_torch(python, args.dry_run, env)
        else:
            torch = [python, '-m', 'pip', 'install', 'torch==2.2.2']
            if sys.platform != 'darwin':
                torch += ['--index-url', 'https://download.pytorch.org/whl/cpu']
            run(torch, args.dry_run, env)
        requirements = lock if locked_windows_requirements else ROOT/'requirements.txt'
        run([python, '-m', 'pip', 'install', '--requirement', requirements], args.dry_run, env)
    run([python, '-m', 'pip', 'check'], args.dry_run, env)
    r_check = [python, ROOT / 'check_install.py']
    if not conda_entries:
        r_check.append('--install-r-packages')
    if args.check_online:
        r_check.append('--check-online')
    run(r_check, args.dry_run, env)
    if args.dry_run:
        print('Dry run only: no environment, package or configuration was changed.')
        return
    marker.write_text(json.dumps({'application': APPLICATION, 'python': PYTHON_VERSION, 'created_by': 'bootstrap.py',
                                  'miniforge_root': str(miniforge)}, indent=2), encoding='utf-8')
    transaction.unlink()
    config['miniforge_root'] = str(miniforge)
    if custom_bundle:
        config['ca_bundle'] = str(base_bundle)
    try:
        config['python'] = python.relative_to(ROOT).as_posix()
    except ValueError:
        config['python'] = str(python)
    if args.rscript:
        config['rscript'] = args.rscript
    config_path.parent.mkdir(parents=True,exist_ok=True)
    config_path.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding='utf-8')
    print('Setup complete. Run Start Pipeline.cmd (Windows) or ./start_pipeline.sh (Linux/macOS).')

if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        print('Setup could not complete: ' + str(error), file=sys.stderr)
        sys.exit(1)

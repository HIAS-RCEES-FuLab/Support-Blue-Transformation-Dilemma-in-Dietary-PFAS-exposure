"""Adapters for the supplied Zenodo CausalForestDML health programs."""
from pathlib import Path
import ast,concurrent.futures,contextlib,hashlib,json,os,random,sys,time,functools
import numpy as np
import pandas as pd
import joblib
from common import *
PUB=ASSETS/'health/published'
DATA=ASSETS/'health/published_data'
OUTCOME_MANIFEST=read_json(ASSETS/'health/health_outcomes.json')
OUTCOMES=OUTCOME_MANIFEST['outcomes']
OUTCOME_INFO={item['code']:item for item in OUTCOME_MANIFEST['health_outcomes']}
DERIVED={'C_AGR','C_LDL','C_THR','C_LHR','C_BCR'}
def data_path(outcome):
 return DATA/('data_outcome diseases.xlsx' if outcome in SELECTED else 'data_outcome indicators derived local.xlsx')
LABELS={'PFOS':'LBXPFOS','PFOA':'LBXPFOA','PFHxS':'LBXPFHS','PFNA':'LBXPFNA','PFDA':'LBXPFDE','PFUnDA':'LBXPFUA','PFDoDA':'LBXPFDO'}
SELECTED={
 'BPQ020':['DMDMARTL','HUQ030','HUQ010','DMDCITZN','SMAQUEX','LBXHA','LBXPFOS','HSD010','BPACSZ','DR2TCRYP'],
 'MCQ160A':['DMDMARTL','HUQ010','HUQ030','DR1TNUMF','DR2TTFAT','DR1TVB2','PFQ051','SMAQUEX','IMQ020','WTDR2D','DR2TS060','LBDSIRSI','DR1TVB1','LBXPFHS','LBXPFNA','LBXPFOA','LBXPFOS']}
def source_for(outcome):
 source=PUB/('DMLOrthoForest ('+outcome+' NN-causalforest).py' if outcome in SELECTED else 'DMLOrthoForest (reg).py')
 if not source.is_file():raise FileNotFoundError('Health model source is missing for '+outcome+': '+str(source))
 return source
@functools.lru_cache(maxsize=4)
def clinical_frame(binary,sheet):
 source=DATA/('data_outcome diseases.xlsx' if binary else 'data_outcome indicators derived local.xlsx')
 with pd.ExcelFile(source) as book:
  if binary and sheet not in book.sheet_names:raise ValueError('Missing cleaned disease cohort sheet: '+str(sheet))
  frame=pd.read_excel(book,sheet_name=sheet if sheet in book.sheet_names else book.sheet_names[0])
 if not binary:
  targets=[code for code in OUTCOMES if code not in SELECTED]
  missing=[code for code in targets if code not in frame]
  if missing:raise ValueError('Cleaned health cohort is missing indicators: '+', '.join(missing))
  if len(frame)!=7618 or not np.isfinite(frame[targets].to_numpy(float)).all():raise ValueError('Expected 7,618 cleaned participants with finite health indicators')
 return frame
def load_data(outcome):
 binary=outcome in SELECTED
 source=data_path(outcome)
 # All 34 indicators use the supplied cleaned cohort; each disease keeps its own cleaned sheet.
 frame=clinical_frame(binary,outcome if binary else None)
 if outcome not in frame:raise ValueError('Health outcome column is missing: '+outcome)
 tags={}
 with (DATA/('tag diseases.csv' if binary else 'tag indicators.csv')).open(encoding='utf-8-sig',newline='') as f:
  import csv
  for row in csv.reader(f):
   if len(row)>=2:tags.setdefault(row[0],[]).append(row[1])
 return frame,tags,source
class PortableCalls(ast.NodeTransformer):
 def visit_Expr(self,node):
  if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr in {'to_excel','show','savefig'}:return None
  return self.generic_visit(node)
def load_program(outcome):
 sys.path.insert(0,str(PUB))
 tree=ast.parse(source_for(outcome).read_text(encoding='utf-8-sig'))
 tree.body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Import,ast.ImportFrom))]
 tree=PortableCalls().visit(tree);ast.fix_missing_locations(tree)
 ns={'__name__':'pipeline_health_source','__file__':str(source_for(outcome))}
 exec(compile(tree,str(source_for(outcome)),'exec'),ns)
 if outcome in SELECTED:
  cls=ns['NeuralRandomForestRegressor']
  if not hasattr(cls,'_pipeline_original_predict'):
   cls._pipeline_original_predict=cls.predict
   def deterministic_predict(self,values):
    self.eval();return self._pipeline_original_predict(values)
   cls.predict=deterministic_predict
 sys.path.pop(0)
 return ns
def model_path(outcome):
 neural=(sha(PUB/('test_NN_clssification_F_'+outcome+'.py'))+sha(PUB/('NNTree_'+outcome+'.pth'))) if outcome in SELECTED else ''
 derived='source-cleaned-cohort-v3' if outcome not in SELECTED else ''
 fingerprint=hashlib.sha256((sha(source_for(outcome))+sha(data_path(outcome))+neural+derived+'deterministic-eval-v1'+json.dumps(environment_signature(),sort_keys=True)).encode()).hexdigest()[:12]
 return CACHE/'health_models'/(outcome+'_'+fingerprint+'.joblib')
def training_columns(outcome,frame,tags,ns):
 x=[t for t in tags['covariate'] if t in frame];w=[t for t in tags.get('instrumental',[]) if t in frame]
 t=[LABELS[c] for c in ['PFOS','PFOA','PFHxS','PFNA','PFDA','PFDoDA','PFUnDA'] if LABELS[c] in frame]
 if outcome in SELECTED:
  x=[c for c in x if c in SELECTED[outcome]];w=[c for c in w if c in SELECTED[outcome]];t=[c for c in tags['treatment'] if c in frame and c in SELECTED[outcome]]
 else:
  correlation_frame=frame[t+[outcome]].replace([np.inf,-np.inf],np.nan).dropna()
  if len(correlation_frame)<3:raise ValueError('Insufficient finite observations for '+outcome)
  t=ns['filter_T'](t,[outcome],correlation_frame)
 if not x or not t:raise ValueError('Missing training features for '+outcome)
 return x,t,w
def train_one(outcome):
 if outcome not in OUTCOMES:raise ValueError('Outcome is outside the validated health-outcome manifest')
 dest=model_path(outcome);dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists() and read_json(dest.with_suffix('.json'),{}).get('sha256')==sha(dest):return {'outcome':outcome,'cached':True}
 seed=int.from_bytes(hashlib.sha256(outcome.encode()).digest()[:4],'little');random.seed(seed);np.random.seed(seed)
 frame,tags,data_source=load_data(outcome);ns=load_program(outcome);x,t,w=training_columns(outcome,frame,tags,ns)
 keep=np.isfinite(frame[list(dict.fromkeys(x+t+w+[outcome]))].to_numpy(dtype=float)).all(axis=1)
 if outcome in SELECTED:keep&=frame[outcome].isin([1,2]).to_numpy()
 selected=frame.loc[keep]
 X=selected[x].to_numpy(np.float32);T=selected[t].to_numpy(np.float32);W=selected[w].to_numpy(np.float32) if w else None
 Y=selected[[outcome]].to_numpy(float)
 logpath=dest.with_suffix('.log')
 with logpath.open('w',encoding='utf-8',buffering=1) as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
  print('SOURCE',source_for(outcome),'ROWS',len(selected),'X',x,'T',t,'W',w,flush=True)
  if outcome in SELECTED:
   import torch
   torch.set_num_threads(1);torch.manual_seed(seed)
   # Keep the supplied neural training/loss unchanged; prediction uses eval mode.
   model=ns['prepare_DML'](X,(2-Y[:,0]).astype(int),T,W)
   if hasattr(model,'random_state'):model.random_state=seed
   model.n_jobs=1;model.fit(X=X,T=T,Y=(2-Y[:,0]).astype(int),W=W,inference='blb')
  else:
   model,r2_test,r2_train=ns['prepare_DML'](X,Y,T,W)
   if hasattr(model,'random_state'):model.random_state=seed
   model.n_jobs=1;model.fit(X=X,T=T,Y=Y,W=W,inference='blb')
  bundle={'model':model,'outcome':outcome,'X':x,'T':t,'W':w,'rows':np.flatnonzero(keep),'training_seed':seed,'source_sha256':sha(source_for(outcome))}
  joblib.dump(bundle,dest,compress=3)
 write_json(dest.with_suffix('.json'),{'sha256':sha(dest),'outcome':outcome,'patients':len(selected),'rows_excluded':int((~keep).sum()),'selected_treatments':t,'source':str(source_for(outcome)),'data_source':str(data_source),'data_sha256':sha(data_source),'seed':seed,'NN_loss_unchanged':True,'NN_inference_eval_mode':True})
 return {'outcome':outcome,'cached':False,'patients':len(selected)}
def load_cached_model(outcome):
 path=model_path(outcome)
 if not path.is_file():raise FileNotFoundError('Health model is missing for '+outcome+'; rerun the health workflow to prepare it')
 return joblib.load(path)
def verify_pretrained():
 import torch,importlib
 sys.path.insert(0,str(PUB));checks=[]
 for outcome in SELECTED:
  mod=importlib.import_module('test_NN_clssification_F_'+outcome)
  for name in ['NRFRegressionTreeNode','NeuralRandomForestRegressor','CustomLoss']:
   setattr(sys.modules['__main__'],name,getattr(mod,name))
  p=PUB/('NNTree_'+outcome+'.pth');net=torch.load(p,map_location='cpu')
  frame,_,_=load_data(outcome);x=frame[SELECTED[outcome]].iloc[:16].to_numpy(np.float32)
  if hasattr(net,'model'):net.model.eval()
  prediction=np.asarray(net.predict_proba(x))
  if prediction.shape!=(16,2) or not np.isfinite(prediction).all():raise ValueError('Pretrained NN inference failed: '+outcome)
  checks.append({'outcome':outcome,'model_sha256':sha(p),'tested_patients':16,'prediction_shape':list(prediction.shape)})
 sys.path.pop(0);return checks
def plot_health_summary(out,baseline_out=None):
 import matplotlib.pyplot as plt
 s=pd.read_csv(Path(out)/'regional_world_health_outcomes.csv')
 if baseline_out is not None:
  from future_health_view import plot_future_health_summary
  plot_future_health_summary(out,s,OUTCOME_INFO,OUTCOMES)
  return
 d=pd.read_csv(Path(out)/'country_health_outcomes.csv')
 world=s[s.region=='World'].pivot_table(index='outcome',columns='scenario',values='mean_effect_vs_near_zero')
 labels={'2020_trade':'2020\nTrade','2050_LL_trade':'LR\nTrade','2050_LL_Metatrade':'LR\nMetatrade',
         '2050_BAU_trade':'BAU\nTrade','2050_BAU_Metatrade':'BAU\nMetatrade','2050_HL_trade':'HR\nTrade','2050_HL_Metatrade':'HR\nMetatrade'}
 order=[c for c in labels if c in world.columns]
 import textwrap
 nrows=(len(OUTCOMES)+2)//3
 fig,axes=plt.subplots(nrows,3,figsize=(15,2.8*nrows),squeeze=False)
 for ax,outcome in zip(axes.flat,OUTCOMES):
  values=world.loc[outcome,order]
  ax.bar(range(len(order)),values.to_numpy(),color=['#168b83' if 'Metatrade' not in c else '#bb9657' for c in order],width=.65)
  ax.axhline(0,color='#777',linewidth=.6)
  ax.set_xticks(range(len(order)),[labels[c] for c in order],fontsize=7)
  unit=d.loc[d.outcome==outcome,'unit'].iloc[0]
  ax.set_title(textwrap.fill(OUTCOME_INFO[outcome]['display_name'],40),loc='left',fontsize=10)
  ax.set_ylabel(unit,fontsize=7);ax.tick_params(axis='y',labelsize=8)
 for ax in list(axes.flat)[len(OUTCOMES):]:ax.set_visible(False)
 fig.suptitle('34 health indicators and two disease outcomes · population-weighted differences\n2020 Trade versus near-zero serum · separate outcome scales',fontsize=13)
 fig.tight_layout(rect=(0,0,1,.975),h_pad=2,w_pad=2)
 # Keep the reserved title area when exporting this taller, 36-panel figure.
 for suffix in ['png','pdf']:fig.savefig(Path(out)/('health_outcomes.'+suffix),bbox_inches='tight')
 plt.close(fig)

def run_health(out,opt,exposure_out,baseline_out=None):
 from calculations import serum_arrays,serum_model,geography
 event(out,'Preparing 34 health-indicator models and two disease-outcome models')
 write_json(out/'pretrained_NN_checks.json',verify_pretrained())
 with concurrent.futures.ProcessPoolExecutor(max_workers=opt['workers']) as pool:
  tasks={pool.submit(train_one,o):o for o in OUTCOMES}
  for i,f in enumerate(concurrent.futures.as_completed(tasks)):
   result=f.result();event(out,'Health model ready · '+OUTCOME_INFO[result['outcome']]['display_name'],(i+1)/len(tasks))
 manifests=[(Path(exposure_out),r) for r in read_json(Path(exposure_out)/'individual_manifest.json') if r['scenario']!='2020_notrade']
 baselines={}
 if baseline_out:
  for r in read_json(Path(baseline_out)/'individual_manifest.json'):
   if r['scenario']=='2020_trade':baselines[r['replicate'],r['country']]=Path(baseline_out)/r['file']
 mapping=serum_model();geo=geography();rows=[];acceleration=[]
 for outcome in OUTCOMES:
  ns=load_program(outcome)
  bundle=load_cached_model(outcome);model=bundle['model'];frame,tags,_=load_data(outcome);frame=frame.iloc[bundle['rows']]
  X=frame[bundle['X']].to_numpy(np.float32);ranks={c:frame[LABELS[c]].rank(method='first').to_numpy()/len(frame) for c in LABELS if LABELS[c] in frame}
  treatment_names=bundle['T'];observed=frame[treatment_names].to_numpy(np.float32)
  if getattr(model,'treatment_featurizer',None) is not None:raise ValueError('Fast projection requires the supplied linear-treatment model')
  started=time.monotonic();theta=np.concatenate([np.asarray(model.const_marginal_effect(X[lo:lo+opt['health_batch']])).reshape(min(opt['health_batch'],len(X)-lo),-1) for lo in range(0,len(X),opt['health_batch'])])
  if theta.shape!=observed.shape:raise ValueError('Unexpected CATE coefficient dimensions')
  coefficient_seconds=time.monotonic()-started;maximum_error=0.;reference_calls=0
  def map_t(arrays,record):
   values=observed.copy()
   for chemical,distribution in arrays.items():
    label=LABELS[chemical]
    if label in treatment_names:
     # Preserve source resampling and rank matching, with a recorded common seed.
     token=f'{outcome}|{record["country"]}|{record["replicate"]}|{chemical}'
     seed=int.from_bytes(hashlib.sha256(token.encode()).digest()[:4],'little')
     sampled=np.random.RandomState(seed).choice(distribution,len(frame));sampled.sort()
     order=np.argsort(frame[label].to_numpy(),kind='quicksort')
     values[order,treatment_names.index(label)]=sampled
   return values
  for i,(folder,r) in enumerate(manifests):
   cancelled(out);arrays=serum_arrays(folder/r['file'],mapping);T=map_t(arrays,r)
   ground=1e-12 if outcome in SELECTED else 0.;zero=np.full_like(T,ground)
   baseline=map_t(serum_arrays(baselines[r['replicate'],r['country']],mapping),r) if baselines else None
   # Same estimator effect: theta(X) dot (T1-T0), with no treatment featurizer.
   values=np.einsum('ij,ij->i',theta,T-zero)
   changes=np.einsum('ij,ij->i',theta,T-baseline) if baseline is not None else None
   sample=np.unique(np.linspace(0,len(X)-1,min(32,len(X)),dtype=int))
   direct=np.asarray(model.effect(X=X[sample],T0=zero[sample],T1=T[sample])).reshape(-1)
   np.testing.assert_allclose(values[sample],direct,rtol=1e-10,atol=1e-12)
   maximum_error=max(maximum_error,float(np.max(np.abs(values[sample]-direct))));reference_calls+=1
   if baseline is not None:
    direct=np.asarray(model.effect(X=X[sample],T0=baseline[sample],T1=T[sample])).reshape(-1)
    np.testing.assert_allclose(changes[sample],direct,rtol=1e-10,atol=1e-12)
    maximum_error=max(maximum_error,float(np.max(np.abs(changes[sample]-direct))));reference_calls+=1
   year=r['scenario'][:4];population=geo[r['country']][year]
   row={'outcome':outcome,'outcome_name':OUTCOME_INFO[outcome]['display_name'],'outcome_category':OUTCOME_INFO[outcome]['category'],'scenario':r['scenario'],'replicate':r['replicate'],'country':r['country'],'region':geo[r['country']]['region'],'population':population,
    'mean_effect_vs_near_zero':float(values.mean()),'individual_effect_p05':float(np.quantile(values,.05)),'individual_effect_p95':float(np.quantile(values,.95)),
    'mean_change_from_2020':float(np.mean(changes)) if changes is not None else None,'patients':len(X),'unit':OUTCOME_INFO[outcome]['unit'],
    'binary_effects_outside_minus1_plus1':int((np.abs(values)>1).sum()) if outcome in SELECTED else 0,
    'unmapped_treatments_kept_at_NHANES':';'.join(t for t in treatment_names if t not in [LABELS[c] for c in arrays])}
   if baseline_out is None:
    row.update(fraction_increase=float(np.mean(values>0)),
      fraction_decrease=float(np.mean(values<0)), fraction_unchanged=float(np.mean(values==0)))
   rows.append(row)
  acceleration.append({'outcome':outcome,'coefficient_seconds':coefficient_seconds,'reference_effect_calls':reference_calls,'reference_patients_per_call':32,'max_absolute_difference':maximum_error})
  pd.DataFrame(rows).to_csv(out/'country_health_outcomes.csv',index=False);write_json(out/'HEALTH_ACCELERATION_VERIFICATION.json',acceleration);event(out,'Health projections complete · '+OUTCOME_INFO[outcome]['display_name'])
 d=pd.DataFrame(rows);summary=[]
 for (outcome,scenario,rep,region),g in pd.concat([d,d.assign(region='World')]).groupby(['outcome','scenario','replicate','region']):
  summary.append({'outcome':outcome,'outcome_name':OUTCOME_INFO[outcome]['display_name'],'outcome_category':OUTCOME_INFO[outcome]['category'],'unit':OUTCOME_INFO[outcome]['unit'],'scenario':scenario,'replicate':rep,'region':region,'mean_effect_vs_near_zero':float(np.average(g.mean_effect_vs_near_zero,weights=g.population)),
   'mean_change_from_2020':float(np.average(g.mean_change_from_2020,weights=g.population)) if g.mean_change_from_2020.notna().all() else None,'population_covered':float(g.population.sum()),'countries_covered':len(g)})
  if baseline_out is None:
   for field in ['fraction_increase','fraction_decrease','fraction_unchanged']:
    summary[-1][field]=float(np.average(g[field],weights=g.population))
 s=pd.DataFrame(summary);s.to_csv(out/'regional_world_health_outcomes.csv',index=False)
 if baseline_out is None:
  from health_result_views import write_population_shift
  write_population_shift(out, s, OUTCOME_INFO, OUTCOMES)
 plot_health_summary(out,baseline_out)
 write_json(out/'health_method.json',{'outcomes':OUTCOMES,'health_outcomes':OUTCOME_MANIFEST['health_outcomes'],'selection':OUTCOME_MANIFEST['selection'],'source':'Supplied Zenodo double machine learning/program','CausalForest_models_fitted_then_cached':True,
  'pretrained_neural_weights_verified':True,'neural_training_loss_unchanged':True,'deterministic_eval_at_prediction':True,
  'effect':'Difference relative to near-zero serum, and direct paired future-versus-2020 treatment contrast',
  'future_plot_percent_change':'100 × the mean paired change divided by the absolute matched 2020 Trade effect against near-zero serum, aggregated with the same 2050 population weights and then averaged across replicates. Undefined for zero baselines.',
  'summary':'Untrimmed country means, then exact year-specific population weights','intervals':'Individual effect quantiles are heterogeneity, not confidence intervals',
  'binary_violations':'Counted and exported; never silently clipped','missing_treatments':'Preserved at reference NHANES serum as in the supplied preparation method',
  'continuous_cohort':{'participants_before_cleanup':9026,'participants_after_cleanup':7618,'source':'data_outcome indicators derived local.xlsx'},
  'disease_cohorts':{'BPQ020':8587,'MCQ160A':8749,'source':'Outcome-specific cleaned sheets in data_outcome diseases.xlsx'},
  'derived_indicators':{'C_AGR':'LBXSAL / LBXSGB','C_LDL':'LBXSCH / 18 - LBDHDDSI','C_THR':'(LBXSCH / 18) / LBDHDDSI','C_LHR':'C_LDL / LBDHDDSI','C_BCR':'1000 * LBDSBUSI / LBDSCRSI','validation':'All formulas reproduce the 7618 local source values within floating-point tolerance; source cholesterol-derived indexes are retained without clinical unit reinterpretation'}})

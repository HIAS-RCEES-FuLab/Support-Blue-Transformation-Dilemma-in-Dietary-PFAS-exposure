"""Render the packaged diet and trade inputs as a self-contained HTML result."""

from pathlib import Path
import json

import numpy as np
import pandas as pd


PATHWAYS = ("2020", "LR", "BAU", "HR")
TRADE_FILES = {
    "Trade": "consump_trade matrix.xlsx",
    "Metatrade": "consump_trade matrix 2050.xlsx",
}
FOOD_SHEETS = {"aquatic": "Water", "terrestrial": "Terri"}
COUNTRY_CODES = {
    "Argentina": "ARG", "Australia": "AUS", "Austria": "AUT", "Belgium": "BEL",
    "Brazil": "BRA", "Bulgaria": "BGR", "Canada": "CAN", "Chile": "CHL", "China": "CHN",
    "Colombia": "COL", "Costa Rica": "CRI", "Croatia": "HRV", "Czechia": "CZE",
    "Denmark": "DNK", "Estonia": "EST", "Finland": "FIN", "France": "FRA", "Germany": "DEU",
    "Greece": "GRC", "Hungary": "HUN", "Iceland": "ISL", "India": "IND", "Indonesia": "IDN",
    "Ireland": "IRL", "Israel": "ISR", "Italy": "ITA", "Japan": "JPN", "Korea": "KOR",
    "Latvia": "LVA", "Lithuania": "LTU", "Luxembourg": "LUX", "Mexico": "MEX",
    "Netherlands": "NLD", "New Zealand": "NZL", "Norway": "NOR", "Poland": "POL",
    "Portugal": "PRT", "Romania": "ROU", "Slovak Republic": "SVK", "Slovenia": "SVN",
    "South Africa": "ZAF", "Spain": "ESP", "Sweden": "SWE", "Switzerland": "CHE",
    "Turkiye": "TUR", "United Kingdom": "GBR", "United States": "USA",
}


def supply_shares(input_dir, countries):
    result = {}
    for mode, filename in TRADE_FILES.items():
        workbook = pd.read_excel(input_dir / filename, sheet_name=list(FOOD_SHEETS.values()), index_col=0)
        result[mode] = {}
        for food, sheet in FOOD_SHEETS.items():
            matrix = workbook[sheet]
            if (matrix.index.has_duplicates or matrix.columns.has_duplicates
                    or set(matrix.index) != countries or set(matrix.columns) != countries):
                raise ValueError(f"{filename}, {sheet}: unexpected trade country coverage")
            values = matrix.to_numpy(dtype=float)
            if (not np.isfinite(values).all() or (values < 0).any()
                    or not np.allclose(values.sum(axis=0), 1.0, rtol=0.0, atol=1e-8)):
                raise ValueError(f"{filename}, {sheet}: supply shares must be nonnegative and sum to one by importer")
            destinations = {}
            for country in sorted(countries):
                column = matrix[country]
                domestic = float(column.loc[country])
                exporters = [
                    [COUNTRY_CODES[exporter], float(share)]
                    for exporter, share in column.drop(country).nlargest(5).items()
                    if share > 0
                ]
                destinations[COUNTRY_CODES[country]] = {"domestic": domestic, "exporters": exporters}
            result[mode][food] = destinations
    return result


def consumption_amounts(diets, geography, land_foods):
    result = {}
    countries = set(geography)
    land = set(land_foods)
    for pathway in PATHWAYS:
        year = "2020" if pathway == "2020" else "2050"
        diet = diets[pathway]
        if diet.index.has_duplicates or set(diet.index) != countries or not land < set(diet.columns):
            raise ValueError(f"{pathway}: unexpected diet coverage")
        groups = {"terrestrial": sorted(land), "aquatic": sorted(set(diet.columns) - land)}
        result[pathway] = {}
        for group, categories in groups.items():
            per_capita = diet[categories].sum(axis=1, skipna=False)
            total = {}
            for country, amount in per_capita.items():
                population = float(geography[country][year])
                if not np.isfinite(amount) or amount < 0 or not np.isfinite(population) or population <= 0:
                    raise ValueError(f"{pathway}, {country}: invalid consumption or population")
                total[COUNTRY_CODES[country]] = float(amount) * population / 1_000_000_000
            result[pathway][group] = total
    return result


def write_diet_trade_map(out, input_dir, diets, geography, land_foods):
    """Write an offline map using country-level diet amounts and supply matrix shares."""
    out = Path(out)
    input_dir = Path(input_dir)
    assets = Path(__file__).resolve().parent / "assets/results_visuals"
    geography_codes = {COUNTRY_CODES[name]: name for name in geography}
    geometry = json.loads((assets / "world.geojson").read_text(encoding="utf-8"))
    available = {feature["properties"]["ADM0_A3"] for feature in geometry["features"]}
    if not geography_codes.keys() <= available:
        raise ValueError(f"Missing country shapes for {sorted(geography_codes.keys() - available)}")
    payload = {
        "shape": geometry,
        "names": geography_codes,
        "consumption": consumption_amounts(diets, geography, land_foods),
        "shares": supply_shares(input_dir, set(geography)),
    }
    template = (assets / "diet_trade_map.template.html").read_text(encoding="utf-8")
    if template.count("__MAP_PAYLOAD__") != 1:
        raise ValueError("Unexpected diet-map template")
    serial = json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(",", ":")).replace("<", "\\u003c")
    (out / "diet_trade_map.html").write_text(template.replace("__MAP_PAYLOAD__", serial), encoding="utf-8")

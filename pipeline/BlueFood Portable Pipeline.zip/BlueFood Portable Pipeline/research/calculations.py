from pathlib import Path
import concurrent.futures,contextlib,csv,io,json,os,pickle,random,shutil,subprocess,sys,time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from common import *
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':140})
YIELD={'Bovine Meat':.4,'Mutton & Goat Meat':.37,'Pigmeat':.52,'Poultry Meat':.51,'Eggs':.89,'Meat, Other':.85,
       'Crustaceans':.4,'Molluscs, Other':.15,'Freshwater Fish':.56,'Demersal Fish':.56,'Pelagic Fish':.56,
       'Marine Fish, Other':.56,'Aquatic Animals, Others':.56}
LAND=['Bovine Meat','Mutton & Goat Meat','Pigmeat','Poultry Meat','Eggs','Meat, Other']
DIET_DIR = GLOBAL_INPUT / 'diet'
DIET_SCENARIOS = ('2020', 'LR', 'BAU', 'HR')
DIET_FILES = {scenario: DIET_DIR / f'{scenario} diet.csv' for scenario in DIET_SCENARIOS}
CO2_DIET_FILES = {scenario: ASSETS / 'co2' / f'{scenario} diet.csv' for scenario in DIET_SCENARIOS}
def savefig(out,name):
 plt.tight_layout();plt.savefig(Path(out)/(name+'.png'),bbox_inches='tight');plt.savefig(Path(out)/(name+'.pdf'),bbox_inches='tight');plt.close()

def plot_world_edi_hi(out, stats, *, future=False):
    """Plot world means and between-run SDs for the selected set of scenarios."""
    from matplotlib.ticker import MultipleLocator, StrMethodFormatter

    if future:
        pathways = [('LL', 'LR'), ('BAU', 'BAU'), ('HL', 'HR')]
        scenarios = [f'2050_{key}_{mode}' for key, _ in pathways for mode in ('trade', 'Metatrade')]
        labels = ['Trade', 'Metatrade'] * len(pathways)
    else:
        scenarios = ['2020_notrade', '2020_trade']
        labels = ['No trade', 'Trade']
    world = stats[stats.geography_level == 'world']
    means = {}
    for metric in ('SUM_AVAILABLE_PFAS', 'HI'):
        means[metric] = world[world.pollutant == metric].groupby('scenario')['mean'].agg(['mean', 'std']).reindex(scenarios)
        means[metric]['std'] = means[metric]['std'].fillna(0)

    edi = means['SUM_AVAILABLE_PFAS']
    edi_low, edi_high = 1.0, 3.5 if future else 4.0
    edi_top = max(edi_high + .5, np.ceil(2 * ((edi['mean'] + edi['std']).max() + .08)) / 2)
    visible_values = pd.concat([edi['mean'], edi['mean'] - edi['std'], edi['mean'] + edi['std']])
    # An unfamiliar future run could place a bar or SD cap inside the gap.
    use_break = (edi['mean'] >= edi_high).any() and not visible_values.between(edi_low, edi_high, inclusive='neither').any()

    fig = plt.figure(figsize=(12, 4.7 if future else 4.5), layout='constrained')
    columns = fig.add_gridspec(1, 2)

    def split_axis(column, low, high, top):
        split = column.subgridspec(2, 1, height_ratios=[top - high, low], hspace=.13 if future else .045)
        upper = fig.add_subplot(split[0])
        lower = fig.add_subplot(split[1], sharex=upper)
        upper.set_ylim(high, top)
        lower.set_ylim(0, low)
        upper.spines['bottom'].set_visible(False)
        upper.tick_params(axis='x', bottom=False, labelbottom=False)
        lower.spines['top'].set_visible(False)
        for axis, seam in ((upper, 0), (lower, 1)):
            axis.plot([0, 1], [seam, seam], linestyle='none', marker=[(-1, -.5), (1, .5)],
                      markersize=11, markeredgewidth=1.2, color='#303841',
                      transform=axis.transAxes, clip_on=False, zorder=5)
        return upper, lower

    if use_break:
        edi_upper, edi_axis = split_axis(columns[0], edi_low, edi_high, edi_top)
        edi_title = edi_upper
    else:
        edi_axis = fig.add_subplot(columns[0])
        edi_axis.set_ylim(0, edi_top)
        edi_title = edi_axis

    hi = means['HI']
    hi_top = max(.5, np.ceil(2 * ((hi['mean'] + hi['std']).max() + .08)) / 2)
    hi_intersects_gap = ((hi['mean'] + hi['std']) > .5) & ((hi['mean'] - hi['std']) < 1)
    split_hi = not future and (hi['mean'] >= 1).any() and not hi_intersects_gap.any()
    if split_hi:
        hi_upper, hi_axis = split_axis(columns[1], .5, 1, hi_top)
    else:
        hi_axis = fig.add_subplot(columns[1])
        hi_axis.set_ylim(0, hi_top)
    series_by_axis = [(edi_axis, edi), (hi_axis, hi)]
    if use_break:
        series_by_axis.append((edi_upper, edi))
    if split_hi:
        series_by_axis.append((hi_upper, hi))
    for axis, series in series_by_axis:
        axis.bar(range(len(labels)), series['mean'], yerr=series['std'], color='#158c87', capsize=3)
        axis.yaxis.set_major_locator(MultipleLocator(.5))
        axis.yaxis.set_major_formatter(StrMethodFormatter('{x:.1f}'))
        axis.set_axisbelow(True)
        axis.grid(axis='y', color='#dbe3ea', linewidth=.8)
        axis.set_xticks(range(len(labels)), labels)
    if future:
        for axis in (edi_axis, hi_axis):
            pathway_axis = axis.secondary_xaxis('bottom')
            pathway_axis.spines['bottom'].set_visible(False)
            pathway_axis.set_xticks([2 * i + .5 for i in range(len(pathways))], [label for _, label in pathways])
            pathway_axis.tick_params(axis='x', length=0, pad=20)
    fig.supylabel('Sum of available PFAS EDI (ng/kg bw/day)', fontsize=plt.rcParams['axes.labelsize'])
    edi_title.set_title('World population-weighted mean')
    if split_hi:
        hi_axis.set_ylabel('HI', loc='top')
        hi_upper.set_title('World population-weighted mean')
    else:
        hi_axis.set(ylabel='HI', title='World population-weighted mean')
    for extension in ('png', 'pdf'):
        fig.savefig(Path(out) / f'EDI_HI.{extension}', bbox_inches='tight')
    plt.close(fig)

def moments(a):
 a=np.asarray(a,float)
 if a.size==0 or not np.isfinite(a).all() or (a<0).any():raise ValueError('Invalid nonnegative distribution')
 return {'mean':float(a.mean()),'median':float(np.median(a)),'geometric_mean':0. if (a==0).any() else float(np.exp(np.log(a).mean())),'sd':float(a.std(ddof=1)) if len(a)>1 else 0.,'n':int(a.size)}
def geography():
 d=pd.read_csv(GLOBAL_INPUT/'reference_geography.csv').set_index('country')
 return {c:{'region':r['region'],'2020':float(r.population_2020),'2050':float(r.population_2050)} for c,r in d.iterrows()}
def diet(path):
 d=pd.read_csv(path).iloc[:,:3];d.columns=['country','food','value']
 if d.duplicated(['country','food']).any() or not np.isfinite(d.value).all() or (d.value<0).any():raise ValueError('Invalid diet input')
 return d.pivot(index='country',columns='food',values='value')
def load_diets(files):
 return {scenario:diet(path) for scenario,path in files.items()}
def prepare(out,opt):
 event(out,'Checking Python, R and source data',.1)
 from certificate_trust import certificate_bundle, check_r_certificates
 bundle,ca_count=certificate_bundle(sys.prefix,CONFIG.get('ca_bundle'))
 import importlib.metadata
 installed={}
 for p in ['numpy','pandas','scipy','matplotlib','openpyxl','econml','torch','xgboost','sklearn','numba','joblib','psutil','pyecharts','shap','sparse']:
  mod=__import__(p);installed[p]=getattr(mod,'__version__','available')
 imports=[]
 for p in sorted(IMPORTS.glob('*.zip')):imports.append(extract_zip(p,IMPORTS/p.stem))
 manifest=read_json(MANIFEST,[])
 if not manifest:raise FileNotFoundError('The input asset manifest is missing or empty')
 for record in manifest:
  p=asset_file(record)
  if sha(p)!=record['sha256']:raise ValueError('Input checksum mismatch: '+str(p))
 r_exe=find_rscript(required=True)
 r_env=r_environment(r_exe)
 r_ca=check_r_certificates(r_exe,ROOT/'check_R_CA.R',r_env,bundle)
 expr='.libPaths(c('+json.dumps(str(R_LIBRARY).replace('\\','/'))+',.libPaths()));required<-c("deSolve","openxlsx","jsonlite");missing<-required[!vapply(required,requireNamespace,logical(1),quietly=TRUE)];if(length(missing))stop(paste("Missing R packages:",paste(missing,collapse=", "),". Run Setup Environment again."));cat(R.version.string,"\\n");print(sapply(required,packageVersion))'
 r=subprocess.run([str(r_exe),'--vanilla','-e',expr],env=r_env,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stdout+'\n'+r.stderr)
 load_diets(DIET_FILES)
 write_json(out/'environment.json',{'python':sys.executable,'packages':installed,'R':r.stdout,'RfD':RFD,'archives':imports,'input_files_verified':len(manifest),
  'certificate_trust':{'bundle':str(bundle),'ca_certificates':ca_count,'R':r_ca}})
 plt.figure(figsize=(9,4));plt.axis('off');plt.text(.03,.86,'Environment ready',fontsize=23,weight='bold',color='#126858');plt.text(.03,.62,'Python scientific stack  •  R  •  PBK packages',fontsize=12);plt.text(.03,.43,'Source files verified  •  ZIP imports checked',fontsize=12);plt.text(.03,.22,'Ready to run the calculation workflows',fontsize=12);savefig(out,'environment')
 event(out,'Environment and data checks passed',1)
def plot_diet_composition(out,summary):
 w=summary[summary.region=='World'].set_index('scenario').loc[['2020','LR','BAU','HR']]
 ax=w[['aquatic_kg_person_year','terrestrial_kg_person_year']].plot.bar(stacked=True,color=['#198b9b','#d6a25b'],figsize=(8,4.6),rot=0)
 for bars,color in zip(ax.containers,['white','#222222']):
  ax.bar_label(bars,labels=[f'{bar.get_height():.1f} kg' for bar in bars],label_type='center',color=color,fontsize=11,fontweight='bold')
 ax.set(xlabel='',ylabel='kg animal food/person/year',title='Population-weighted diets');ax.legend(['Aquatic','Terrestrial'],frameon=False)
 ax.figure.set_dpi(320)
 with plt.rc_context({'savefig.dpi':320}):savefig(out,'diet_composition')

def diet_stage(out,opt):
 ds=load_diets(DIET_FILES);geo=geography();rows=[];parts=[]
 for scenario in ['2020','LR','BAU','HR']:
  d=ds[scenario];year='2020' if scenario=='2020' else '2050'
  population=pd.Series({c:g[year] for c,g in geo.items()}).reindex(d.index)
  for c in d.index:
   total=float(d.loc[c].sum());terr=float(d.loc[c,LAND].sum());ed=d.loc[c]*pd.Series(YIELD)
   rows.append({'scenario':scenario,'country':c,'region':geo[c]['region'],'population':population[c],
    'aquatic_kg_person_year':total-terr,'terrestrial_kg_person_year':terr,'animal_food_total_kg_person_year':total,
    'aquatic_share':(total-terr)/total,'edible_g_person_day':float(ed.sum()*1000/365)})
   for food,v in d.loc[c].items():parts.append({'scenario':scenario,'country':c,'food':food,'kg_person_year':v,'edible_g_person_day':v*YIELD[food]*1000/365,'share_animal_food':v/total})
 country=pd.DataFrame(rows);country.to_csv(out/'country_diets.csv',index=False);pd.DataFrame(parts).to_csv(out/'country_food_composition.csv',index=False)
 summary=[]
 for (sc,reg),g in pd.concat([country,country.assign(region='World')]).groupby(['scenario','region']):
  summary.append({'scenario':sc,'region':reg,**{k:float(np.average(g[k],weights=g.population)) for k in ['aquatic_kg_person_year','terrestrial_kg_person_year','animal_food_total_kg_person_year','edible_g_person_day']}})
 summary=pd.DataFrame(summary);summary.to_csv(out/'population_weighted_diets.csv',index=False)
 plot_diet_composition(out,summary)
 from diet_map_views import write_diet_trade_map
 write_diet_trade_map(out, GLOBAL_INPUT, ds, geo, LAND)
 event(out,'Diet composition complete',1)
def plot_world_emissions(out, summary):
    """Show the saved world emissions and diet-weighted intensity on linear axes."""
    world = summary[summary.region == 'World'].set_index('scenario').rename(index={'HR118': 'HR', 'HR106': 'HR'})
    world = world.loc[['2020', 'LR', 'BAU', 'HR']]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.3), layout='constrained')
    fig.suptitle('Population-weighted world means\nArchived Figure 4a rates · pipeline population weights')
    panels = [
        ('g_CO2eq_person_day', 'Daily emissions per person', 'g CO₂e/person/day', '#168b83', '{:,.0f}'),
        ('g_CO2eq_per_g_edible_food', 'Emissions intensity', 'g CO₂e/g edible animal food', '#c29c61', '{:.2f}'),
    ]
    for axis, (column, title, unit, color, display) in zip(axes, panels):
        values = world[column]
        bars = axis.bar(world.index, values, color=color, width=.65)
        axis.bar_label(bars, labels=[display.format(value) for value in values], padding=4)
        axis.set(title=title, ylabel=unit, ylim=(0, values.max() * 1.15))
        axis.set_axisbelow(True)
        axis.grid(axis='y', color='#dbe3ea', linewidth=.8)
    for extension in ('png', 'pdf'):
        fig.savefig(Path(out) / f'emissions.{extension}', bbox_inches='tight')
    plt.close(fig)

def co2_stage(out,opt):
    rates = ASSETS / 'co2' / 'Figure 4a country rates.csv'
    data = pd.read_csv(rates, dtype={'scenario': str, 'country': str})
    geo = geography()
    scenarios = ('2020', 'LR', 'BAU', 'HR')
    expected = {(scenario, country) for scenario in scenarios for country in geo}
    pairs = data[['scenario', 'country']]
    if pairs.duplicated().any() or set(pairs.itertuples(index=False, name=None)) != expected:
        raise ValueError('Archived Figure 4a rate coverage differs from the pipeline geography')

    emission_kg = data['kg_CO2eq_person_year']
    edible_kg = data['edible_kg_person_year']
    if not np.isfinite(data[['kg_CO2eq_person_year', 'edible_kg_person_year']]).all().all() or (emission_kg < 0).any() or (edible_kg <= 0).any():
        raise ValueError('Archived Figure 4a rates must be finite and edible-food amounts must be positive')

    data['region'] = data['country'].map({name: row['region'] for name, row in geo.items()})
    data['population'] = [geo[name]['2020' if scenario == '2020' else '2050']
                          for scenario, name in pairs.itertuples(index=False, name=None)]
    data['g_CO2eq_person_day'] = emission_kg * 1000 / 365
    data['edible_g_person_day'] = edible_kg * 1000 / 365
    data['g_CO2eq_per_g_edible_food'] = emission_kg / edible_kg
    country_columns = ['scenario', 'country', 'region', 'population', 'g_CO2eq_person_day',
                       'kg_CO2eq_person_year', 'edible_g_person_day', 'g_CO2eq_per_g_edible_food']
    data[country_columns].to_csv(out / 'country_emissions_and_intensity.csv', index=False)

    groups = []
    for (scenario, region), group in pd.concat([data, data.assign(region='World')]).groupby(['scenario', 'region']):
        emission = float(np.average(group.g_CO2eq_person_day, weights=group.population))
        food = float(np.average(group.edible_g_person_day, weights=group.population))
        groups.append({'scenario': scenario, 'region': region, 'g_CO2eq_person_day': emission,
                       'g_CO2eq_per_g_edible_food': emission / food,
                       'total_Mt_CO2eq_year': float((group.kg_CO2eq_person_year * group.population).sum() / 1e9)})
    summary = pd.DataFrame(groups)
    summary.to_csv(out / 'population_weighted_emissions.csv', index=False)
    write_json(out / 'emissions_method.json', {
        'source': 'Archived Figure 4a national annual emissions and edible-food amounts per person',
        'rate_file': str(rates.relative_to(ROOT)), 'rate_sha256': sha(rates),
        'population_file': str((GLOBAL_INPUT / 'reference_geography.csv').relative_to(ROOT)),
        'population_sha256': sha(GLOBAL_INPUT / 'reference_geography.csv'),
        'population_year': {'2020': 2020, 'LR': 2050, 'BAU': 2050, 'HR': 2050},
        'intensity': 'Population-weighted emissions divided by population-weighted edible-food amount',
    })
    plot_world_emissions(out, summary)
    event(out,'CO₂ summary of archived Figure 4a rates complete',1)

def global_seed_batches(cases, opt, defaults):
 """Keep single runs paired and use the study's independent seven-run streams."""
 if opt['repeats'] != 7 or opt['seed'] != defaults.get('seed', 301):
  return [(rep, opt['seed'] + rep - 1, cases) for rep in range(1, opt['repeats'] + 1)]

 schedule = defaults['global_repeat_seeds']
 single_cases = [(label, filename, (branch,)) for label, filename, branches in cases for branch in branches]
 case_seeds = [schedule[label + '_' + branches[0]] for label, _, branches in single_cases]
 if any(len(seeds) != 7 or any(type(seed) is not int or not 0 <= seed < 2**32 for seed in seeds) for seeds in case_seeds):
  raise ValueError('Each global scenario requires seven valid integer seeds')
 if len({seed for seeds in case_seeds for seed in seeds}) != len(case_seeds) * 7:
  raise ValueError('The global sensitivity seed lists must be independent across scenarios and repeats')
 return [(rep, seeds[rep - 1], [case]) for rep in range(1, 8) for case, seeds in zip(single_cases, case_seeds)]

def global_stage(out,opt,future=False):
 os.chdir(ASSETS/'global/program');sys.path.insert(0,str(ASSETS/'global/program'));base=module(ASSETS/'global/program/base_runner.py','pipeline_base')
 assert base.RFD==RFD
 geo=geography();summary=[];manifest=[]
 cases=[('2020',DIET_FILES['2020'],('notrade','trade'))] if not future else [
  ('2050_LL',DIET_FILES['LR'],('trade','Metatrade')),
  ('2050_BAU',DIET_FILES['BAU'],('trade','Metatrade')),
  ('2050_HL',DIET_FILES['HR'],('trade','Metatrade'))]
 defaults=read_json(ROOT/'SIMULATION_DEFAULT.json')
 seed_batches=global_seed_batches(cases,opt,defaults)
 independent_runs=opt['repeats']==7 and opt['seed']==defaults.get('seed',301)
 for rep,seed,seed_cases in seed_batches:
  random.seed(seed);np.random.seed(seed);ns=base.load_model(ASSETS/'global/program/simulation_single_trade.py')
  def capture(path,ct,cw,n):return ct,cw,n,np.random.get_state(),random.getstate()
  ns['_requested']=capture
  input_fingerprint=hashlib.sha256((sha(MANIFEST)+json.dumps(environment_signature(),sort_keys=True)).encode()).hexdigest()[:12]
  cache=CACHE/f'concentrations_{input_fingerprint}_{seed}.pkl';meta=cache.with_suffix('.json')
  if cache.exists() and read_json(meta,{}).get('sha256')==sha(cache):
   with cache.open('rb') as f:ct,cw,n,nps,rs=pickle.load(f)
   event(out,f'Using verified concentration cache, seed {seed}')
  else:
   event(out,f'Sampling PFAS in food data, seed {seed}')
   with contextlib.redirect_stdout(io.StringIO()):
    # The adapted model returns concentration pools before reading any diet files.
    ct,cw,n,nps,rs=ns['flowwork_year']('PFAS',None,None,None,None,path=str(GLOBAL_INPUT)+'/')
   with cache.open('wb') as f:pickle.dump((ct,cw,n,nps,rs),f,protocol=4)
   write_json(meta,{'sha256':sha(cache),'concentration_sha256':sha(GLOBAL_INPUT/'PFAS in food data.csv'),'seed':seed})
  np.random.set_state(nps);random.setstate(rs)
  t20,w20,countries=ns['read_trade_matrix'](str(GLOBAL_INPUT)+'/','consump_trade matrix.xlsx')
  t30,w30,countries30=ns['read_trade_matrix'](str(GLOBAL_INPUT)+'/','consump_trade matrix 2050.xlsx')
  assert set(countries)==set(countries30)==set(geo)
  if t20.equals(t30) or w20.equals(w30):raise ValueError('Trade and Metatrade matrices unexpectedly identical')
  original=ns['get_dishes']
  country_order=geo if independent_runs else countries
  for label,diet_path,branches in seed_cases:
   diet_data=ns['read_FAO_diet'](str(diet_path.parent)+'/',diet_path.name);records={b:{} for b in branches}
   for count,country in enumerate(country_order):
    event(out,f'{label} · {", ".join(branches)} · repeat {rep} · {country}',(count+1)/len(country_order))
    aq_dishes=original(diet_data,country,N_sims=n,all_blue=False);tr_dishes=original(diet_data,country,N_sims=n,all_blue=False)
    state=np.random.get_state();rstate=random.getstate()
    for ib,branch in enumerate(branches):
     np.random.set_state(state);random.setstate(rstate)
     mt,mw=(None,None) if branch=='notrade' else ((t20,w20) if branch=='trade' else (t30,w30))
     ns['get_dishes']=lambda *a,**k:aq_dishes;aq=base.fast_trade(ns,country,cw,diet_data,mw,n)
     ns['get_dishes']=lambda *a,**k:tr_dishes;tr=base.fast_trade(ns,country,ct,diet_data,mt,n);ns['get_dishes']=original
     if ib==0:next_np=np.random.get_state();next_rs=random.getstate()
     labels=sorted(set(aq)&set(tr)&set(RFD))
     if not labels:raise ValueError('No compound coverage: '+country)
     arrays={'labels':np.array(labels,dtype='U20')}
     for i,c in enumerate(labels):
      arrays['aquatic_'+str(i)]=aq[c];arrays['terrestrial_'+str(i)]=tr[c]
     dest=out/'individual_values'/f'repeat_{rep}'/(label+'_'+branch)/(country+'.npz');dest.parent.mkdir(parents=True,exist_ok=True)
     np.savez_compressed(dest,**arrays);records[branch][country]=dest
     manifest.append({'scenario':label+'_'+branch,'replicate':rep,'seed':seed,'country':country,'file':str(dest.relative_to(out)),'sha256':sha(dest),'available_compounds':labels})
    np.random.set_state(next_np);random.setstate(next_rs)
   previous=base.FACTORS;base.FACTORS=(1.,)
   for branch in branches:
    with contextlib.redirect_stdout(io.StringIO()):summary.extend(base.aggregate_scenario(out,label+'_'+branch,records[branch],geo,rep,seed))
   base.FACTORS=previous
   pd.DataFrame(summary).to_csv(out/'statistics.csv',index=False);write_json(out/'individual_manifest.json',manifest)
 stats=pd.DataFrame(summary);stats.to_csv(out/'statistics.csv',index=False)
 plot_world_edi_hi(out,stats,future=future)
 write_json(out/'method.json',{'body_weight_kg':62,'RfD':RFD,'concentration':'PFAS in food data','diets':{label: path.name for label,path,_ in cases},'simulation_defaults':read_json(ROOT/'SIMULATION_DEFAULT.json',{}),'raw_uncalibrated':True,'source_model_sha256':sha(ASSETS/'global/program/simulation_single_trade.py'),'sum7_label':'Sum of available target PFAS, coverage recorded','country_first_population_weighted_HI':True})
 if not future:
  from baseline_result_views import render_baseline_views
  render_baseline_views(out, stats, DIET_FILES['2020'], manifest, ASSETS / 'results_visuals/world.geojson')
 event(out,'Exposure and HI calculations complete',1)
def us_year(args):
 year,rep,out,body_weight,start_seed=args;out=Path(out);sys.path.insert(0,str(ROOT))
 driver=module(ASSETS/'us/code/run_us_exposure.py','pipeline_us_driver')
 driver.ROOT=ASSETS/'us';driver.INPUT=ASSETS/'us/inputs';driver.OUT=out;driver.BW=body_weight;driver.START_SEED=start_seed
 folder=out/'annual'/str(year);folder.mkdir(parents=True,exist_ok=True)
 m,s,c=driver.run_case(year,rep,'baseline',folder)
 return m,s,c
def us_stage(out,opt):
 rows=[];sums=[];checks=[]
 tasks=[(y,r,str(out),opt['historical_body_weight_kg'],opt['seed']) for r in range(1,opt['repeats']+1) for y in range(2003,2017)]
 with concurrent.futures.ProcessPoolExecutor(max_workers=opt['workers']) as pool:
  jobs={pool.submit(us_year,a):a for a in tasks}
  for f in concurrent.futures.as_completed(jobs):
   cancelled(out);m,s,c=f.result();rows+=m;sums.append(s);checks.append(c)
   event(out,f'US EDI {c["year"]} · repeat {c["replicate"]} complete',len(checks)/len(tasks))
 for record in rows+sums:record['body_weight_kg']=opt['historical_body_weight_kg']
 pd.DataFrame(rows).to_csv(out/'US_EDI.csv',index=False);pd.DataFrame(sums).to_csv(out/'US_Sum7.csv',index=False)
 write_json(out/'method.json',{'body_weight_kg':opt['historical_body_weight_kg'],'units':'ng/kg_bw/day','concentration_input':'PFAS in food data','source_program':'assets/us/code/exposure_model.py','time_trend_input':'assets/us/inputs/aquatic_time_trends.xlsx','terrestrial_time_window':False,'terrestrial_k':1,'food_concentration_file':'PFAS in food data.csv','source_provenance':'SOURCE_PROVENANCE.json'})
 write_json(out/'checks.json',checks)
 d=pd.DataFrame(rows);d=d[(d.component=='total')&(d.status=='available')]
 fig,axes=plt.subplots(2,4,figsize=(13,6.8),sharex=True)
 for ax,c in zip(axes.flat,CHEMS):
  s=d[d.chemical==c].groupby('year').agg(gmean=('gmean_EDI','mean'),sd=('gmean_EDI','std'),reference=('reference_gmean_EDI','first'))
  ax.errorbar(s.index,s.gmean,yerr=s.sd.fillna(0),color='#168b83',label='Calculated');ax.plot(s.index,s.reference,'--',color='#ad8d5c',label='Historical');ax.set(title=c,ylabel='ng/kg bw/day')
 axes.flat[-1].axis('off');axes.flat[0].legend(frameon=False,fontsize=8);fig.suptitle('US dietary exposure, 2003–2016')
 from us_result_views import historical_cv_note, historical_edi_views
 historical_cv_note(fig, ASSETS/'us')
 savefig(out,'US_EDI')
 historical_edi_views(out, rows, sums, opt['historical_body_weight_kg'], ASSETS/'us', savefig)
 comparison=[]
 for y,g in d.groupby('year'):
  diff=100*(g.gmean_EDI/g.reference_gmean_EDI-1)
  comparison.append({'year':int(y),'mean_percent_difference':float(diff.mean()),'median_percent_difference':float(diff.median()),'minimum_percent_difference':float(diff.min()),'maximum_percent_difference':float(diff.max())})
 pd.DataFrame(comparison).to_csv(out/'difference_from_historical_by_year.csv',index=False)
 event(out,'US annual EDI and historical comparison complete',1)

def serum_model():
 from scipy.stats import gmean
 return functions(ASSETS/'health/source/serum_mapping.py',{'np':np,'pd':pd,'gmean':gmean})
def serum_arrays(path,model=None):
 model=model or serum_model()
 with np.load(path,allow_pickle=False) as data:
  result={}
  for i,c in enumerate(data['labels'].tolist()):
   # Published fits take absolute ng/person/day; their internal /63 is unchanged.
   raw=data['aquatic_'+str(i)]+data['terrestrial_'+str(i)]
   value=np.asarray(model['D_func'][c](raw),float)
   if not np.isfinite(value).all() or (value<=0).any():raise ValueError('Invalid serum prediction: '+c)
   result[c]=value
 return result
def serum_burden_outputs(out):
 """Sum of arithmetic means, without assuming a joint serum distribution."""
 d=pd.read_csv(Path(out)/'country_serum_concentrations.csv')
 totals=d.groupby(['scenario','replicate','country'],as_index=False).agg(mean_total_available_PFAS_ng_ml=('mean','sum'),available_compounds=('chemical','nunique'))
 geo=geography();totals['region']=totals.country.map(lambda c:geo[c]['region'])
 totals['population']=[geo[c][sc[:4]] for c,sc in zip(totals.country,totals.scenario)]
 totals.to_csv(Path(out)/'country_total_serum_burden.csv',index=False)
 rows=[]
 for (sc,rep,region),g in pd.concat([totals,totals.assign(region='World')]).groupby(['scenario','replicate','region']):
  rows.append({'scenario':sc,'replicate':rep,'region':region,'mean_total_available_PFAS_ng_ml':float(np.average(g.mean_total_available_PFAS_ng_ml,weights=g.population)),'countries':len(g),'population':float(g.population.sum()),'minimum_compound_coverage':int(g.available_compounds.min()),'maximum_compound_coverage':int(g.available_compounds.max())})
 pd.DataFrame(rows).to_csv(Path(out)/'regional_world_total_serum_burden.csv',index=False)
def measured_serum(path):
 """Read supplied Data 3 revisions without treating mass units as volume units."""
 with pd.ExcelFile(path) as book:
  sheet=next((s for s in ('reviewed measures','reviewed meansures') if s in book.sheet_names),None)
  if sheet is None:raise ValueError('Data 3 has no reviewed measurements sheet')
  measured=pd.read_excel(book,sheet_name=sheet)
 value_column=next((c for c in ('Value (ng/mL unless noted)','Value (ng/mL)') if c in measured),None)
 required={'Region/Country','Analyte','Metric','Years','Cohort Type','Matrix','Reference (link)'}
 if value_column is None or not required.issubset(measured.columns):raise ValueError('Data 3 measurement columns are incomplete')
 measured['reported_value']=pd.to_numeric(measured[value_column],errors='coerce')
 units=measured['Matrix'].fillna('').astype(str).str.extract(r'(?i)\b((?:[fpnum\u03bc\u00b5]?g|[fpnum\u03bc\u00b5]?mol)\s*/\s*(?:m?l|[kmg]?g))\b',expand=False)
 units=units.str.replace(r'\s+','',regex=True).fillna('ng/mL')
 measured['reported_unit']=units.where(units.str.lower()!='ng/ml','ng/mL')
 reference=measured['Reference (link)'].fillna('').astype(str)
 # Gyllenhammar et al. (2025), Table 2 reports the Swedish serum concentrations by mass.
 swedish_mass=reference.str.contains('10.1016/j.envint.2025.109671',regex=False)
 measured.loc[swedish_mass,'reported_unit']='ng/g'
 # Health Canada, Tables 12.1.8–9: the 0.44 PFNA entry covers a broader age group than adults.
 canada_adult_pfna=(reference.str.startswith('https://www.canada.ca/') &
  measured['Region/Country'].eq('Canada') & measured['Cohort Type'].eq('CHMS (national, adults)') &
  measured['Analyte'].eq('PFNA') & measured['Years'].astype(str).eq('2018-2019') &
  measured['reported_value'].eq(.44))
 measured.loc[canada_adult_pfna,'Cohort Type']='CHMS (national, broader age group)'
 measured['measured_ng_ml']=measured['reported_value'].where(measured['reported_unit']=='ng/mL')
 return measured

def serum_stage(out,opt,exposure_out):
 manifest=read_json(Path(exposure_out)/'individual_manifest.json');model=serum_model();geo=geography();rows=[]
 for k,record in enumerate(manifest):
  if record['scenario']=='2020_notrade':continue
  arrays=serum_arrays(Path(exposure_out)/record['file'],model)
  for chemical,v in arrays.items():rows.append({'scenario':record['scenario'],'replicate':record['replicate'],'country':record['country'],'chemical':chemical,'unit':'ng/mL',**moments(v)})
  event(out,'Serum · '+record['scenario']+' · '+record['country'],(k+1)/len(manifest))
 d=pd.DataFrame(rows);d.to_csv(out/'country_serum_concentrations.csv',index=False);serum_burden_outputs(out)
 groups=[]
 for (sc,rep,c),g in d.groupby(['scenario','replicate','chemical']):
  for region in ['World']+sorted({v['region'] for v in geo.values()}):
   s=g if region=='World' else g[g.country.map(lambda x:geo[x]['region'])==region]
   all_members=[x for x in geo if region=='World' or geo[x]['region']==region]
   year=sc[:4];full_pop=sum(geo[x][year] for x in all_members)
   if not len(s):continue
   p=np.array([geo[x][year] for x in s.country]);covered=float(p.sum())
   groups.append({'scenario':sc,'replicate':rep,'region':region,'chemical':c,'population_coverage':covered/full_pop,
    'mean_ng_ml':float(np.sum(s['mean']*p)/full_pop),'geometric_mean_available_population_ng_ml':float(np.exp(np.average(np.log(s.geometric_mean),weights=p)))})
 pd.DataFrame(groups).to_csv(out/'regional_world_serum.csv',index=False)
 if (d.scenario=='2020_trade').any():
  from serum_comparison import comparison_rows,draw_comparison,pick_country_points
  measured=measured_serum(ASSETS/'health/data/Measured_serum.xlsx')
  comparison=pick_country_points(comparison_rows(measured,d[d.scenario=='2020_trade']))
  comparison.to_csv(out/'predicted_vs_measured_serum.csv',index=False)
  _,ax=plt.subplots(figsize=(7,5.8))
  draw_comparison(ax,comparison);savefig(out,'serum_vs_measured')
 else:
  world=pd.DataFrame(groups);world=world[world.region=='World'];p=world.pivot_table(index='scenario',columns='chemical',values='mean_ng_ml')
  p.index=[c.replace('2050_','').replace('LL','LR').replace('HL','HR').replace('_','\n') for c in p.index]
  ax=p.plot.bar(stacked=True,figsize=(10,5),rot=0,colormap='viridis');ax.set(ylabel='ng/mL',xlabel='',title='Population-weighted modeled serum burden · available PFAS');ax.legend(frameon=False,bbox_to_anchor=(1.01,1));savefig(out,'future_serum')
 write_json(out/'serum_method.json',{'source':'Published intake-to-serum fits (0107)','input_unit':'ng/person/day','output_unit':'ng/mL','internal_curve_divisor_63_unchanged':True,'measured_comparison':'PFOA, PFOS, PFOA + PFOS and PFOS + PFOA + PFHxS + PFNA. Combined comparisons add the same compound statistic (arithmetic mean, median or geometric mean) on each axis. Measurements are paired within the same country, report, cohort, subgroup, sampling period and matrix. Each series uses one point per country by the sampling-period midpoint nearest 2020, with ties resolved by statistic (arithmetic mean, geometric mean, then median) and source metadata.'})

def pbk_stage(out,opt,us_out):
 job=out/'R_job';job.mkdir();(job/'code').mkdir();(job/'original_source').mkdir();(job/'results').mkdir()
 for p in (R_ORIGINAL/'original_source').iterdir():
  if p.is_file():shutil.copy2(p,job/'original_source'/p.name)
 for name in ['PFAS_PBK_US_2003_2016_Fabrega_2015.R','ode_fast.R']:
  shutil.copy2(R_ORIGINAL/'code'/name,job/'code'/name)
 runner=(ROOT/'r_runner.R').read_text(encoding='utf-8')
 (job/'code/run.R').write_text(runner,encoding='utf-8')
 intakes=out/'intakes';intakes.mkdir()
 for year in range(2003,2017):
  path=Path(us_out)/'annual'/str(year)/'baseline_r1.npz'
  with np.load(path,allow_pickle=False) as data:
   for source,folder in [('total','total'),('aquatic','aqours'),('terrestrial','terri')]:
    dest=intakes/f'{year}_US_{folder}_exposure';dest.mkdir()
    pd.DataFrame({c:data[f'expo_{source}^{c}'] for c in ['PFOA','PFOS']}).to_csv(dest/'N100000_United States_expo.csv',index=False)
 for mode in ['smoke','prepare','run']:
  event(out,'R PBK · '+mode)
  cmd=[str(find_rscript(required=True)),'--vanilla',str(job/'code/run.R'),'--job',str(job),'--mode',mode,'--input-root',str(intakes),'--benchmark',str(ASSETS/'r/nhanes_pfas_total_population.csv'),'--workers',str(opt['workers']),'--grid',str(opt['pbk_grid'])]
  with (out/f'R_{mode}.log').open('w',encoding='utf-8') as log:
   child=subprocess.Popen(cmd,env=r_environment(),stdout=log,stderr=subprocess.STDOUT)
   try:
    while child.poll() is None:cancelled(out);time.sleep(.5)
   except BaseException:
    import psutil
    try:
     for p in psutil.Process(child.pid).children(recursive=True):p.terminate()
     child.terminate()
    except psutil.NoSuchProcess:pass
    raise
  if child.returncode:raise RuntimeError('R PBK '+mode+' failed; see '+str(out/f'R_{mode}.log'))
 d=pd.read_csv(job/'results/period_results.csv');d.to_csv(out/'PFOA_PFOS_period_results.csv',index=False)
 validate_pbk_population(out)
 fig,axes=plt.subplots(1,2,figsize=(12,4.5))
 for ax,c in zip(axes,['PFOA','PFOS']):
  for name,g in d[d.compound==c].groupby('scenario'):ax.plot(g.period,g.geometric_mean,'o-',label=name.replace('_',' '))
  g=d[(d.compound==c)&(d.scenario=='aquatic_plus_terrestrial')];ax.plot(g.period,g.NHANES_gmean,'k--',label='NHANES');ax.tick_params(axis='x',rotation=40);ax.set(title=c,ylabel='Serum geometric mean (ng/mL)')
 axes[1].legend(frameon=False,fontsize=8,bbox_to_anchor=(1.02,1));savefig(out,'US_PBK_R')
 from us_result_views import pbk_composition_view
 pbk_composition_view(out, d, savefig)
 event(out,'R PFOA/PFOS PBK complete',1)

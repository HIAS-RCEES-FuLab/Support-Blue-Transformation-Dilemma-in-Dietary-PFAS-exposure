"""Start this pipeline locally, reusing only this installation's server."""
from pathlib import Path
import argparse
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser
from runtime import *
from miniforge_runtime import expanded_path, managed_python, prefix_python, verify_launcher_host

def probe(port):
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open('http://127.0.0.1:' + str(port) + '/api/state', timeout=2) as reply:
            body = json.load(reply)
        return body if body.get('service') == 'bluefood-pipeline' and body.get('instance_id') == INSTANCE_ID else None
    except (OSError, ValueError):
        return None

def interpreter(explicit=None):
    selected = explicit or os.environ.get('BLUEFOOD_PYTHON') or CONFIG.get('python')
    path = expanded_path(selected) if selected else prefix_python(ROOT / '.environment')
    return managed_python(path if path.is_absolute() else ROOT / path)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--python')
    p.add_argument('--port', type=int, default=PORT)
    p.add_argument('--no-browser', action='store_true')
    p.add_argument('--stop', action='store_true', help='Close this installation and its running calculation')
    args = p.parse_args()
    verify_launcher_host(sys.executable)
    python = interpreter(args.python)
    ensure_workspace()
    saved = STATE / 'server.json'
    previous = json.loads(saved.read_text()) if saved.exists() else {}
    state = probe(previous.get('port', args.port))
    port = previous.get('port') if state else None
    if args.stop:
        if not state:
            print('This pipeline is already closed.')
            return
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        url = 'http://127.0.0.1:' + str(port)
        with opener.open(url + '/') as response:
            token = re.search(r"const TOKEN='([^']+)'", response.read().decode('utf-8')).group(1)
        request = urllib.request.Request(url + '/api/shutdown', data=b'{}', headers={'Content-Type': 'application/json', 'X-BlueFood-Token': token})
        with opener.open(request) as response:
            json.load(response)
        try:
            import psutil
            try:
                psutil.Process(previous['pid']).wait(timeout=10)
            except psutil.NoSuchProcess:
                pass
        except ImportError:
            for attempt in range(40):
                if not probe(port):
                    time.sleep(.2)
                    break
                time.sleep(.25)
        print('Pipeline closed.')
        return
    if state and previous.get('python') != str(python):
        raise ValueError('Stop the existing pipeline before starting it with the verified Miniforge interpreter.')
    if not state:
        from bootstrap import process_env
        env = process_env(python.parent if os.name == 'nt' else python.parent.parent)
        env.update(PYTHONHASHSEED='0', PYTHONUTF8='1', MPLBACKEND='Agg')
        import socket
        chosen = args.port
        if chosen:
            with socket.socket() as test:
                try:
                    test.bind(('127.0.0.1', chosen))
                except OSError:
                    chosen = 0
        flags = {'creationflags': subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS} if os.name == 'nt' else {'start_new_session': True}
        with (STATE / 'server.log').open('ab') as log:
            child = subprocess.Popen([str(python), '-u', str(ROOT / 'app.py'), '--port', str(chosen)], cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, **flags)
        for attempt in range(60):
            if child.poll() is not None:
                raise RuntimeError('The window could not start. See ' + str(STATE / 'server.log'))
            try:
                current = json.loads(saved.read_text())
                if current.get('pid') == child.pid:
                    port = current['port']
                    if probe(port):
                        break
            except (OSError, ValueError):
                pass
            time.sleep(.5)
        else:
            child.terminate()
            raise RuntimeError('The calculation window did not become ready; see ' + str(STATE / 'server.log'))
    url = 'http://127.0.0.1:' + str(port) + '/'
    print(url)
    if not args.no_browser:
        webbrowser.open(url)

if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)

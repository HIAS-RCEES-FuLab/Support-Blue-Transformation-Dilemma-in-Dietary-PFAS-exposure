import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
 os.environ[key]='1'
os.environ['PYTHONHASHSEED']='0'
import argparse,traceback,time
from common import *
from miniforge_runtime import managed_python
os.environ['BLUEFOOD_R_LIBRARY']=str(R_LIBRARY)
os.environ['CUDA_VISIBLE_DEVICES']=''
def main():
 managed_python(sys.executable)
 p=argparse.ArgumentParser();p.add_argument('--stage',required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--request',type=Path,required=True);a=p.parse_args()
 request=read_json(a.request);opt=options(request['options']);out=a.out
 start=time.time();event(out,'Starting calculation')
 try:
  from calculations import prepare,us_stage,pbk_stage,global_stage,serum_stage,diet_stage,co2_stage
  deps=request['dependencies']
  if a.stage=='prepare':prepare(out,opt)
  elif a.stage=='us_edi':us_stage(out,opt)
  elif a.stage=='us_pbk':pbk_stage(out,opt,Path(deps['us_edi']['out']))
  elif a.stage=='baseline':global_stage(out,opt,False)
  elif a.stage=='baseline_serum':
   serum_stage(out,opt,Path(deps['baseline']['out']))
   from health import run_health
   run_health(out,opt,Path(deps['baseline']['out']))
  elif a.stage=='diets':diet_stage(out,opt)
  elif a.stage=='co2':co2_stage(out,opt)
  elif a.stage=='future':
   global_stage(out,opt,True);serum_stage(out,opt,out)
   from health import run_health
   run_health(out,opt,out,Path(deps['baseline']['out']))
  else:raise ValueError('Unknown calculation')
  write_json(out/'COMPLETE.json',{'status':'complete','stage':a.stage,'seconds':time.time()-start,'options':opt,'fingerprint':request['fingerprint'],'images':[x.name for x in out.glob('*.png')],'completed_at':time.time()})
  event(out,'Calculation complete',1)
 except BaseException as exc:
  write_json(out/'FAILED.json',{'status':'cancelled' if isinstance(exc,InterruptedError) else 'failed','error':str(exc),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main()

"""Result plots for the 2020 dietary exposure and hazard index simulation."""

import json
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib import colors, ticker
from matplotlib.cm import ScalarMappable
from matplotlib.collections import PatchCollection
from matplotlib.patches import Polygon
import numpy as np
import pandas as pd
from scipy.stats import linregress


TRADE = "2020_trade"
NO_TRADE = "2020_notrade"
FISH = ("Freshwater Fish", "Demersal Fish", "Pelagic Fish", "Marine Fish, Other")
MAP_ALIASES = {
    "Korea": "South Korea",
    "Slovak Republic": "Slovakia",
    "Turkiye": "Turkey",
    "United States": "United States of America",
}
MAP_COLORS = colors.LinearSegmentedColormap.from_list(
    "green_white_red", ("#476548", "#ffffff", "#a81321")
)


def _save(fig, out, stem):
    for extension in ("png", "pdf"):
        fig.savefig(out / f"{stem}.{extension}", bbox_inches="tight", dpi=180, facecolor="white")
    plt.close(fig)


def _country_shapes(path):
    features = json.loads(Path(path).read_text(encoding="utf-8"))["features"]
    shapes = {}
    for feature in features:
        properties = feature["properties"]
        geometry = feature["geometry"]
        if geometry["type"] not in {"Polygon", "MultiPolygon"}:
            raise ValueError("Expected polygon features for the country map")
        polygons = [geometry["coordinates"]] if geometry["type"] == "Polygon" else geometry["coordinates"]
        shapes[properties["ADMIN"]] = polygons
    return shapes


def _draw_map(out, shapes, results, title, label, norm, ticks, stem, fmt=None):
    by_shape = {MAP_ALIASES.get(country, country): value for country, value in results.items()}
    missing = set(by_shape) - shapes.keys()
    if missing:
        raise ValueError("Country boundaries unavailable for " + ", ".join(sorted(missing)))

    fig, ax = plt.subplots(figsize=(12, 5.9))
    patches = []
    faces = []
    edges = []
    for country, polygons in shapes.items():
        value = by_shape.get(country, np.nan)
        is_modeled = np.isfinite(value)
        face = MAP_COLORS(norm(value)) if is_modeled else "#e3e5e5"
        edge = "#495354" if is_modeled else "#bdc3c4"
        for polygon in polygons:
            patches.append(Polygon(polygon[0], closed=True))
            faces.append(face)
            edges.append(edge)
    ax.add_collection(PatchCollection(patches, facecolors=faces, edgecolors=edges, linewidths=0.45, zorder=2))
    ax.set(xlim=(-180, 180), ylim=(-60, 85), xticks=np.arange(-180, 181, 60),
           yticks=np.arange(-60, 61, 30), title=title)
    ax.xaxis.set_major_formatter(ticker.FuncFormatter(
        lambda value, _: f"{abs(value):g}°" + ("W" if value < 0 else "E" if value > 0 else "")
    ))
    ax.yaxis.set_major_formatter(ticker.FuncFormatter(
        lambda value, _: f"{abs(value):g}°" + ("S" if value < 0 else "N" if value > 0 else "")
    ))
    ax.grid(color="#bbc3c4", linestyle=":", linewidth=0.7, zorder=1)
    ax.set_aspect("equal")
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color("#637070")
    bar = fig.colorbar(ScalarMappable(norm=norm, cmap=MAP_COLORS), ax=ax, shrink=0.84, pad=0.02,
                       ticks=ticks, format=fmt)
    bar.set_label(label)
    fig.text(0.12, 0.09, "Gray indicates unavailable results.", fontsize=9, color="#465353")
    _save(fig, out, stem)


def _hi_maps(out, stats, shapes):
    select = (
        stats["scenario"].isin((TRADE, NO_TRADE))
        & stats["geography_level"].eq("country")
        & stats["pollutant"].eq("HI")
        & stats["aquatic_factor"].eq(1)
    )
    means = stats.loc[select].groupby(["geography", "scenario"])["mean"].mean().unstack()
    if means.empty or means[[TRADE, NO_TRADE]].isna().any().any():
        raise ValueError("The baseline HI maps require results for both scenarios in every modeled country")
    change = 100 * (means[TRADE] - means[NO_TRADE]) / means[NO_TRADE].where(means[NO_TRADE] > 0)
    export = means.rename(columns={TRADE: "mean_HI_trade", NO_TRADE: "mean_HI_no_trade"})
    export["trade_change_percent"] = change
    export.rename_axis("country").to_csv(out / "country_HI_map_data.csv")

    upper = max(2.0, float(np.ceil(means[TRADE].max())))
    hi_ticks = [0, 1] + [x for x in (5, 10, 20, 50) if x < 0.9 * upper] + [upper]
    _draw_map(out, shapes, means[TRADE], "2020 hazard index by country · Trade",
              "Mean hazard index", colors.TwoSlopeNorm(vmin=0, vcenter=1, vmax=upper),
              hi_ticks, "country_HI_map", ticker.FormatStrFormatter("%.2g"))

    available = change.dropna()
    if available.empty:
        raise ValueError("HI percentage changes require at least one nonzero no-trade baseline")
    lo = min(-10, 10 * np.floor(available.min() / 10))
    hi = max(10, 10 * np.ceil(available.max() / 10))
    ticks = [lo, lo / 2, 0, hi / 2, hi]
    _draw_map(out, shapes, change, "2020 hazard index change from No trade to Trade",
              "Change relative to No trade", colors.TwoSlopeNorm(vmin=lo, vcenter=0, vmax=hi),
              ticks, "trade_HI_change_map", ticker.PercentFormatter(xmax=100, decimals=0))


def _total_edi(path):
    with np.load(path, allow_pickle=False) as arrays:
        count = len(arrays["labels"])
        if not count:
            raise ValueError(f"No PFAS compounds available in {path.name}")
        total = np.zeros(arrays["aquatic_0"].shape, dtype=float)
        for index in range(count):
            total += arrays[f"aquatic_{index}"]
            total += arrays[f"terrestrial_{index}"]
    total /= 62.0
    if not total.size or not np.isfinite(total).all() or (total < 0).any():
        raise ValueError(f"Invalid 2020 Trade EDI values in {path.name}")
    return total


def _fish_edi(out, diet_path, manifest, countries):
    diet = pd.read_csv(diet_path, usecols=["country", "food", "value"])
    fish = diet.loc[diet["food"].isin(FISH)].groupby("country")["value"].sum()
    records = {}
    for record in manifest:
        if record["scenario"] == TRADE:
            records.setdefault(record["country"], []).append(record)
    if set(records) != countries or not countries.issubset(fish.index):
        raise ValueError("Fish consumption and simulated 2020 Trade results must cover all modeled countries")

    rows = []
    for country in sorted(records):
        repeats = sorted(records[country], key=lambda item: item["replicate"])
        samples = np.concatenate([_total_edi(out / record["file"]) for record in repeats])
        geometric_mean = 0.0 if (samples == 0).any() else float(np.exp(np.log(samples).mean()))
        lower, upper = np.percentile(samples, [25, 75])
        rows.append({
            "country": country, "fish_kg_person_year": fish[country], "geometric_mean_edi": geometric_mean,
            "edi_p25": lower, "edi_p75": upper, "n_simulated_values": samples.size,
        })
    data = pd.DataFrame(rows)
    data.to_csv(out / "fish_consumption_EDI_data.csv", index=False)
    x = data["fish_kg_person_year"]
    y = data["geometric_mean_edi"]
    fit = linregress(x, y)
    x_fit = np.linspace(x.min(), x.max(), 150)

    fig, ax = plt.subplots(figsize=(9.5, 5.7))
    midpoint = (data["edi_p25"] + data["edi_p75"]) / 2
    half_range = data["edi_p75"] - midpoint
    ax.errorbar(x, midpoint, yerr=half_range, fmt="none", ecolor="#859d9d", alpha=0.8,
                linewidth=1.05, capsize=2, label="25th–75th percentile of simulated EDI")
    ax.scatter(x, y, s=31, color="#168b83", edgecolors="#07594f", linewidths=0.4,
               zorder=3, label="Country geometric mean")
    ax.plot(x_fit, fit.intercept + fit.slope * x_fit, color="#ad2f3e", linestyle="--",
            linewidth=1.6, label=f"Linear fit (r = {fit.rvalue:.2f}, p = {fit.pvalue:.2g})")
    ax.set(xlabel="Fish consumption (kg/person/year)", ylabel="Dietary EDI (ng/kg bw/day)",
           title="Fish consumption and total dietary PFAS EDI · 2020 Trade")
    ax.set_axisbelow(True)
    ax.grid(axis="y", alpha=0.22)
    ax.legend(frameon=False, fontsize=9)
    fig.subplots_adjust(bottom=0.19)
    fig.text(0.12, 0.055, "Fish includes freshwater, demersal, pelagic and other marine fish. "
             "EDI sums available PFAS.", fontsize=9, color="#465353")
    _save(fig, out, "fish_consumption_vs_EDI")


def render_baseline_views(out, stats, diet_path, manifest, geometry_path):
    """Render the manuscript-style HI maps and a country EDI–fish comparison."""
    out = Path(out)
    shapes = _country_shapes(geometry_path)
    _hi_maps(out, stats, shapes)
    modeled = set(stats.loc[stats["geography_level"].eq("country") & stats["scenario"].eq(TRADE), "geography"])
    _fish_edi(out, diet_path, manifest, modeled)

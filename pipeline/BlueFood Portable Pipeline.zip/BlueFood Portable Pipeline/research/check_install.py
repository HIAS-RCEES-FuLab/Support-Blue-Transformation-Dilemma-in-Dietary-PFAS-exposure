from common import *
import importlib
import importlib.metadata
import argparse,subprocess
from certificate_trust import certificate_bundle, check_python_https, check_r_certificates
def main():
 p=argparse.ArgumentParser();p.add_argument('--install-r-packages',action='store_true');p.add_argument('--check-online',action='store_true');args=p.parse_args()
 result={'python':sys.executable,'python_version':sys.version,'RfD':RFD,'imports':{},'workspace':str(WORKSPACE)}
 if sys.version_info[:2]!=(3,9):raise RuntimeError('The preserved scientific package set requires Python 3.9. Run Setup Environment.')
 for name in ['numpy','pandas','scipy','matplotlib','openpyxl','econml','torch','xgboost','numba','joblib','psutil','pyecharts','shap','sparse']:
  print('Checking Python package: '+name,flush=True)
  mod=importlib.import_module(name);result['imports'][name]=getattr(mod,'__version__','available')
 for line in (ROOT/'requirements.txt').read_text().splitlines():
  if not line.strip() or line.startswith('#'):continue
  name,expected=line.strip().split('==');actual=importlib.metadata.version(name)
  if actual.split('+')[0]!=expected:raise RuntimeError(f'{name} {actual} differs from the preserved version {expected}. Rerun Setup Environment.')
 records=read_json(MANIFEST)
 if not records:raise FileNotFoundError('ASSET_MANIFEST.json is missing or empty')
 for record in records:
  if sha(asset_file(record))!=record['sha256']:raise ValueError('Input checksum mismatch: '+record['path'])
 result['input_files_verified']=len(records)
 r=find_rscript(required=True);env=r_environment(r)
 bundle,ca_count=certificate_bundle(sys.prefix,CONFIG.get('ca_bundle'))
 result['certificate_trust']={'bundle':str(bundle),'ca_certificates':ca_count,
  'R':check_r_certificates(r,ROOT/'check_R_CA.R',env,bundle,online=args.check_online)}
 if args.check_online:
  result['certificate_trust']['python_https']=check_python_https(bundle)
 command=[str(r),'--vanilla',str(ROOT/'setup_R.R'),'--library',str(R_LIBRARY)]
 if args.install_r_packages:command.append('--install')
 reply=subprocess.run(command,env=env,capture_output=True,text=True)
 if reply.returncode:raise RuntimeError(reply.stdout+'\n'+reply.stderr)
 result.update(Rscript=str(r),R=reply.stdout,resources=resource_limits())
 write_json(STATE/'install_check.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':main()

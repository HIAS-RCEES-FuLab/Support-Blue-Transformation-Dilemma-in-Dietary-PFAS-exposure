param(
    [string]$Conda,
    [string]$Prefix,
    [string]$Rscript,
    [switch]$DryRun,
    [string]$CondaArchives,
    [string]$Wheelhouse,
    [string]$CABundle,
    [switch]$CheckOnline
)

$ErrorActionPreference = 'Stop'

function Find-Miniforge([string]$Root) {
    if (-not $Root) { return }
    $Root = [Environment]::ExpandEnvironmentVariables($Root.Trim('"'))
    if (-not (Test-Path -LiteralPath $Root -PathType Container)) { return }
    $Root = (Resolve-Path -LiteralPath $Root).ProviderPath
    $python = Join-Path $Root 'python.exe'
    $condaExe = Join-Path $Root 'Scripts\conda.exe'
    if (-not (Test-Path -LiteralPath $python -PathType Leaf) -or
        -not (Test-Path -LiteralPath $condaExe -PathType Leaf) -or
        -not (Test-Path -LiteralPath (Join-Path $Root 'conda-meta\history') -PathType Leaf)) {
        return
    }
    $condaPackage = Get-ChildItem -LiteralPath (Join-Path $Root 'conda-meta') -Filter 'conda-*.json' -File |
        Where-Object { $_.Name -match '^conda-\d' } |
        Select-Object -First 1
    if (-not $condaPackage) { return }

    $installer = Join-Path $Root '.installer.info'
    $hasMiniforgeInstaller = Test-Path -LiteralPath (Join-Path $Root 'Uninstall-Miniforge3.exe') -PathType Leaf
    if (Test-Path -LiteralPath $installer -PathType Leaf) {
        try {
            $metadata = Get-Content -LiteralPath $installer -Raw -Encoding UTF8 | ConvertFrom-Json
            $hasMiniforgeInstaller = $metadata.name -in @('Miniforge', 'Miniforge3')
        } catch {
            return
        }
    }
    if ($hasMiniforgeInstaller) {
        [pscustomobject]@{Python = $python; Conda = $condaExe}
    }
}

function Get-CondaRoot([string]$Executable) {
    if (-not $Executable) { return }
    $Executable = [Environment]::ExpandEnvironmentVariables($Executable.Trim('"'))
    if (Test-Path -LiteralPath $Executable -PathType Leaf) {
        $location = (Resolve-Path -LiteralPath $Executable).ProviderPath
        $parent = Split-Path -Parent $location
        if ((Split-Path -Leaf $parent) -in @('Scripts', 'condabin')) {
            Split-Path -Parent $parent
        }
    }
}

if ($Conda) {
    $miniforge = Find-Miniforge (Get-CondaRoot $Conda)
    if (-not $miniforge) { throw '-Conda must point to the Conda executable in an installed copy of Miniforge.' }
} elseif ($env:BLUEFOOD_MINIFORGE_ROOT) {
    $miniforge = Find-Miniforge $env:BLUEFOOD_MINIFORGE_ROOT
    if (-not $miniforge) { throw 'BLUEFOOD_MINIFORGE_ROOT must point to an installed copy of Miniforge.' }
} else {
    $configPath = $env:BLUEFOOD_CONFIG
    if (-not $configPath) { $configPath = Join-Path $PSScriptRoot 'bluefood.json' }
    elseif (-not [IO.Path]::IsPathRooted($configPath)) { $configPath = Join-Path $PSScriptRoot $configPath }
    $roots = @()
    if (Test-Path -LiteralPath $configPath -PathType Leaf) {
        $config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($config.miniforge_root) {
            if ([IO.Path]::IsPathRooted($config.miniforge_root)) { $roots += $config.miniforge_root }
            else { $roots += Join-Path $PSScriptRoot $config.miniforge_root }
        }
    }
    $roots += Get-CondaRoot $env:CONDA_EXE
    $condaCommands = Get-Command conda.exe, conda.bat -CommandType Application -ErrorAction SilentlyContinue
    foreach ($command in $condaCommands) { $roots += Get-CondaRoot $command.Source }

    foreach ($hive in @('HKCU:', 'HKLM:')) {
        $uninstall = Join-Path $hive 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
        foreach ($entry in (Get-ItemProperty -Path $uninstall -ErrorAction SilentlyContinue)) {
            if ($entry.DisplayName -like 'Miniforge*') {
                if ($entry.InstallLocation) { $roots += $entry.InstallLocation }
                if ($entry.UninstallString -match '^\s*"?([^"]*Uninstall-Miniforge3\.exe)') {
                    $roots += Split-Path -Parent $Matches[1]
                }
            }
        }
    }
    foreach ($parent in @($env:USERPROFILE, $env:LOCALAPPDATA, $env:ProgramData, $env:ProgramFiles)) {
        if ($parent) { $roots += Join-Path $parent 'miniforge3' }
    }
    foreach ($root in ($roots | Where-Object { $_ } | Select-Object -Unique)) {
        $miniforge = Find-Miniforge $root
        if ($miniforge) { break }
    }
    if (-not $miniforge) {
        throw 'Install Miniforge for Windows and run Setup Environment.cmd again. For a custom installation, pass -Conda with the full path to its Scripts\conda.exe.'
    }
}

$pipelineArguments = @((Join-Path $PSScriptRoot 'bootstrap.py'), '--conda', $miniforge.Conda)
if ($Prefix) { $pipelineArguments += @('--prefix', $Prefix) }
if ($Rscript) { $pipelineArguments += @('--rscript', $Rscript) }
if ($CondaArchives) { $pipelineArguments += @('--conda-archives', $CondaArchives) }
if ($Wheelhouse) { $pipelineArguments += @('--wheelhouse', $Wheelhouse) }
if ($CABundle) { $pipelineArguments += @('--ca-bundle', $CABundle) }
if ($CheckOnline) { $pipelineArguments += '--check-online' }
if ($DryRun) { $pipelineArguments += '--dry-run' }

$previousPythonHome = $env:PYTHONHOME
$previousPythonPath = $env:PYTHONPATH
try {
    $env:PYTHONHOME = $null
    $env:PYTHONPATH = $null
    & $miniforge.Python -E -s @pipelineArguments
} finally {
    $env:PYTHONHOME = $previousPythonHome
    $env:PYTHONPATH = $previousPythonPath
}
if ($LASTEXITCODE -ne 0) {
    throw 'Setup did not finish. The message above explains the missing requirement.'
}

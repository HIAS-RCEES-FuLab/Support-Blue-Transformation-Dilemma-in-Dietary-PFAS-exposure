"""Build the 2020 serum comparison from saved model summaries and reported studies."""
import re

import numpy as np
import pandas as pd


COMPONENTS = ('PFOA', 'PFOS')
COMBINED = 'PFOA + PFOS'
SUM4 = 'PFOS + PFOA + PFHxS + PFNA'
TOTALS = {COMBINED: COMPONENTS, SUM4: (*COMPONENTS, 'PFHxS', 'PFNA')}
ANALYTES = {name.upper(): name for name in TOTALS[SUM4]}
METRICS = ['mean', 'median', 'geometric_mean']
STATISTIC_LABELS = {'mean': 'arithmetic means', 'median': 'medians',
                    'geometric_mean': 'geometric means'}
COUNTRIES = {
    'South Korea': 'Korea', 'Republic of Korea': 'Korea',
    'Korea (Republic of)': 'Korea', 'Turkey': 'Turkiye',
    'Czech Republic': 'Czechia', 'USA': 'United States', 'UK': 'United Kingdom',
    'Netherland': 'Netherlands', 'Swden': 'Sweden',
}
STUDY_KEYS = ['country', 'measurement_period', 'cohort', 'matrix',
              'statistic', 'metric_subgroup', 'reference', 'reference_title']
COLUMNS = ['country', 'chemical', 'measurement_period', 'cohort', 'matrix',
           'reported_metric', 'reported_value', 'reported_unit', 'measured_ng_ml',
           'predicted_2020_ng_ml', 'percent_difference', 'status', 'reference',
           'reference_title', 'statistic', 'aggregation']

METRIC_PATTERN = re.compile(r'\b(geometric\s+means?|g\s*[-_]?\s*means?|medians?|'
                            r'(?:weighted\s+|arithmetic\s+)?(?:means?|averages?))\b', re.I)


def reported_statistic(metric):
    match = METRIC_PATTERN.search(metric)
    if not match:
        return None
    label = match[0].lower()
    if label.startswith('geometric') or label.startswith('g'):
        return 'geometric_mean'
    if label.startswith('median'):
        return 'median'
    return 'mean'


def metric_subgroup(metric):
    """Keep cohort qualifiers recorded in the statistic and distinguish weighting."""
    match = METRIC_PATTERN.search(metric)
    qualifier = (metric[:match.start()] + ' ' + metric[match.end():]).strip().casefold()
    return ('weighted', qualifier) if 'weighted' in match[0].casefold() else ('', qualifier)


def period_distance(period):
    years = [int(year) for year in re.findall(r'(?<!\d)(?:19|20)\d{2}(?!\d)', period)]
    if len(years) == 1:
        short_end = re.search(r'(?:19|20)\d{2}\s*[-–—/]\s*(\d{2})(?!\d)', period)
        if short_end:
            end = years[0] // 100 * 100 + int(short_end[1])
            years.append(end if end >= years[0] else end + 100)
    return abs((min(years) + max(years)) / 2 - 2020) if years else np.inf


def pick_country_points(comparison):
    """Select by sampling period and study metadata independently of prediction error."""
    matched = comparison[comparison.status == 'matched_metric_country'].copy()
    matched['distance'] = matched.measurement_period.map(period_distance)
    matched['dedup_metric'] = matched.statistic.map(
        {'mean': 0, 'geometric_mean': 1, 'median': 2})
    order = ['distance', 'dedup_metric', 'reference_title', 'reference', 'cohort',
             'matrix', 'measurement_period', 'reported_metric']
    picked = matched.sort_values(order, kind='stable').drop_duplicates(['country', 'chemical'])
    return comparison.loc[comparison.index.isin(picked.index)].reset_index(drop=True)


def comparison_rows(measured, predictions):
    """Match the reported statistic and keep each eligible study observation."""
    components = predictions[predictions.chemical.isin(ANALYTES.values())]
    by_country = components.groupby(['country', 'chemical'])[METRICS].mean()
    by_replicate = components.pivot(index=['country', 'replicate'],
                                    columns='chemical', values=METRICS)
    combined_predictions = {
        (label, statistic): by_replicate[statistic].reindex(columns=chemicals).dropna()
        .sum(axis=1).groupby(level='country').mean()
        for label, chemicals in TOTALS.items()
        for statistic in METRICS
    }

    rows = []
    for _, record in measured.iterrows():
        chemical = ANALYTES.get(str(record['Analyte']).strip().upper())
        if chemical is None:
            continue
        original_country = str(record['Region/Country']).strip()
        country = COUNTRIES.get(original_country, original_country)
        metric = str(record['Metric']).strip()
        statistic = reported_statistic(metric)
        value = record['measured_ng_ml']
        unit = record['reported_unit']
        estimate = np.nan
        if statistic is not None and (country, chemical) in by_country.index:
            estimate = by_country.loc[(country, chemical), statistic]
        match = (unit == 'ng/mL' and np.isfinite(value) and value > 0
                 and np.isfinite(estimate) and estimate > 0)
        status = 'matched_metric_country' if match else 'unmatched'
        if unit != 'ng/mL':
            status = 'unit_conversion_required'
        rows.append({
            'country': country, 'chemical': chemical,
            'measurement_period': str(record['Years']).strip(),
            'cohort': str(record['Cohort Type']).strip(),
            'matrix': str(record['Matrix']).strip(), 'reported_metric': metric,
            'reported_value': record['reported_value'], 'reported_unit': unit,
            'measured_ng_ml': value,
            'predicted_2020_ng_ml': estimate if match else np.nan,
            'percent_difference': 100 * (estimate / value - 1) if match else np.nan,
            'status': status, 'reference': str(record['Reference (link)']).strip(),
            'reference_title': str(record.get('Reference (title)', '')).strip(),
            'statistic': statistic, 'aggregation': 'individual_compound',
        })

    comparison = pd.DataFrame(rows, columns=COLUMNS)
    matched = comparison[comparison.status == 'matched_metric_country'].copy()
    matched['metric_subgroup'] = matched.reported_metric.map(metric_subgroup)
    missing = ('', 'nan', 'none')
    by_title = matched[~matched.reference.str.casefold().isin(missing)].groupby(
        ['country', 'reference_title']).reference.unique()
    ambiguous = []
    for index, record in matched[matched.reference.str.casefold().isin(missing)].iterrows():
        if record.reference_title.casefold() not in missing:
            links = by_title.get((record.country, record.reference_title), ())
            if len(links) == 1:
                matched.at[index, 'reference'] = links[0]
            elif len(links) > 1:
                ambiguous.append(index)
    matched = matched.drop(index=ambiguous)
    rows = [row for row in rows if row['chemical'] in COMPONENTS]
    for keys, group in matched.groupby(STUDY_KEYS, sort=False):
        identity = dict(zip(STUDY_KEYS, keys))
        if all(identity[key].casefold() in missing
               for key in ('reference', 'reference_title')):
            continue
        if any(identity[key].casefold() in missing
               for key in ('measurement_period', 'cohort', 'matrix')):
            continue
        statistic = identity['statistic']
        weighted, subgroup = identity.pop('metric_subgroup')
        qualifiers = ' '.join(x for x in (subgroup, weighted) if x)
        metric = f'Sum of {STATISTIC_LABELS[statistic]}'
        if qualifiers:
            metric += f' ({qualifiers})'
        values = group.groupby('chemical').measured_ng_ml.unique()
        for label, chemicals in TOTALS.items():
            if any(c not in values or len(values[c]) != 1 for c in chemicals):
                continue
            estimate = combined_predictions[label, statistic].get(identity['country'], np.nan)
            if not np.isfinite(estimate) or estimate <= 0:
                continue
            value = sum(values[c][0] for c in chemicals)
            rows.append({**identity, 'chemical': label,
                         'reported_metric': metric, 'aggregation': 'sum_of_compound_statistics',
                         'reported_value': value, 'reported_unit': 'ng/mL',
                         'measured_ng_ml': value, 'predicted_2020_ng_ml': estimate,
                         'percent_difference': 100 * (estimate / value - 1),
                         'status': 'matched_metric_country'})

    return pd.DataFrame(rows, columns=COLUMNS)


def draw_comparison(ax, comparison, title='Measured and predicted serum concentrations'):
    matched = comparison[comparison.status == 'matched_metric_country']
    styles = [('o', '#176c94'), ('s', '#ca5b28'), ('D', '#486845'), ('^', '#795394')]
    for (chemical, (marker, color)) in zip((*COMPONENTS, *TOTALS), styles):
        points = matched[matched.chemical == chemical]
        if not points.empty:
            # Scatter sizes are areas in points squared.
            marker_area = 34 * 1.5**2 if chemical == SUM4 else 34
            ax.scatter(points.measured_ng_ml, points.predicted_2020_ng_ml,
                       label=chemical, marker=marker, color=color, alpha=.78,
                       s=marker_area, edgecolors='white', linewidths=.45, zorder=3)
    if not matched.empty:
        values = matched[['measured_ng_ml', 'predicted_2020_ng_ml']]
        limits = [float(values.min().min()) * .7, float(values.max().max()) * 1.3]
        ax.plot(limits, limits, '--', color='#6c7782', linewidth=1, zorder=2)
        ax.set(xscale='log', yscale='log', xlim=limits, ylim=limits, aspect='equal')
        ax.legend(frameon=False)
        ax.grid(True, which='major', color='#e2e7eb', linewidth=.7)
    ax.set(xlabel='Measured concentration (ng/mL)',
           ylabel='Predicted 2020 concentration (ng/mL)', title=title)
    ax.text(.5, -.15, 'Combined points sum matched compound means, medians, or geometric means.',
            transform=ax.transAxes, ha='center', va='top', fontsize=8, color='#465360')

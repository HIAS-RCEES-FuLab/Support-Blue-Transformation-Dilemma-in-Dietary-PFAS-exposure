"""Local calculation window with isolated, persistent job workers."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import argparse,hashlib,json,mimetypes,os,secrets,subprocess,sys,threading,time,traceback,urllib.parse,webbrowser
from common import *
from miniforge_runtime import managed_python
from health_overview import SUMMARY_NAME, TABLE_NAME, render_table
STAGES={'prepare': {'title': 'Environment & data', 'subtitle': 'Checks the included input files and required software, and opens any imported archives. Produces a readiness report before the calculation workflows begin.', 'deps': []}, 'us_edi': {'title': 'US historical EDI', 'subtitle': 'Combines annual US diets, trade flows and food concentrations using Monte Carlo simulation. Produces yearly dietary intake estimates and comparisons with the historical results.', 'deps': ['prepare']}, 'us_pbk': {'title': 'PBK for US PFOA & PFOS serum', 'subtitle': 'Uses historical dietary intakes in a physiological model with food bioavailability. Produces serum concentration estimates for four exposure scenarios and compares them with measured data.', 'deps': ['us_edi']}, 'baseline': {'title': '2020 exposure & HI', 'subtitle': 'Combines food concentrations, diets and trade flows using Monte Carlo simulation. Produces dietary exposure and hazard index summaries for countries, regions and the world.', 'deps': ['prepare']}, 'baseline_serum': {'title': '2020 health outcomes', 'subtitle': 'Converts dietary intakes to serum estimates, compares them with measured concentrations, and applies the supplied health models. Produces serum summaries and predicted health outcome differences.', 'deps': ['baseline']}, 'diets': {'title': '2050 diet pathways', 'subtitle': 'Compares the 2020 diet, LR diet, BAU diet and HR diet. Produces national consumption totals, food composition and population-weighted summaries.', 'deps': ['prepare']}, 'co2': {'title': 'CO₂ emissions & intensity', 'subtitle': 'Reweights archived Figure 4a emissions and edible-food estimates to report daily emissions and emissions intensity for 2020, LR, BAU and HR.', 'deps': ['prepare']}, 'future': {'title': '2050 exposure & health', 'subtitle': 'Combines projected diets, food concentrations and trade scenarios to estimate intake, serum and health changes. Produces country, regional and world summaries for each pathway.', 'deps': ['baseline', 'diets']}}
INTERACTIVE_RESULTS={'diet_trade_map.html','health_population_shift.html'}
RESULT_SUFFIXES={'.png','.pdf','.csv','.json','.log'}

def is_result(path):
 return path.name in INTERACTIVE_RESULTS or path.suffix.lower() in RESULT_SUFFIXES

LOCK=threading.RLock();ACTIVE=None;CHILD=None;TOKEN=secrets.token_urlsafe(32);CANCEL=False
INDEX=STATE/'latest.json'
def latest():
 records=read_json(INDEX,{})
 for record in records.values():
  run_id=record['run_id']
  if Path(run_id).name!=run_id or '/' in run_id or '\\' in run_id:raise ValueError('Invalid saved run ID')
  record['out']=str(RUNS/run_id)
 return records
def fingerprint(stage,opt):
 payload={'stage':stage,'options':opt,'assets':sha(MANIFEST),
          'code':{p.name:sha(p) for p in ROOT.glob('*.py')},'R':sha(ROOT/'r_runner.R'),
          'environment':environment_signature(),'rscript':str(find_rscript())}
 if opt['repeats']==7 and stage in ('baseline','baseline_serum','future'):
  payload['simulation_defaults']=sha(ROOT/'SIMULATION_DEFAULT.json')
 return hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
def state():
 with LOCK:
  result={'service':'bluefood-pipeline','instance_id':INSTANCE_ID,'stages':STAGES,'latest':latest(),'active':ACTIVE,'free_gib':round(shutil.disk_usage(WORKSPACE).free/1024**3,2),'resources':resource_limits(),'defaults':options(),'workspace':str(WORKSPACE)}
  if ACTIVE:
   result['active']=dict(ACTIVE);folder=Path(ACTIVE.get('out',STATE))
   result['active']['progress']=read_json(folder/'progress.json',{})
   p=folder/'run.log'
   if p.exists():
    with p.open('rb') as f:
     f.seek(max(0,p.stat().st_size-12000));result['active']['log']=f.read().decode('utf-8',errors='replace')
  return result
def run_one(stage,opt,force=False):
 global ACTIVE,CHILD
 if CANCEL:raise InterruptedError('Cancelled')
 dependencies={d:run_one(d,opt,False) for d in STAGES[stage]['deps']}
 fp=fingerprint(stage,opt);previous=latest().get(stage)
 if not force and previous and previous.get('fingerprint')==fp and (Path(previous['out'])/'COMPLETE.json').exists():
  if stage!='us_pbk':return previous
  try:validate_pbk_population(previous['out'])
  except (OSError,ValueError,TypeError):pass
  else:return previous
 need={'baseline':1.1,'future':3.1,'us_edi':.6,'us_pbk':.7}.get(stage,.15)*opt['repeats']
 if shutil.disk_usage(WORKSPACE).free/1024**3<need+1:raise OSError(f'{stage} needs about {need+1:.1f} GiB free including reserve. Earlier results are preserved.')
 run_id=time.strftime('%Y%m%d_%H%M%S')+'_'+stage+'_'+secrets.token_hex(2);folder=RUNS/run_id;folder.mkdir()
 request={'stage':stage,'options':opt,'dependencies':dependencies,'fingerprint':fp};write_json(folder/'request.json',request)
 with LOCK:ACTIVE={'stage':stage,'out':str(folder),'run_id':run_id,'status':'running','started_at':time.time()}
 env=os.environ.copy();env.pop('PYTHONPATH',None);env.update(PYTHONHASHSEED='0',PYTHONUTF8='1',PYTHONNOUSERSITE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',MPLBACKEND='Agg')
 with (folder/'run.log').open('w',encoding='utf-8') as log:
  CHILD=subprocess.Popen([sys.executable,'-u',str(ROOT/'worker.py'),'--stage',stage,'--out',str(folder),'--request',str(folder/'request.json')],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
  returncode=CHILD.wait();CHILD=None
 if CANCEL:raise InterruptedError('Calculation cancelled')
 if returncode or not (folder/'COMPLETE.json').exists():raise RuntimeError(read_json(folder/'FAILED.json',{}).get('error','Worker failed; see run.log'))
 record={'stage':stage,'out':str(folder),'run_id':run_id,'fingerprint':fp,'completed_at':time.time()}
 with LOCK:
  index=latest();index[stage]=record;write_json(INDEX,index)
 return record
def launch(stage,opt,force=False):
 global ACTIVE,CANCEL
 with LOCK:
  if ACTIVE and ACTIVE.get('status') in ['starting','running']:raise RuntimeError('A calculation is already running')
  ACTIVE={'stage':stage,'status':'starting','started_at':time.time()};CANCEL=False
 def work():
  global ACTIVE
  try:
   sequence=['prepare','diets','co2','baseline','us_edi','us_pbk','baseline_serum','future'] if stage=='all' else [stage]
   for item in sequence:record=run_one(item,opt,force)
   with LOCK:ACTIVE={'stage':stage,'status':'complete','out':record['out'],'run_id':record['run_id'],'completed_at':time.time()}
  except BaseException as exc:
   with LOCK:ACTIVE=dict(ACTIVE or {},status='cancelled' if isinstance(exc,InterruptedError) else 'failed',error=str(exc))
 threading.Thread(target=work,daemon=True).start()
def stop():
 global CANCEL
 CANCEL=True
 with LOCK:
  if ACTIVE and ACTIVE.get('out'):(Path(ACTIVE['out'])/'CANCEL').touch()
  child=CHILD
 if child and child.poll() is None:
  import psutil
  try:
   parent=psutil.Process(child.pid)
   for p in parent.children(recursive=True):p.terminate()
   parent.terminate()
  except psutil.NoSuchProcess:pass
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def send(self,data,code=200,kind='application/json'):
  if not isinstance(data,bytes):data=json.dumps(data,ensure_ascii=False,allow_nan=False).encode('utf-8')
  self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
  if self.path.startswith('/results/') and kind.startswith('text/html'):
   self.send_header('Content-Security-Policy',"sandbox allow-scripts; default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; frame-ancestors 'self'")
  self.end_headers();self.wfile.write(data)
 def valid_host(self):return self.headers.get('Host','').split(':')[0] in ['127.0.0.1','localhost']
 def do_GET(self):
  if not self.valid_host():return self.send({'error':'Localhost required'},403)
  path=urllib.parse.urlsplit(self.path).path
  if path=='/':return self.send((ROOT/'window.html').read_bytes().replace(b'__TOKEN__',TOKEN.encode()),kind='text/html; charset=utf-8')
  if path=='/api/state':return self.send(state())
  if path=='/api/files':
   query=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query);stage=query.get('stage',[''])[0];item=latest().get(stage)
   if not item:return self.send({'files':[]})
   folder=Path(item['out']);files=[{'name':p.name,'url':'/results/'+item['run_id']+'/'+urllib.parse.quote(p.name),'bytes':p.stat().st_size} for p in folder.iterdir() if p.is_file() and is_result(p)]
   if stage=='baseline_serum' and (folder/SUMMARY_NAME).is_file() and (ASSETS/'health/health_outcomes.json').is_file():
    files.append({'name':TABLE_NAME,'url':'/results/'+item['run_id']+'/'+TABLE_NAME,'bytes':0})
   return self.send({'files':files,'out':str(folder)})
  if path.startswith('/results/'):
   try:
    target=(RUNS/urllib.parse.unquote(path[len('/results/'):])).resolve();target.relative_to(RUNS.resolve())
    if target.name==TABLE_NAME:
     baseline=latest().get('baseline_serum')
     if not baseline or target.parent!=Path(baseline['out']).resolve() or target.parent.parent!=RUNS.resolve():
      return self.send({'error':'File not found'},404)
     manifest=ASSETS/'health/health_outcomes.json';summary=target.parent/SUMMARY_NAME
     if not manifest.is_file() or not summary.is_file():return self.send({'error':'File not found'},404)
     try:
      preview=render_table(summary,manifest)
     except (ValueError,KeyError,OSError):
      preview='<html lang="en"><meta charset="utf-8"><title>Health outcomes overview unavailable</title><p>The saved file does not contain a complete overview. Open the original chart or CSV above to inspect these results.</p></html>'
     return self.send(preview.encode('utf-8'),kind='text/html; charset=utf-8')
    if not target.is_file():return self.send({'error':'File not found'},404)
    # Only generated result artifacts are exposed, never source data, models or SSH keys.
    if not is_result(target):return self.send({'error':'Not a viewable result'},403)
    if target.name in INTERACTIVE_RESULTS:
     if target.parent.parent != RUNS.resolve():return self.send({'error':'Invalid interactive result path'},404)
     if target.name=='diet_trade_map.html':
      # Saved runs contain the map data as JSON. Display it with the current controls.
      start='<script type="application/json" id="data">'
      saved=target.read_text(encoding='utf-8')
      _,marker,embedded=saved.partition(start)
      payload,end,_=embedded.partition('</script>')
      if marker and end:
       data=json.loads(payload)
       template=(Path(__file__).with_name('assets')/'results_visuals/diet_trade_map.template.html').read_text(encoding='utf-8')
       serial=json.dumps(data,ensure_ascii=False,allow_nan=False,separators=(',',':')).replace('<','\\u003c')
       return self.send(template.replace('__MAP_PAYLOAD__',serial).encode('utf-8'),kind='text/html; charset=utf-8')
     return self.send(target.read_bytes(),kind='text/html; charset=utf-8')
    return self.send(target.read_bytes(),kind=mimetypes.guess_type(target.name)[0] or 'application/octet-stream')
   except (ValueError,OSError):return self.send({'error':'Invalid result path'},404)
  return self.send({'error':'Not found'},404)
 def do_POST(self):
  if not self.valid_host() or self.headers.get('X-BlueFood-Token')!=TOKEN:return self.send({'error':'Invalid request token'},403)
  try:
   n=int(self.headers.get('Content-Length','0'))
   if n>10000:raise ValueError('Request too large')
   data=json.loads(self.rfile.read(n))
   if self.path=='/api/run':
    stage=data['stage']
    if stage not in STAGES and stage!='all':raise ValueError('Unknown workflow')
    launch(stage,options(data.get('options')),bool(data.get('force',False)));return self.send({'status':'started'},202)
   if self.path=='/api/stop':stop();return self.send({'status':'cancelling'})
   if self.path=='/api/shutdown':
    stop();self.send({'status':'closing'});threading.Thread(target=self.server.shutdown,daemon=True).start();return
   return self.send({'error':'Not found'},404)
  except (ValueError,KeyError,RuntimeError) as exc:return self.send({'error':str(exc)},400)
def main():
 python=managed_python(sys.executable)
 p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=PORT);p.add_argument('--open',action='store_true');a=p.parse_args()
 server=ThreadingHTTPServer(('127.0.0.1',a.port),Handler);port=server.server_address[1]
 write_json(STATE/'server.json',{'service':'bluefood-pipeline','instance_id':INSTANCE_ID,'pid':os.getpid(),'port':port,'started_at':time.time(),'python':str(python)})
 if a.open:webbrowser.open('http://127.0.0.1:'+str(port))
 print('BlueFood pipeline ready: http://127.0.0.1:'+str(port),flush=True)
 try:server.serve_forever()
 finally:server.server_close()
if __name__=='__main__':main()

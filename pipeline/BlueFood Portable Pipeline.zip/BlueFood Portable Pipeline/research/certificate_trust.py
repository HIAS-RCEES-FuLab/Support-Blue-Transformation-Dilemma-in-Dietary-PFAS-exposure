"""Use a verified CA bundle for pipeline package installation and HTTPS."""

import os
from pathlib import Path
import ssl
import subprocess
from urllib.request import Request, urlopen


def certificate_bundle(prefix, configured=None):
    explicit = os.environ.get('BLUEFOOD_CA_BUNDLE') or configured
    if explicit:
        locations = [Path(os.path.expandvars(str(explicit))).expanduser()]
    else:
        prefix = Path(prefix)
        locations = [prefix / path for path in (
            'Library/ssl/cacert.pem', 'Library/ssl/cert.pem',
            'ssl/cacert.pem', 'ssl/cert.pem', 'etc/ssl/certs/ca-certificates.crt',
        )]
    for candidate in locations:
        if not candidate.is_file():
            continue
        try:
            context = ssl.create_default_context(cafile=str(candidate))
            count = context.cert_store_stats()['x509_ca']
            if count:
                return candidate.resolve(), count
        except (OSError, ssl.SSLError):
            if explicit:
                break
    location = str(explicit) if explicit else str(prefix)
    raise RuntimeError(f'No usable CA certificates found at {location}. Check Miniforge ca-certificates or supply a trusted PEM bundle.')


def certificate_environment(env, bundle):
    path = str(bundle)
    env.update(SSL_CERT_FILE=path, REQUESTS_CA_BUNDLE=path, CURL_CA_BUNDLE=path,
               PIP_CERT=path, CONDA_SSL_VERIFY=path)
    env.pop('PIP_TRUSTED_HOST', None)
    env.pop('R_LIBCURL_SSL_REVOKE_BEST_EFFORT', None)
    # Keep pip config from silently adding a trusted-host certificate bypass.
    env['PIP_CONFIG_FILE'] = os.devnull
    return env


def certificate_tools(env, prefix):
    folders = ('Library/bin', 'bin') if os.name == 'nt' else ('bin',)
    for tool in ('curl', 'openssl'):
        filename = tool + ('.exe' if os.name == 'nt' else '')
        for folder in folders:
            path = Path(prefix) / folder / filename
            if path.is_file():
                env['BLUEFOOD_' + tool.upper() + '_EXE'] = str(path.resolve())
                break
        else:
            raise RuntimeError(f'{tool} was not found in the Miniforge environment. Run Setup Environment again.')
    return env


def check_r_certificates(executable, script, env, bundle, online=False):
    command = [str(executable), '--vanilla', str(script), str(bundle)]
    if online:
        command.append('--online')
    reply = subprocess.run(command, env=env, capture_output=True, text=True, timeout=45)
    if reply.returncode:
        raise RuntimeError('R certificate check failed: ' + (reply.stderr.strip() or reply.stdout.strip()))
    return reply.stdout.strip()


def check_python_https(bundle):
    context = ssl.create_default_context(cafile=str(bundle))
    urls = ('https://pypi.org/simple/pip/', 'https://conda.anaconda.org/conda-forge/channeldata.json')
    for url in urls:
        try:
            with urlopen(Request(url, method='HEAD'), context=context, timeout=15) as response:
                if not response.url.startswith('https://'):
                    raise RuntimeError(f'HTTPS was redirected to a non-HTTPS URL: {response.url}')
        except OSError as error:
            raise RuntimeError(f'Could not verify HTTPS to {url}: {error}') from error
    return urls

from pathlib import Path
import ast,hashlib,importlib.util,json,os,sys,time,zipfile,shutil
from runtime import *
ensure_workspace()
RFD={'PFOS':2.,'PFHxS':20.0,'PFOA':3.,'PFDA':15.0,'PFDoDA':12.,'PFUnDA':12.0,'PFNA':3.}
CHEMS=list(RFD)
PBK_POPULATION={'PFOA':100000,'PFOS':100000}
GLOBAL_INPUT=ASSETS/'global/input_file'
R_ORIGINAL=ASSETS/'r'
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def read_json(p,default=None):return json.loads(Path(p).read_text(encoding='utf-8-sig')) if Path(p).exists() else default
def write_json(p,value):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
 # Windows readers/antivirus can briefly deny replacement of an open file.
 for attempt in range(80):
  try:os.replace(t,p);break
  except PermissionError:
   if attempt==79:raise
   time.sleep(min(.02*(attempt+1),.2))
def module(path,name):
 spec=importlib.util.spec_from_file_location(name,str(path));obj=importlib.util.module_from_spec(spec);sys.modules[name]=obj;spec.loader.exec_module(obj);return obj
def validate_pbk_population(out):
 """Accept only complete PBK summaries for the fixed 100,000-person populations."""
 import csv
 from decimal import Decimal,InvalidOperation
 out=Path(out);results=out/'R_job/results'
 def require_count(value,label):
  try:valid=not isinstance(value,bool) and Decimal(str(value))==100000
  except (InvalidOperation,ValueError):valid=False
  if not valid:raise ValueError(f'{label}: PBK requires 100,000 people; rerun the US serum stage')
 settings=read_json(results/'settings.json',{})
 if not isinstance(settings,dict):raise ValueError('Invalid PBK population settings; rerun the US serum stage')
 sizes=settings.get('population_n',{})
 if not isinstance(sizes,dict):raise ValueError('Missing PBK population settings; rerun the US serum stage')
 for compound in PBK_POPULATION:
  require_count(sizes.get(compound),compound+' population settings')
  result_settings=read_json(results/compound/'settings.json',{})
  if not isinstance(result_settings,dict):raise ValueError('Invalid '+compound+' result settings; rerun the US serum stage')
  require_count(result_settings.get('n'),compound+' result settings')
 scenarios=('no_exposure','aquatic_only','terrestrial_only','aquatic_plus_terrestrial')
 expected={(c,s,f'{y}-{y+1}') for c in PBK_POPULATION for s in scenarios for y in range(2003,2016,2)}
 for path in (results/'period_results.csv',out/'PFOA_PFOS_period_results.csv'):
  with path.open(newline='',encoding='utf-8-sig') as handle:rows=list(csv.DictReader(handle))
  keys={(r.get('compound'),r.get('scenario'),r.get('period')) for r in rows}
  if len(rows)!=len(expected) or keys!=expected:raise ValueError(f'{path.name}: incomplete PBK scenario/period results; rerun the US serum stage')
  for row in rows:require_count(row.get('n'),path.name+' '+str(row.get('compound')))
 return {'population_n':dict(PBK_POPULATION),'period_rows':len(expected)}
def functions(path,extra=None):
 tree=ast.parse(Path(path).read_text(encoding='utf-8-sig'))
 tree.body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Import,ast.ImportFrom))
            or isinstance(n,ast.Assign) and all(isinstance(t,ast.Name) and t.id in {'D_func','D_label','D_contaminatedregion'} for t in n.targets)]
 ns={'__name__':'__pipeline_functions__','__file__':str(path)};ns.update(extra or {})
 exec(compile(tree,str(path),'exec'),ns);return ns
def cancelled(out):
 if (Path(out)/'CANCEL').exists():raise InterruptedError('Calculation cancelled by user')
def event(out,message,progress=None):
 cancelled(out);print(message,flush=True)
 p={'message':message,'updated_at':time.time()}
 if progress is not None:p['progress']=progress
 write_json(Path(out)/'progress.json',p)
def extract_zip(archive,destination):
 """Idempotent extraction; never overwrite an already different source file."""
 archive=Path(archive);destination=Path(destination).resolve();destination.mkdir(parents=True,exist_ok=True)
 extracted=skipped=0
 with zipfile.ZipFile(archive) as z:
  total=sum(i.file_size for i in z.infolist())
  if total>max(0,shutil.disk_usage(destination).free-1024**3):raise OSError('Archive expansion would leave less than 1 GiB free')
  names=set()
  for info in z.infolist():
   clean=info.filename.replace('\\','/')
   if ':' in clean or clean.startswith('/') or '\x00' in clean:raise ValueError('Unsafe archive member: '+clean)
   target=(destination/clean).resolve();target.relative_to(destination)
   if str(target).casefold() in names:raise ValueError('Duplicate archive member: '+clean)
   names.add(str(target).casefold())
   if (info.external_attr>>16)&0o170000==0o120000:raise ValueError('Archive symlinks are not accepted')
   if info.is_dir():target.mkdir(parents=True,exist_ok=True);continue
   if target.exists():
    import binascii
    crc=0
    with target.open('rb') as f:
     for chunk in iter(lambda:f.read(1024*1024),b''):crc=binascii.crc32(chunk,crc)
    if target.stat().st_size!=info.file_size or crc&0xffffffff!=info.CRC:raise FileExistsError('Different extracted file already exists: '+str(target))
    skipped+=1;continue
   target.parent.mkdir(parents=True,exist_ok=True)
   with z.open(info) as src,target.open('xb') as dst:shutil.copyfileobj(src,dst)
   extracted+=1
 return {'archive':str(archive),'destination':str(destination),'extracted':extracted,'already_extracted':skipped}
def options(raw=None):
 limits=resource_limits()
 defaults=read_json(ROOT/'SIMULATION_DEFAULT.json',{})
 result={'seed':int(defaults.get('seed',301)),'repeats':1,'workers':limits['default_workers'],'historical_body_weight_kg':62,'global_body_weight_kg':62,
         'aquatic_factor':1,'pbk_grid':257,'health_batch':512}
 unknown=set(raw or {})-set(result)
 if unknown:raise ValueError('Unknown calculation options: '+', '.join(sorted(unknown)))
 result.update(raw or {})
 if isinstance(result['repeats'],bool) or result['repeats'] not in [1,7]:raise ValueError('Repeats must be 1 or 7')
 if isinstance(result['workers'],bool) or not isinstance(result['workers'],int) or not 1<=result['workers']<=limits['max_workers']:raise ValueError(f'Choose 1 to {limits["max_workers"]} workers for this computer')
 if isinstance(result['seed'],bool) or not isinstance(result['seed'],int) or not 0<=result['seed']<2**32-7:raise ValueError('Seed must be a nonnegative 32-bit integer with room for seven repeats')
 if result['global_body_weight_kg']!=62 or result['historical_body_weight_kg']!=62:raise ValueError('This workflow reports EDI at 62 kg body weight')
 if isinstance(result['health_batch'],bool) or not isinstance(result['health_batch'],int) or result['health_batch']<1:raise ValueError('Health batch size must be a positive integer')
 if isinstance(result['pbk_grid'],bool) or not isinstance(result['pbk_grid'],int) or result['pbk_grid']<33:raise ValueError('PBK grid size must be an integer of at least 33')
 if isinstance(result['aquatic_factor'],bool) or result['aquatic_factor']!=1:raise ValueError('This pipeline uses the supplied aquatic food concentrations at 1 fold')
 return result



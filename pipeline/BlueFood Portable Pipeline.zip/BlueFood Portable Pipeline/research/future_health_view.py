"""Plot paired changes in modeled PFAS-attributable effects as percentages."""

import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import textwrap

import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np
import pandas as pd


SCENARIOS = {
    "2050_LL_trade": "LR\nTrade",
    "2050_LL_Metatrade": "LR\nMetatrade",
    "2050_BAU_trade": "BAU\nTrade",
    "2050_BAU_Metatrade": "BAU\nMetatrade",
    "2050_HL_trade": "HR\nTrade",
    "2050_HL_Metatrade": "HR\nMetatrade",
}
SUMMARY_NAME = "regional_world_health_outcomes.csv"
OUTPUT_STEM = "health_outcomes"


def relative_health_data(summary, outcomes):
    """Use matched effects in the 2050 population and preserve change direction."""
    future_column = "mean_effect_vs_near_zero"
    change_column = "mean_change_from_2020"
    selecting = (
        summary["region"].eq("World")
        & summary["scenario"].isin(SCENARIOS)
        & summary["outcome"].isin(outcomes)
    )
    columns = ["outcome", "scenario", "replicate", future_column, change_column]
    world = summary.loc[selecting, columns].copy()
    keys = ["outcome", "scenario", "replicate"]
    expected = set(outcomes)
    if world.duplicated(keys).any() or set(world["outcome"]) != expected:
        raise ValueError("Expected one world health row per outcome, scenario and repeat")
    all_repeats = set(world["replicate"])
    expected_pairs = {(outcome, scenario) for outcome in outcomes for scenario in SCENARIOS}
    found_pairs = {
        (outcome, scenario): set(rows["replicate"])
        for (outcome, scenario), rows in world.groupby(["outcome", "scenario"], sort=False)
    }
    if found_pairs.keys() != expected_pairs or any(ids != all_repeats for ids in found_pairs.values()):
        raise ValueError("Incomplete 2050 outcome, scenario or repeat coverage")
    if not np.isfinite(world[[future_column, change_column]].to_numpy(dtype=float)).all():
        raise ValueError("A world health outcome is missing its paired 2020 Trade contrast")

    # The saved paired contrast uses identical patient covariates and population
    # weights for both years. A separately aggregated 2020 table uses 2020
    # population weights and would not recover the matched baseline.
    world["matched_2020_trade_effect"] = world[future_column] - world[change_column]
    metrics = world.groupby(["outcome", "scenario"], as_index=False).agg(
        mean_2050_effect=(future_column, "mean"),
        mean_paired_change=(change_column, "mean"),
        mean_matched_2020_trade_effect=("matched_2020_trade_effect", "mean"),
        repeats=("replicate", "size"),
    )
    denominator = metrics["mean_matched_2020_trade_effect"].abs()
    scale = metrics[["mean_2050_effect", "mean_paired_change"]].abs().max(axis=1)
    valid = denominator > 16 * np.finfo(float).eps * scale
    metrics["percent_change_vs_2020_trade"] = 100 * (
        metrics["mean_paired_change"] / denominator.where(valid)
    )
    metrics["status"] = np.where(valid, "ok", "undefined_zero_baseline")
    return metrics


def plot_future_health_summary(out, summary, outcome_info, outcomes, *, archived=False):
    """Render the new plot, PDF and calculation detail without rerunning models."""
    out = Path(out)
    data = relative_health_data(summary, outcomes)
    changes = data.pivot(index="outcome", columns="scenario", values="percent_change_vs_2020_trade")
    order = list(SCENARIOS)
    bar_colors = ["#168b83" if "Metatrade" not in scenario else "#bb9657" for scenario in order]
    nrows = (len(outcomes) + 2) // 3
    fig, axes = plt.subplots(nrows, 3, figsize=(15, 2.8 * nrows), squeeze=False)
    for ax, outcome in zip(axes.flat, outcomes):
        values = changes.loc[outcome, order].to_numpy(dtype=float)
        bars = ax.bar(range(len(order)), values, color=bar_colors, width=0.65)
        labels = [f'{value:+.1f}%' if np.isfinite(value) and round(value, 1) else
                  '0.0%' if np.isfinite(value) else '' for value in values]
        ax.bar_label(bars, labels=labels, padding=3, fontsize=7)
        ax.margins(y=.17)
        ax.axhline(0, color="#777", linewidth=0.6)
        ax.set_xticks(range(len(order)), [SCENARIOS[c] for c in order], fontsize=7)
        ax.set_title(textwrap.fill(outcome_info[outcome]["display_name"], 40), loc="left", fontsize=10)
        ax.set_ylabel("Change vs 2020 Trade", fontsize=7)
        ax.yaxis.set_major_formatter(PercentFormatter(xmax=100))
        ax.tick_params(axis="y", labelsize=8)
        for index in np.flatnonzero(~np.isfinite(values)):
            ax.annotate("N/A", (index, 0), xytext=(0, 3), textcoords="offset points",
                        ha="center", va="bottom", fontsize=7, color="#5a5a5a")
    for ax in list(axes.flat)[len(outcomes):]:
        ax.set_visible(False)
    title = "2050 changes in modeled PFAS-attributable health effects"
    if archived:
        title = "Archived results · " + title
    fig.suptitle(
        title + "\nChange as a percent of the matched 2020 Trade effect magnitude · population-weighted",
        fontsize=13,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.97), h_pad=2, w_pad=2)
    try:
        with TemporaryDirectory(prefix="health-plot-", dir=out) as tmp:
            staging = Path(tmp)
            figures = [f"{OUTPUT_STEM}.png", f"{OUTPUT_STEM}.pdf"]
            for name in figures:
                fig.savefig(staging / name, bbox_inches="tight")
            details = "health_outcome_percentage_changes.csv"
            data.insert(1, "outcome_name", data["outcome"].map(lambda o: outcome_info[o]["display_name"]))
            data.to_csv(staging / details, index=False)
            for name in figures + [details]:
                (staging / name).replace(out / name)
    finally:
        plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description="Refresh the 2050 health figures from an existing completed run.")
    parser.add_argument("run_dir", type=Path, help="Future-stage directory containing the saved health summary CSV")
    parser.add_argument("--summary", type=Path, help="Read an alternative saved health summary CSV")
    parser.add_argument("--outcome-manifest", type=Path, default=Path(__file__).with_name("assets") /
                        "health" / "health_outcomes.json", help="Use the same outcome list as the saved run")
    parser.add_argument("--output", type=Path, help="Write the refreshed plots to a separate directory")
    parser.add_argument("--archived", action="store_true", help="Identify the plot as an archived example")
    args = parser.parse_args()
    manifest = json.loads(args.outcome_manifest.read_text(encoding="utf-8-sig"))
    summary = pd.read_csv(args.summary or args.run_dir / SUMMARY_NAME)
    output = args.output or args.run_dir
    output.mkdir(parents=True, exist_ok=True)
    info = {item["code"]: item for item in manifest["health_outcomes"]}
    plot_future_health_summary(output, summary, info, manifest["outcomes"], archived=args.archived)


if __name__ == "__main__":
    main()

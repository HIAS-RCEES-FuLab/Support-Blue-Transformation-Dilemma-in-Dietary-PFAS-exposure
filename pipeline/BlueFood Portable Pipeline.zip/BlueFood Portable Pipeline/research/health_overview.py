"""Display the archived 2020 health outcomes without running the model."""

import argparse
import csv
from decimal import Decimal, InvalidOperation
from html import escape
import json
from pathlib import Path


TABLE_NAME = 'health_outcomes_table.html'
SUMMARY_NAME = 'regional_world_health_outcomes.csv'
CONTRAST = 'Population-weighted world mean differences for 2020 Trade versus the near-zero serum reference.'
SHARE_NOTE = 'Population shares show the percentage of modeled individuals whose change follows the direction shown in Trend.'
FRACTION_COLUMNS = {'Increase': 'fraction_increase', 'Decrease': 'fraction_decrease', 'No change': 'fraction_unchanged'}


def read_fraction(value):
    if value is None or not value.strip():
        return None
    try:
        fraction = Decimal(value)
    except InvalidOperation:
        return None
    return fraction if fraction.is_finite() and 0 <= fraction <= 1 else None


def effects_by_outcome(summary_path, manifest_path):
    manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'))
    order = manifest['outcomes']
    labels = {record['code']: record['display_name'] for record in manifest['health_outcomes']}
    if len(order) != 36 or set(order) != labels.keys():
        raise ValueError('The health outcome definitions must cover the 36 reported outcomes.')

    values = {code: {} for code in order}
    fractions = {code: {} for code in order}
    units = {}
    with summary_path.open(encoding='utf-8-sig', newline='') as source:
        for row in csv.DictReader(source):
            if row['scenario'] != '2020_trade' or row['region'] != 'World':
                continue
            code, replicate, unit = row['outcome'], row['replicate'], row['unit']
            if code not in values:
                continue
            if not replicate or not unit or replicate in values[code]:
                raise ValueError(f'Invalid or duplicate health result for {code}.')
            if units.setdefault(code, unit) != unit:
                raise ValueError(f'Health result for {code} has conflicting units.')
            try:
                value = Decimal(row['mean_effect_vs_near_zero'])
            except InvalidOperation as error:
                raise ValueError(f'Invalid health result for {code}.') from error
            if not value.is_finite():
                raise ValueError(f'Non-finite health result for {code}.')
            values[code][replicate] = value
            fractions[code][replicate] = {column: read_fraction(row.get(column)) for column in FRACTION_COLUMNS.values()}

    repeats = set(values[order[0]])
    if not repeats or any(result.keys() != repeats for result in values.values()):
        raise ValueError('The saved health result does not contain the same repeats for all 36 outcomes.')

    outcomes = []
    for code in order:
        mean = sum(values[code].values()) / len(repeats)
        trend = 'Increase' if mean > 0 else 'Decrease' if mean < 0 else 'No change'
        shares = [result[FRACTION_COLUMNS[trend]] for result in fractions[code].values()]
        percent = 100 * sum(shares) / len(shares) if all(share is not None for share in shares) else None
        outcomes.append({
            'health_outcome': labels[code],
            'code': code,
            'mean_difference': str(mean),
            'unit': units[code],
            'trend': trend,
            'population_percent_same_trend': str(percent) if percent is not None else '',
            'display_population_percent_same_trend': f'{percent:.1f}%' if percent is not None else 'Not available',
            'display_mean_difference': format_effect(mean),
            'repeats': len(repeats),
        })
    return outcomes


def format_effect(value):
    value = Decimal(value)
    if value.is_zero():
        return '0'
    # Four significant digits and a fixed decimal representation for tabular reading.
    return format(Decimal(format(value, '.4g')).normalize(), 'f').replace('-', '−')


def render_table(summary_path, manifest_path):
    outcomes = effects_by_outcome(summary_path, manifest_path)
    repeat_count = outcomes[0]['repeats']
    repeat_note = f' Values are averages across {repeat_count} repeats.' if repeat_count > 1 else ''
    table_rows = ''.join(
        '<tr><th scope="row">' + escape(outcome['health_outcome']) + '</th>'
        '<td class="code">' + escape(outcome['code']) + '</td>'
        '<td class="effect" title="' + escape(outcome['mean_difference']) + '">'
        + escape(outcome['display_mean_difference']) + '</td>'
        '<td>' + escape(outcome['unit']) + '</td>'
        '<td>' + escape(outcome['trend']) + '</td>'
        '<td class="effect">' + escape(outcome['display_population_percent_same_trend']) + '</td></tr>'
        for outcome in outcomes
    )
    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>2020 health outcomes overview</title>
<style>
*{{box-sizing:border-box}}:root{{font:14px/1.45 "Segoe UI",Arial,sans-serif;color:#223b36;background:#fbfcf9}}
body{{height:100vh;margin:0;padding:16px;display:flex;flex-direction:column}}
h1{{margin:0 0 5px;font-size:18px}}p{{margin:0 0 14px;color:#426259;font-size:12px}}
.results{{flex:1 1 auto;min-height:0;overflow:auto;border:1px solid #c9dcd4;border-radius:8px;background:#fff;scrollbar-color:#4e7b6e #eaf0e9}}
.results:focus-visible{{outline:2px solid #146459;outline-offset:2px}}
table{{border-collapse:separate;border-spacing:0;width:100%;text-align:left;font-size:12px}}
thead{{position:sticky;top:0;background:#e5efeb;color:#1d5045}}th,td{{padding:8px 10px;vertical-align:middle;border-bottom:1px solid #e5ece7}}
thead th{{border-bottom-color:#b6d1c7;white-space:nowrap}}tbody th{{font-weight:500}}tbody tr:nth-child(even){{background:#f6f9f7}}
tbody tr:last-child>*{{border-bottom:0}}.effect{{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}}.code{{white-space:nowrap;color:#36584e}}
@media(max-width:480px){{body{{padding:10px}}th,td{{padding:6px}}}}
</style></head><body>
<h1 id="heading">2020 health outcomes overview</h1><p id="contrast">{escape(CONTRAST + repeat_note)} {escape(SHARE_NOTE)}</p>
<div class="results" tabindex="0" role="region" aria-labelledby="heading">
<table aria-describedby="contrast"><thead><tr><th scope="col">Health outcome</th><th scope="col">Outcome code</th>
<th scope="col" class="effect">Mean difference</th><th scope="col">Unit</th><th scope="col">Trend</th>
<th scope="col" class="share">Percent of population in the same trend</th></tr></thead>
<tbody>{table_rows}</tbody></table></div></body></html>'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('summary', type=Path)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--editable', type=Path)
    options = parser.parse_args()
    outcomes = effects_by_outcome(options.summary, options.manifest)
    with options.output.open('w', newline='', encoding='utf-8-sig') as output:
        writer = csv.DictWriter(output, fieldnames=list(outcomes[0]))
        writer.writeheader()
        writer.writerows(outcomes)
    if options.editable:
        with options.editable.open('w', newline='', encoding='utf-8-sig') as output:
            writer = csv.writer(output)
            writer.writerow(['Health outcome', 'Outcome code', 'Mean difference', 'Unit', 'Trend', 'Percent of population in the same trend'])
            for row in outcomes:
                writer.writerow([row['health_outcome'], row['code'], row['mean_difference'],
                                 row['unit'], row['trend'], row['population_percent_same_trend'] or 'Not available'])


if __name__ == '__main__':
    main()

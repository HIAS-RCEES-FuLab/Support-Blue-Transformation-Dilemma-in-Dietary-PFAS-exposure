# -*- coding: utf-8 -*-
"""
Created on Mon Aug  4 14:53:48 2025

@author: huboy
"""
import time
import datetime
#time.sleep(3600*7.5)
print(datetime.datetime.now())
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gmean
from scipy.optimize import root
def solve0(a, b):
    def f(x):
        return np.exp(x*b/a + np.log(a) -1) - x
    t = root(f, x0=0)['x'][0]
    print(t)
    x = np.arange(0,1000,0.01)
    a1 = np.exp(x*t)
    a2 = a*x+b
    plt.plot(x, a1)
    plt.plot(x, a2)
    plt.show()
    return


''' read the exposure of 7 PFASs '''
def read_expo(path, filename, L_PFASs = None):
    if L_PFASs ==  None:
        L_PFASs = ['PFHxS','PFOS','PFNA','PFOA', 'PFUnDA','PFDA','PFDoDA']
    df = pd.read_csv(path+filename)
    D_expo = {}
    for PFAS in L_PFASs:
        D_expo[PFAS] = df[PFAS]
        np.sort(D_expo[PFAS])
        D_expo[PFAS] = D_expo[PFAS]
    return D_expo

''' read serum level '''
def read_serum(path, filename, sheet):
    D_serum = pd.read_excel(path+filename, index_col='SEQN' , sheet_name=sheet)
    return D_serum

''' functions of exposure vs serum '''
def renormalization(serum, g_std):
    old_sd = np.std( np.log(serum) )
    logave = np.log( gmean(serum) )
    return np.exp( (np.log(serum) - logave)/old_sd*g_std + logave )

def PFOA(expo):
    x1 = 7.22613504913939*(expo/63)**1.27321697445463
    x2 = 7.63193028314647*(expo/63) +-0.80058770351775   #10.675354
    th = 25.75 #(expo)
    g_std = 0.286968
    a = np.ones_like(expo)
    a[expo<=th] = x1[expo<=th]
    a[expo>th] = x2[expo>th]
    return renormalization(a, g_std)
def PFDO(expo):
    x1 = 4.24097389755964*(expo/63)**1.84270607350659
    x2 = 2.37628826442755*(expo/63) + -0.204383892936057
    g_std = 0.091088
    th = 8.08
    a = np.ones_like(expo)
    a[expo<=th] = x1[expo<=th]
    a[expo>th] = x2[expo>th]
    return renormalization(a, g_std)
def PFUA(expo):
    #x1 = 0.262759514494733*(expo/63)**0.410944959047275
    x2 = 0.180973534312604*(expo/63) +0.103365108663515
    g_std = 0.29973
    #th = 57.499
    #a = np.ones_like(expo)
    #a[expo<=th] = x1[expo<=th]
    #a[expo>th] = x2[expo>th]
    return renormalization(x2, g_std)
def PFDE(expo):
    #x1 = 0.600292743105055*(expo/63)**0.54589954394883
    x2 = 0.648790718294605*(expo/63) +0.115520056436062
    g_std = 0.316053
    #th = 51.6
    #a = np.ones_like(expo)
    #a[expo<=th] = x1[expo<=th]
    #a[expo>th] = x2[expo>th]
    return renormalization(x2, g_std)
def PFNA(expo):
    x1 = 2.97467284262077*(expo/63)**0.992642798750788
    x2 = 3.0190958941266*(expo/63) +-0.00647545505364988
    g_std = 0.301027
    th = 21.226
    a = np.ones_like(expo)
    a[expo<=th] = x1[expo<=th]
    a[expo>th] = x2[expo>th]
    return renormalization(a, g_std)
def PFOS(expo):
    x1 = 1.46574641733492*(expo/63)**0.98073879728117
    x2 = 1.41267517386356*(expo/63) +-0.0966110476175697
    g_std = 0.352850
    th = 635.087
    a = np.ones_like(expo)
    a[expo<=th] = x1[expo<=th]
    a[expo>th] = x2[expo>th]
    return renormalization(a, g_std)
def PFHS(expo):
    x1 = 2.52183653153458*(expo/63)**0.257062135802175
    x2 = 3.34874735888277*(expo/63) +0.990564779916881
    g_std = 0.416235
    th = 3.03
    a = np.ones_like(expo)
    a[expo<=th] = x1[expo<=th]
    a[expo>th] = x2[expo>th]
    return renormalization(a, g_std)
    #1.0768e-2 * expo # #4.648e-2 * expo - 47.541 + 13.94 + 7.02 #10**( 4.3007 * np.log10(expo) - 12.32 )/2.15*7.02
D_func = {'PFHxS':PFHS,'PFOS':PFOS,'PFNA':PFNA,'PFOA':PFOA, 'PFUnDA':PFUA,'PFDA':PFDE,'PFDoDA':PFDO}
D_label = {'PFHxS':'LBXPFHS','PFOS':'LBXPFOS','PFNA':'LBXPFNA','PFOA':'LBXPFOA', 'PFUnDA':'LBXPFUA',
           'PFDA':'LBXPFDE','PFDoDA':'LBXPFDO', 'total':'total'}
#['LBXPFHS','LBXPFOS','LBXPFNA','LBXPFOA''LBXPFUA','LBXPFDE','LBXPFDO']
''' predict serum level '''
path = 'F:/blue food diet simulation results 0105/'
serumpath = 'F:/NHANEs 2003-2016 (add 2018)/conditioned patients/'

def read_chem_ava(path, file='avalible chems by country.xlsx'):
    df = pd.read_excel(path+file)
    D = {}
    for chem in df:
        D[chem] = [c for c in df[chem] if type(c) == str]
    return D

import os
D_country_chem = read_chem_ava(path, file='avalible chems by country.xlsx')

#for country in D_country_chem:
L_country = iter([c for c in D_country_chem])
for country in L_country:
    #serumfile = 'data_outcome by classification.xlsx'
    def check_distributions():
        def check_PFOS():
            D_serum = read_serum(serumpath, serumfile)
            a = D_serum['LBXPFOS'][:10000]
            print(gmean(a),np.mean(a))
            serum = np.log10(D_serum['LBXPFOS']+0.001)
            plt.hist(serum, bins=100, alpha=0.3, color='grey')
            
            D_expo = read_expo(path, expofile_2020)
            for chem in ['PFOS']:
                expo = D_expo[chem]
                line = D_func[chem]
                conc = line(expo)
                print(gmean(conc),np.mean(conc))
                plt.hist(np.log10(conc), bins=1000, alpha=0.5)
            
            return
        
        def check_PFOA():
            D_serum = read_serum(serumpath, serumfile)
            a = D_serum['LBXPFOA'][:10000]
            print(gmean(a),np.mean(a))
            serum = np.log10(D_serum['LBXPFOA']+0.001)
            plt.hist(serum, bins=100, alpha=0.3, color='grey')
            
            D_expo = read_expo(path, expofile_2020)
            for chem in ['PFOA']:
                expo = D_expo[chem]
                line = D_func[chem]
                conc = line(expo)
                print(gmean(conc),np.mean(conc))
                plt.hist(np.log10(conc), bins=1000, alpha=0.5)
            
            return
        
        def check_PFNA():
            D_serum = read_serum(serumpath, serumfile)
            a = D_serum['LBXPFNA'][:10000]
            print(gmean(a))
            serum = np.log10(D_serum['LBXPFNA']+0.001)
            plt.hist(serum, bins=200, alpha=0.3, color='grey')
            
            D_expo = read_expo(path, expofile_2020)
            for chem in ['PFNA']:
                expo = D_expo[chem]
                line = D_func[chem]
                conc = line(expo)
                print(gmean(conc))
                plt.hist(np.log10(conc), bins=1000, alpha=0.5)
            return
        
        def check_PFDE():
            D_serum = read_serum(serumpath, serumfile)
            a = D_serum['LBXPFDE'][:10000]
            print(gmean(a))
            serum = np.log10(D_serum['LBXPFDE']+0.001)
            plt.hist(serum, bins=200, alpha=0.3, color='grey')
            
            D_expo = read_expo(path, expofile_2020)
            for chem in ['PFDA']:
                expo = D_expo[chem]
                line = D_func[chem]
                conc = line(expo)
                print(gmean(conc))
                plt.hist(np.log10(conc), bins=100, alpha=0.5)
                
            return
        
        def check_PFDO():
            D_serum = read_serum(serumpath, serumfile)
            a = D_serum['LBXPFDO'][:10000]
            print(gmean(a))
            serum = np.log10(D_serum['LBXPFDO']+0.001)
            plt.hist(serum, bins=200, alpha=0.3, color='grey')
            
            D_expo = read_expo(path, expofile_2020)
            for chem in ['PFDoDA']:
                expo = D_expo[chem]
                line = D_func[chem]
                conc = line(expo)
                print(gmean(conc))
                plt.hist(np.log10(conc), bins=100, alpha=0.5)
            
            return
        
        def check_PFHS():
            D_serum = read_serum(serumpath, serumfile)
            a = D_serum['LBXPFHS'][:10000]
            print(gmean(a))
            serum = np.log10(D_serum['LBXPFHS']+0.001)
            plt.hist(serum, bins=50, alpha=0.3, color='grey')
            
            D_expo = read_expo(path, expofile_2020)
            for chem in ['PFHxS']:
                expo = D_expo[chem]
                line = D_func[chem]
                conc = line(expo)
                print(gmean(conc),np.mean(conc))
                plt.hist(np.log10(conc), bins=1000, alpha=0.5)
                
            return
        
        def check_PFUA():
            D_serum = read_serum(serumpath, serumfile)
            a = D_serum['LBXPFUA'][:10000]
            print(gmean(a))
            serum = np.log10(D_serum['LBXPFUA']+0.001)
            plt.hist(serum, bins=200, alpha=0.3, color='grey')
            
            D_expo = read_expo(path, expofile_2020)
            for chem in ['PFUnDA']:
                expo = D_expo[chem]
                line = D_func[chem]
                conc = line(expo)
                print(gmean(conc))
                plt.hist(np.log10(conc), bins=100, alpha=0.5)
            
            return
        print('PFOS')
        check_PFOS()
        print('PFOA')
        check_PFOA()
        print('PFHS')
        check_PFHS()
        return
    
    def caliberate():
        path = 'G:/projects/BLUE FOOD/causal_dose response/predict_exposure2050/'
        file = 'caliberation.xlsx'
        df = pd.read_excel(path+file)
        L_PFASs = ['PFHxS'] #['PFHxS','PFOS','PFNA','PFOA', 'PFUnDA','PFDA','PFDoA']
        from scipy.optimize import curve_fit
        def f_line(x, a,b):
            return a*x+b
        def f_exp(x, a, b, c):
            return b*x**a
        for PFAS in L_PFASs:
            ind = [i for i in range(7000)] + [i+8649 for i in range(100)]
            x = df[PFAS][:8000]
            y = df[PFAS+'_serum'][:8000]
            y_0 = np.log10(y)
            x_0 = np.log10(x)
            params, cov = curve_fit(f_line, x_0, y_0)
            params1, cov = curve_fit(f_exp, x, y, p0 = [params[0], np.exp(params[1]), 0], bounds=(0, np.inf))
            print(PFAS, params1)
            x0 = np.arange(0,np.max(x),0.03)
            plt.scatter(x, y, alpha=0.2)
            plt.plot(x0, f_exp(x0, params1[0], params1[1], params1[2]))
            
        return
    
    #caliberate()
    
    def mapping(D_serum, pred_serum, PFAS):
        import matplotlib.pyplot as plt
        D_serum = D_serum.sort_values(by=PFAS, axis=0, ascending=True)
        L1 = D_serum[PFAS]
        pred_serum_ = np.random.choice( pred_serum, len(D_serum[PFAS]))
        pred_serum_.sort()
        #print(D_serum[PFAS] , pred_serum_)
        #plt.scatter(D_serum[PFAS][:8000], pred_serum_[:8000])
        #plt.show()
        D_serum[PFAS] = pred_serum_
        L2 = D_serum[PFAS]
        #plt.scatter(L1,L2)
        #plt.title(PFAS)
        #plt.show()
        return D_serum
    
    def predict_serum(serumpath, serumfile, sheet, expofile, L):
        #L = ['PFHxS','PFOS','PFOA']
        #['PFHxS','PFOS','PFNA','PFOA','PFUnDA','PFDA','PFDoA']
        D_serum = read_serum(serumpath, serumfile, sheet)
        D_expo = read_expo(path, expofile, L_PFASs=L)
        for PFAS in L:
            labelPFAS = D_label[PFAS]
            function = D_func[PFAS]
            D_serum = mapping(D_serum, function(D_expo[PFAS]), labelPFAS)      
        return D_serum
    
    def save_predict_serum(D_serum, path, filename):
        D_save = {}
        D_save['SEQN'] = D_serum.index
        total = 0
        for PFAS in ['PFHxS','PFOS','PFNA','PFOA','PFUnDA','PFDA','PFDoDA']:
            labelPFAS = D_label[PFAS]
            D_save[labelPFAS] = D_serum[labelPFAS]
            total = np.array(D_serum[labelPFAS])+total
        D_save['total'] = total
        df_save = pd.DataFrame(D_save)
        df_save.to_excel(path+filename)
        return df_save
    
    def save_predict_serum_stats(df_save, path, filename):
        D_stats = {}
        for PFAS in ['PFHxS','PFOS','PFNA','PFOA','PFUnDA','PFDA','PFDoDA','total']:
            labelPFAS = D_label[PFAS]
            arr = np.array(df_save[labelPFAS])
            arr = np.sort(arr)
            D_stats[PFAS] = [np.mean(arr), np.std(arr), gmean(arr), arr[int(len(arr)*0.5)], arr[int(len(arr)*0.75)], arr[int(len(arr)*0.9)], arr[int(len(arr)*0.95)]]
        df_savestat = pd.DataFrame(D_stats)
        df_savestat.index = ['mean','sd','gmean','50','75','90','95']
        df_savestat.to_excel(path+filename)
        return
    
    #while country in ["Australia", 'Austria', 'Belgium', 'Bulgaria', 'Canada', 'Chile', 'Croatia', 'Czechia', 'Denmark', 'Estonia', 'Finland', 'France', 'Germany' ]:
    #    country = next(L_country)
    print(country)
    expofile_2020 = '2020_trade_total_exposure/N100000_'+country+'_expo.csv'
    expofile_BAU = '2050_BAU_trade_total_exposure/N100000_'+country+'_expo.csv'
    expofile_BAUMeta = '2050_BAU_Metatrade_total_exposure/N100000_'+country+'_expo.csv'
    expofile_HL = '2050_HL_trade_total_exposure/N100000_'+country+'_expo.csv'
    expofile_HLMeta = '2050_HL_Metatrade_total_exposure/N100000_'+country+'_expo.csv'
    expofile_LL = '2050_LL_trade_total_exposure/N100000_'+country+'_expo.csv'
    expofile_LLMeta = '2050_LL_Metatrade_total_exposure/N100000_'+country+'_expo.csv'
    L_expofile = [expofile_2020, expofile_BAU, expofile_BAUMeta, expofile_HL, expofile_HLMeta,
                  expofile_LL, expofile_LLMeta]
    L_head = ['2020', 'BAU', 'BAUMeta', 'HL', 'HLMeta', 'LL', 'LLMeta']
    
    savepath = 'H:/projects/BLUE FOOD/causal_dose response/predict_exposure2050_260105/continuous/'+country #/BPQ020/MCQ160A/continuous
    os.makedirs(savepath, exist_ok=True)
    savepath = savepath+'/'
    #serumfile = 'data_outcome by classification (clearned and specific).xlsx'
    serumfile = 'data_outcome by regression.xlsx'
    predfile = 'predicted serum level.xlsx'
    L = D_country_chem[country]
    
    for i in range(len(L_head)):
        head = L_head[i]
        expofile = L_expofile[i]
        D_serum = predict_serum(serumpath, serumfile, 'data_outcome by regression', expofile, L)
        df_save = save_predict_serum(D_serum, savepath, head + predfile)
        save_predict_serum_stats(df_save, savepath, head+'_stats_'+predfile)
        del(D_serum)
        del(df_save)
    print(datetime.datetime.now())
    
    savepath = 'H:/projects/BLUE FOOD/causal_dose response/predict_exposure2050_260105/BPQ020/'+country #/BPQ020/MCQ160A/continuous
    os.makedirs(savepath, exist_ok=True)
    savepath = savepath+'/'
    serumfile = 'data_outcome by classification (clearned and specific).xlsx'
    #serumfile = 'data_outcome by regression.xlsx'
    predfile = 'predicted serum level.xlsx'
    L = D_country_chem[country]
    
    for i in range(len(L_head)):
        head = L_head[i]
        expofile = L_expofile[i]
        D_serum = predict_serum(serumpath, serumfile, 'BPQ020', expofile, L)
        df_save = save_predict_serum(D_serum, savepath, head + predfile)
        save_predict_serum_stats(df_save, savepath, head+'_stats_'+predfile)
        del(D_serum)
        del(df_save)
    print(datetime.datetime.now())
    
    savepath = 'H:/projects/BLUE FOOD/causal_dose response/predict_exposure2050_260105/MCQ160A/'+country #/BPQ020/MCQ160A/continuous
    os.makedirs(savepath, exist_ok=True)
    savepath = savepath+'/'
    serumfile = 'data_outcome by classification (clearned and specific).xlsx'
    #serumfile = 'data_outcome by regression.xlsx'
    predfile = 'predicted serum level.xlsx'
    L = D_country_chem[country]
    
    for i in range(len(L_head)):
        head = L_head[i]
        expofile = L_expofile[i]
        D_serum = predict_serum(serumpath, serumfile, 'MCQ160A', expofile, L)
        df_save = save_predict_serum(D_serum, savepath, head + predfile)
        save_predict_serum_stats(df_save, savepath, head+'_stats_'+predfile)
        del(D_serum)
        del(df_save)
    print(datetime.datetime.now())
    
#solve0(a = 6.8197e-2 , b = - 47.541)
#check_distributions()
def test_bound(f):
    a = np.arange(-3,4,0.0001)
    x = 10**a
    print( np.min(x[f(x)[1]>f(x)[0]] ) )
    return
#test_bound(PFOS)
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 21 16:15:56 2025

@author: huboy
"""
import os
from scipy.stats import norm
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt
import numpy as np
# Use defaults
import pandas
import random
import warnings
from sklearn.utils.class_weight import compute_class_weight

warnings.simplefilter('ignore')
def ifAllInt(L):
    Yes = True
    for x in L:
        if x != int(x):
            Yes = False
            break
    return Yes

def read_taginfo(path, filename):
    D_info = dict()
    with open(path+filename, mode='r', encoding='utf-8-sig') as file:
        Info = False
        for line in file:
            if 'row' in line:
                Info = True
                if 'classification' in line:
                    row_number = int( line.split(' ')[2] )
                    info = [row_number, 'classification']
                elif 'regression' in line:
                    row_number = int( line.split(' ')[2] )
                    info = [row_number, 'regression']
            elif Info and 'row' not in line:
                score = float( line.split(' ')[0] )
                info.append( score )
                D_info[info[0]] = [info[1], info[2]]
                Info = False
            else:
                pass
                    
    return D_info

def get_info(D_info, class_th=0.9, reg_th=0.49):
    L_rownumber = []
    for num in D_info:
        if D_info[num][0] == 'classification':
            if D_info[num][1] >= class_th and D_info[num][1] != 1:
                L_rownumber.append(num)
        elif D_info[num][0] == 'regression' and D_info[num][1] != 1:
            if D_info[num][1] >= reg_th:
                L_rownumber.append(num)
    return L_rownumber
    
def read_tagtouse(path = 'G:/correlation 2013-2014 NHANEs/0906 filter (all)/',
                  filename = 'dataclean exp50 records by histXGB.txt',
                  class_th=0.9,
                  reg_th=0.49):
    D = read_taginfo(path, filename)
    L_rownumber = get_info(D, class_th, reg_th)
    return L_rownumber


def load_data(L_files, path):
    dataframe = None
    for filename in L_files:
        dataframe_new = pandas.read_excel(path + '/' +filename, sheet_name='BPQ020')
        try:
            dataframe = pandas.merge(dataframe, dataframe_new, how='outer')
        except:
            dataframe = dataframe_new
            
    #print(dataframe)
    return dataframe

def delete_poor_col(df, path = 'G:/correlation 2013-2014 NHANEs/0906 filter (all)/',
                  filename = 'dataclean exp50 records by histXGB.txt',
                  class_th=0.9,
                  reg_th=0.49):
    L_tag = read_tagtouse(path, filename, class_th, reg_th)
    arr_tag = np.arange(len(df.columns))
    L_tag_del = [i for i in arr_tag if i not in L_tag if i >=28]
    colnames = df.columns
    L_tagname = [colnames[i] for i in L_tag_del]
    df = df.drop(labels = L_tagname, axis=1)
    return df

def readtag(tagfile, path):
    import csv
    D_tagtype = dict()
    with open(path+tagfile, mode='r', encoding='utf-8-sig') as file:
        data = csv.reader(file)
        for line in data:
            try:
                D_tagtype[line[0]].append(line[1])
            except KeyError:
                D_tagtype[line[0]] = [line[1]]
    return D_tagtype

def split_data(data, X_label, Y_label, Y0_label, T_label, W_label, r=5):
    #data['P_heart_attack'] = norm.ppf(data['P_heart_attack'] )
    n = len(data)
    # food A	food B	chemconc Aa	chemconc Ab	chemconc Ba	chemconc Bb	exposure a	exposure b	geno_defact	age	indicator 1	indicator 2	indicator 3	P_heart_attack confirmed
    X_arr = np.array([ data[item] for item in X_label + W_label]).T
    Y_arr = np.array([ data[item] for item in Y_label + T_label + Y0_label]).T
    #print(np.shape(X_arr), np.shape(Y_arr))
    X_train, X_test, y_train, y_test = train_test_split(X_arr, Y_arr, test_size=1/r )
    if W_label != []:
        nx = len(X_label)
        W_train = X_train[:,nx:]
        W_test= X_test[:,nx:]
        X_train = X_train[:,0:nx]
        X_test = X_test[:,0:nx]
    else:
        W_train, W_test = None, None
        
    ly = len(Y_label)
    lT = len(T_label)
    ly0 = len(Y0_label)
    
    
    Y_train = y_train[:,0:ly]
    T_train = y_train[:,ly:ly+lT]
    y0_train = y_train[:,ly+lT:]
    
    Y_test= y_test[:,0:ly]
    T_test = y_test[:,ly:ly+lT]
    y0_test = y_test[:,ly+lT:]
    
    if lT == 0 and ly0 == 0:
        y0_train, y0_test, T_train, T_test = None, None, None, None
    elif lT == 0:
        T_train, T_test = None, None
    elif ly0 == 0:
        y0_train, y0_test = None, None
        
        
    return X_train, X_test, Y_train, Y_test, y0_train, y0_test, T_train, T_test, W_train, W_test

def save_effects(T0, T1, effect, path, filename):
    import pandas as pd
    Data = dict()
    a,b = np.shape(T0)
    for i in range(b):
        Data['T0:'+str(i)] = [x for x in T0[:,i]]
    for i in range(b):
        Data['T1:'+str(i)] = [x for x in T1[:,i]]
    N = np.ndim(effect)
    if N == 2:
        u,v = np.shape(effect)
        for i in range(v):
            Data['effect:'+str(i)] = [x for x in effect[:,i]]
    elif N == 1:
        Data['effect:0'] = [x for x in effect]
    else:
        raise ValueError('effect has invalid dim. '+str(N))
        
    df = pd.DataFrame(Data)
    df.to_excel(path+filename)
    
    return

   
from sklearn.linear_model import LinearRegression, MultiTaskElasticNetCV, MultiTaskLassoCV
from sklearn.kernel_ridge import KernelRidge

from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor, GradientBoostingRegressor
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, GradientBoostingClassifier
from sklearn.gaussian_process import GaussianProcessRegressor
from xgboost import XGBRegressor as xgbReg
from xgboost import XGBClassifier as xgbCls
from xgboost import plot_tree
from sklearn.neural_network import MLPRegressor
import scipy

from sklearn import metrics
from sklearn.model_selection import train_test_split
from scipy.stats import pearsonr
import shap

from econml.orf import DMLOrthoForest
from econml.dml import CausalForestDML, LinearDML
import sys
sys.path.append('H:/projects/BLUE FOOD/causal_dose response')
from test_NN_clssification_F_BPQ020 import *


def prepare_DML(X, Y, T, W, params=None):
    from sklearn.model_selection import GridSearchCV
    X_train, X_test, T_train, T_test = train_test_split(X, T, test_size=0.2, random_state=1)
    
    clf = xgbReg()
    #from sklearn.gaussian_process.kernels import RBF, PairwiseKernel, Matern, DotProduct, ConstantKernel, Exponentiation
    params = {'max_depth':[2,3,4,5,6],
              'learning_rate':[1e-3,1e-2,3e-2,0.1,0.15],
              'min_child_weight': [1e-4],
              'colsample_bytree': [0.5], 'gamma': [2],  'reg_alpha': [2]
              }
    
    grid = GridSearchCV(clf, params, cv=10, scoring="neg_mean_squared_error",verbose=1)
    grid.fit(X_train, T_train)
    print(grid.best_params_)
    model_T = grid.best_estimator_
    '''
    model_T = xgbReg(max_depth=3, learning_rate=0.1)
    '''
    model_T.fit(X_train, T_train)
    T_pred = model_T.predict(X_test)
    print(metrics.r2_score(T_train, model_T.predict(X_train)))
    print(metrics.r2_score(T_test, T_pred))
    
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=1)
    
    def prepare_model_y(X, y):
        xgb_params = tune_xgb(X, y)
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
        
        tree = NRFRegressionTreeNode(level=1, max_level=1, xgb_params=xgb_params, input_dim=X.shape[1])
        tree.fit(X_train, y_train)
        
        y_pred = tree.predict(X_test) > 0.5
        y_pred = np.array(y_pred, dtype=np.int8)
        y_proba = tree.predict_proba(X_test)[:,1]
        y_pred_train = np.array(tree.predict_proba(X_train)>0.5, dtype=np.int8)[:,1]
        
        print('train',metrics.classification_report(y_train, y_pred_train))
        print('test',metrics.classification_report(y_test, y_pred))
        #print(roc_auc_score(y_test, y_proba))
        
        plt.scatter(y_test+np.random.normal(0,0.05,size=len(y_test)), y_proba, alpha=0.2, s=4)
        plt.show()
        
        fpr, tpr, th = metrics.roc_curve(y_test, y_proba)
        df = {'fpr':fpr, 'tpr':tpr, 'th':th}
        df = pandas.DataFrame(df)
        df.to_excel('H:/projects/BLUE FOOD/causal_dose response/BPQ020_NN_AUC.xlsx')
        auc = roc_auc_score(y_test, y_proba)
        print("AUC:", round(auc,4))
        
        plt.plot(fpr, tpr)
        plt.title('BPQ020 AUC curve:' +str(round(auc,4)))
        plt.show()
        
        return tree
    model_Y = prepare_model_y(X, Y)
    
    DML = CausalForestDML(discrete_outcome = True, n_jobs=-1,
                          model_t=model_T, model_y=model_Y,
                          n_estimators=100, max_depth=8, min_samples_leaf=30 ,min_balancedness_tol=0.5,
                          #mc_iters = 30,
                          honest=True, subforest_size=10)
    return  DML

def check_overfit_reg(best_model, X, y):
    clf = best_model
    L_mse = []
    L_r2 = []
    L_r2_tr = []
    L_split = []
    N_parallals = 20
    train_lim = int(0.05*len(y))
    for split in np.arange(0.75,0.96,0.05):
        split = round(split,2)
        for state in range(N_parallals):
            X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=split, test_size=0.0499, random_state=state)
            clf.fit(X_train, y_train)
            y_testpred = clf.predict(X_test)
            L_mse.append(metrics.mean_squared_error(y_test, y_testpred))
            L_r2.append(metrics.r2_score(y_test, y_testpred))
            L_r2_tr.append(metrics.r2_score(y_train[:train_lim], clf.predict(X_train[:train_lim])))
            L_split.append(split)
    r, p = pearsonr(L_r2_tr, L_split)
    X_splits = np.array(L_split)+scipy.stats.norm.rvs(0,0.001,size=len(L_split))
    plt.scatter(X_splits, L_r2, alpha=0.8)
    plt.scatter(X_splits, L_r2_tr, alpha=0.8)
    plt.show()
    print('prob being not overfit:', p, 'mse pearson r to test size', r,
          'mse average:', np.average(np.array(L_mse)), 'R2 average:', np.average(np.array(L_r2)))
    return L_mse, L_split, N_parallals
    
def check_overfit_class(params, X, y):
    clf = xgbCls(**params)
    L_f1 = []
    L_split = []
    for split in np.arange(0.7,0.96,0.05):
        split = round(split,2)
        for state in range(9):
            X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=split, test_size=0.05, random_state=state)
            clf.fit(X_train, y_train)
            y_testpred = clf.predict(X_test)
            L_f1.append(metrics.f1_score(y_test, y_testpred))
            L_split.append(split)
    r, p = pearsonr(L_f1, L_split)
    print('prob being not overfit:', p, 'F1 pearson r to test size', r, 'f1 average:', np.average(np.array(L_f1)))
    return L_f1, L_split, 9

def check_shapvalues(trained_model, X_test):
    # Explain predictions using SHAP
    explainer = shap.Explainer(trained_model)
    shap_values = explainer(X_test)    # X_test: DataFrame or numpy array
    
    # Visualize feature importance
    shap.summary_plot(shap_values, X_test)
    return

def filtering(X, X_ground):
    from sklearn.decomposition import PCA
    pca = PCA()
    a,b = np.shape(X)
    for j in range(b):
        k = 1/np.sum(X[:,j])
        X[:,j] = X[:,j]*k
        X_ground[:,j] = X_ground[:,j]*k
    #X = pca.fit_transform(X)
    
    return X, X_ground

def grid_y(X, y):
    X = X[y > 0.1]
    y = y[y > 0.1]
    ave = np.average(y)
    sd = np.std(y)
    t_th = 10
    y = y[(y<t_th*sd+ave)+(y>-t_th*sd+ave)]
    X = X[(y<t_th*sd+ave)+(y>-t_th*sd+ave)]
    print('filtered by y and its sd')
    return X, y, (ave, sd, t_th)

from sklearn.metrics import make_scorer, precision_score
negative_precision = make_scorer(
    lambda y_true, y_pred: ((2-precision_score(y_true, y_pred))**4-1)**0.25,
    greater_is_better=False  # Minimize the score
)


def prepare_banchmark(data, X_label, Y_label, T_label, W_label, mode='Reg', ground = 0.07):
    X_cov = np.array([data[x] for x in X_label]+[data[w] for w in W_label]).T
    X = np.concatenate([ X_cov, np.array( [data[t] for t in T_label]  ).T], axis=1) # 
    X_ground= np.concatenate([ X_cov, np.array( [np.ones(len(data[t]))*ground for t in T_label] ).T ], axis=1)
    y = np.array( [data[Y] for Y in Y_label] ).T
    L_labels = X_label + W_label + T_label
    # for each outcome, first get SHAP values, then refine data
    from sklearn.inspection import permutation_importance
    from sklearn.model_selection import GridSearchCV
    outcomes = ['MCQ080', 'BPQ020', 'MCQ160A', 'DIQ010'] # for classification xgb
    
    #outcomes = ['BMXBMI']
    #excluses = []
    #outcomes = ['LBXHGB']
    #excluses = ['LBXMCHSI','LBXRBCSI']
    #outcomes = ['LBDSGBSI']
    #excluses = ['LBXSGB']
    #outcomes = ['LBXTC'] 
    #excluses = ['LBDHDDSI','LBXSCH'] # 'LBXHGB'|'LBXTC', 'LBDHDDSI', 'LBXRBCSI'
    outcomes = ['BPQ020']
    excluses = []
    # 'MCQ080', 'BPQ020', 'MCQ160A', 'KIQ022' tested in (c).py
    # medium value of 'MCQ160E' = 0~
    # medium value of 'MCQ220', 'MCQ160C', 'MCQ010' < 0
    # 'MCQ160F' has 60% increasing risk rate
    # 'PFQ057' is also good
    L_inds = [ Y_label.index(outcome) for outcome in outcomes ]
    L_excs = [ Y_label.index(excluse) for excluse in excluses ]
    D_ground = dict()
    df_score = dict()
    for i in L_inds:
        print(Y_label[i],'/',Y_label,len(Y_label))
        X_i = X #np.concatenate( [X, y[:,[j for j in range(len(Y_label)) if not j in [i]+L_excs]]], axis=1)
        L_labels_i = L_labels# + [Y_label[j] for j in range(len(Y_label)) if not j in [i]+L_excs]
        if mode == 'Binary':
            y_i = 2-y[:,i]
            # use GB to prepare the SHAP value
            
            if Y_label[i] == 'BPQ020':
                L_selcted_label = ['DMDMARTL','HUQ030','HUQ010','DMDCITZN','SMAQUEX','LBXHA','LBXPFOS','HSD010',
                                   'BPACSZ','DR2TCRYP']
            # BPQ020 (up)
            X_= X_i[:,[L_labels_i.index(feature) for feature in L_selcted_label]]
            X_ground_i = X_ground[:,[L_labels_i.index(feature) for feature in L_selcted_label]]
            
            def TrainTree(X, y):
                xgb_params = tune_xgb(X, y)
                
                X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
                
                tree = NRFRegressionTreeNode(level=1, max_level=1, xgb_params=xgb_params, input_dim=X.shape[1])
                tree.fit(X_train, y_train)
                
                y_pred = tree.predict(X_test) > 0.5
                y_pred = np.array(y_pred, dtype=np.int8)
                y_proba = tree.predict_proba(X_test)[:,1]
                y_pred_train = np.array(tree.predict_proba(X_train)>0.5, dtype=np.int8)[:,1]
                
                print('train',metrics.classification_report(y_train, y_pred_train))
                print('test',metrics.classification_report(y_test, y_pred))
                #print(roc_auc_score(y_test, y_proba))
                
                plt.scatter(y_test+np.random.normal(0,0.05,size=len(y_test)), y_proba, alpha=0.2, s=4)
                plt.show()
                
                fpr, tpr, th = metrics.roc_curve(y_test, y_proba)
                df = {'fpr':fpr, 'tpr':tpr, 'th':th}
                df = pandas.DataFrame(df)
                df.to_excel()
                auc = roc_auc_score(y_test, y_proba)
                print("AUC:", round(auc,4))
                
                plt.plot(fpr, tpr)
                plt.title('BPQ020 AUC curve:' +str(round(auc,4)))
                plt.show()
                tree.fit(X, y)
                return tree
            
            import torch
            NNTree = torch.load('./NNTree_BPQ020.pth')
            y_pred = NNTree.predict(X_) > 0.5
            y_pred = np.array(y_pred, dtype=np.int8)
            print('train',metrics.classification_report(y_i, y_pred))
            
            y_i_p = NNTree.predict_proba(X_)[:,1]
            y_ground_p = NNTree.predict_proba(X_ground_i)[:,1]
            
            D_ground[Y_label[i] +'_control'] = y_ground_p
            D_ground[Y_label[i] +'_treated'] = y_i_p
            best_params = None
            
            delta_y = np.array([y_i_p - y_ground_p]).T
            
    #df = pandas.DataFrame(D_ground)
    #df.to_excel('F:/NHANEs 2003-2016 (add 2018)/conditioned patients/ground_PFAS_outcome_classification 250614 MCQ080.xlsx')
    # return the change of outcome (or proba for binary) from ground; model_trained and parameters; overfit test scores, split train size, and cv level for each split size
    return delta_y, best_params, L_selcted_label, Y_label[i]

def compare_banchmark(data, X_label, Y_label, T_label, W_label, delta_y, mode='Reg', ground = 0.01, params = None):
    X = np.array( [data[x] for x in X_label], dtype=np.float32 ).T
    T = np.array( [data[t] for t in T_label], dtype=np.float32 ).T
    
    W = np.array( [data[w] for w in W_label], dtype=np.float32 ).T
    Y = 2 - np.array( [data[y] for y in Y_label], dtype=np.int8 ).T
    T0 = np.ones_like(T)*ground
    model = prepare_DML(X, Y[:,0], T, W, params=params)
    delta_Y = []
    delta_Ysd = []
    
    #T = np.log10(T); T0 = np.log10(T0)
    
    for i in range(len(Y_label)):
        print(Y_label[i], 'is fitting')
        print(np.shape(X), np.shape(T), np.shape(Y), np.shape(W))
        model.fit(X=X, T=T, Y=Y[:,i], W=W, inference='blb') #'blb' 'bootstrap'
        # assume the log based relationship
        T1 = T
        T0 = T0
        #T1[:,[1,2]] = T0[:,[1,2]]
        treatment_effects = model.effect(X=X, T0=T0, T1=T1)
        print('treatment_effects',np.shape(treatment_effects))
        
        treatment_effects_interval = model.effect_interval(X=X, T0=T0, T1=T1, alpha=0.1)
        k = np.average( treatment_effects_interval[0] - treatment_effects_interval[1] )
        print('treatment_effects_interval average diff:', k)
        delta_Y = treatment_effects
        delta_Ysd.append(treatment_effects_interval)
    #delta_Y = treatment_effects np.array(delta_Y).T
    D_scores = compare_dyvalues(Y_label, delta_y, delta_Y, mode)
    print('metrics:  pearson_r   pearson_p  r2     mse     mae')
    for item in D_scores:
        print(f'{item}  {D_scores[item][0]:.3f}   {D_scores[item][1]:.3e}   {D_scores[item][2]:.3f}    {D_scores[item][3]:.3f}   {D_scores[item][4]:.3f}')
        N_display = 1587
        plt.scatter(np.log10((data['LBXPFOS'])[:N_display])[Y[:N_display,i] == 0], np.array(treatment_effects[:N_display,0])[Y[:N_display,i] == 0], alpha=0.1, c ='steelblue',s=6)
        plt.scatter(np.log10((data['LBXPFOS'])[:N_display])[Y[:N_display,i] == 1], np.array(treatment_effects[:N_display,0])[Y[:N_display,i] == 1], alpha=0.3, c ='salmon',s=6)
        #plt.plot(np.log10([2,2]),[-1,2], linewidth=0.5, c='red', alpha=0.8)
        plt.plot(np.log10([20,20]),[-1,2], linewidth=0.5, c='red', alpha=0.8) #LBXPFOS HBM II
        plt.plot(np.log10([2,2]),[-1,2], linewidth=0.5, c='grey', alpha=0.8) #LBXPFOS HBM I 
        plt.xlim([-2,3.5])
        plt.ylim([-0.05,1])
        plt.show()
        print(f'average treatment_effect: {np.average(treatment_effects[:,0]):.5f}, sd {np.std(treatment_effects[:,0]):.5f}')
        sortedarr = np.sort(treatment_effects[:,0])
        print('IC95:',sortedarr[int(0.975*len(sortedarr))], sortedarr[int(0.025*len(sortedarr))])
        print('3Qs:',sortedarr[int(0.75*len(sortedarr))],sortedarr[int(0.5*len(sortedarr))], sortedarr[int(0.25*len(sortedarr))])
        print(f'average treatment_effect on Neg: {np.average(np.array(treatment_effects[:,0])[Y[:,i] == 0]):.5f}')
        print(f'average treatment_effect on Pos: {np.average(np.array(treatment_effects[:,0])[Y[:,i] == 1]):.5f}')
    
    return delta_Y, np.array(delta_Ysd).T, D_scores, model

def compare_dyvalues(Y_label, delta_y, delta_Y, mode):
    from scipy.optimize import curve_fit
    def line(x,a,b):
        return a*x + b
    
    D_scores = dict()
    if mode == 'Reg':
        for i in range(len(Y_label)):
            D_scores[Y_label[i]] = [ metrics.r2_score(delta_y[:,i], delta_Y[:,i]), metrics.mean_squared_error(delta_y[:,i], delta_Y[:,i]), metrics.mean_absolute_error(delta_y[:,i], delta_Y[:,i]) ]
    elif mode == 'Binary':
        for i in range(len(Y_label)):
            popt, pcov = curve_fit(line, delta_y[:,i], delta_Y[:,i])
            plt.scatter(delta_y[:,i], delta_Y[:,i], alpha=0.1)
            plt.plot(np.array([-0.1,0.6]), line(np.array([-0.1,0.6]), *popt), 'r-', alpha=0.5)
            #plt.ylim([-0.05,0.2])
            plt.show()
            r, p = pearsonr(delta_y[:,i], delta_Y[:,i])
            D_scores[Y_label[i]] = [r, p, metrics.r2_score(delta_y[:,i], delta_Y[:,i]), metrics.mean_squared_error(delta_y[:,i], delta_Y[:,i]), metrics.mean_absolute_error(delta_y[:,i], delta_Y[:,i]) ]
    return D_scores

def stability_valid(data, X_label, Y_label, T_label, W_label, mode='Reg', ground = 0.01):
    X = np.array( [data[x] for x in X_label] ).T
    T = np.array( [data[t] for t in T_label] ).T
    W = np.array( [data[w] for w in W_label] ).T
    Y = np.array( [2-data[y] for y in Y_label], dtype=np.int8 ).T
    df = {}
    '''test by add random varibles in treatment'''
    arr_dy_test1 = []
    for i in range(10):
        if i == 0:
            conf = ground + norm.rvs(0, 0.3, size=(np.shape(T)[0],1))
        else:
            conf = conf + norm.rvs(0, 0.3, size=(np.shape(T)[0],1))
        T_test1 = np.concatenate([T, conf], axis=1)
        T0_test1 = np.ones_like(T_test1)*ground
        for j in range(10):
            model = prepare_DML(X, Y[:,0], T_test1, W)
            model.fit(X=X, T=T_test1, Y=Y[:,0], W=W, inference='blb')
            if j == 0:
                treatment_effects = model.effect(X=X, T0=T0_test1, T1=T_test1)
            else:
                treatment_effects = np.concatenate([treatment_effects, model.effect(X=X, T0=T0_test1, T1=T_test1)], axis=1)
        arr_dy_test1.append(treatment_effects)
        
    arr_dy_test1 = np.array(arr_dy_test1).T[0]
    print(np.shape(arr_dy_test1))
    ave = np.average(arr_dy_test1, axis=0)
    sorted_eff = np.sort(arr_dy_test1, axis=0)
    sd = np.std(arr_dy_test1, axis=0)
    plt.plot(np.arange(10)+1, ave)
    plt.fill_between(np.arange(10)+1, sorted_eff[int(np.shape(arr_dy_test1)[0]*0.025)], sorted_eff[int(np.shape(arr_dy_test1)[0]*0.975)], alpha=0.2)
    plt.show()
    
    df['conf added'] = np.arange(10)+1
    df['robust T ave'] = ave
    df['robust T sd'] = sd
    df['robust T 2.5'] = sorted_eff[int(np.shape(arr_dy_test1)[0]*0.025)]
    df['robust T 97.5'] = sorted_eff[int(np.shape(arr_dy_test1)[0]*0.975)]
    
    '''test by add random varibels in covariates'''
    arr_dy_test2 = []
    for i in range(10):
        T0 = np.ones_like(T)*ground
        if i == 0:
            conf = norm.rvs(3*i, 0.8, size=(np.shape(X)[0],1))
        else:
            conf = conf + norm.rvs(3*i, 0.8, size=(np.shape(X)[0],1))
        X_test = np.concatenate([X, conf], axis=1)
        for j in range(3):
            model = prepare_DML(X_test, Y[:,0], T, W)
            model.fit(X=X_test, T=T, Y=Y[:,0], W=W, inference='blb')
            if j == 0:
                treatment_effects = model.effect(X=X_test, T0=T0, T1=T)
            else:
                treatment_effects = np.concatenate([treatment_effects,model.effect(X=X_test, T0=T0, T1=T)], axis=1)
        arr_dy_test2.append(treatment_effects)
    arr_dy_test2 = np.array(arr_dy_test2).T[0]
    print(np.shape(arr_dy_test2))
    ave = np.average(arr_dy_test2, axis=0)
    sorted_eff = np.sort(arr_dy_test2, axis=0)
    #sd = np.std(arr_dy_test2, axis=0)
    plt.plot(np.arange(10)+1, ave)
    #plt.fill_between(np.arange(10)+1, ave-sd, ave+sd, alpha=0.2)
    plt.fill_between(np.arange(10)+1, sorted_eff[int(np.shape(arr_dy_test2)[0]*0.025)], sorted_eff[int(np.shape(arr_dy_test2)[0]*0.975)], alpha=0.2)
    plt.show()
    
    df['robust X ave'] = ave
    df['robust X sd'] = sd
    df['robust X 2.5'] = sorted_eff[int(np.shape(arr_dy_test2)[0]*0.025)]
    df['robust X 97.5'] = sorted_eff[int(np.shape(arr_dy_test2)[0]*0.975)]
    
    df = pandas.DataFrame(df)
    df.to_excel('.../double machine learning/sensitivity_results/robust/robust_BPQ020.xlsx')
    
    '''compare the test results'''
    # for test1, diract subtruction
    # for test2, check variation of sd by increasment of error covariates
    
    return arr_dy_test1, arr_dy_test2

def broken_relationship_test(data, X_label, Y_label, T_label, W_label, mode='Reg', ground = 0.01, labelbroken = 'T'):
    #import random
    X = np.array( [data[x] for x in X_label] ).T
    T = np.array( [data[t] for t in T_label] ).T
    W = np.array( [data[w] for w in W_label] ).T
    Y = np.array( [2 - data[y] for y in Y_label] , dtype=np.int8).T
    T0 = np.ones_like(T)*ground
    if labelbroken == 'T':
        T = list(T)
        random.shuffle(T)
        T = np.array(T)
    elif labelbroken == 'X':
        X = list(X)
        random.shuffle(X)
        X = np.array(X)
    elif labelbroken == 'Y':
        Y = list(Y)
        random.shuffle(Y)
        Y = np.array(Y)
    
    delta_Y = []
    delta_Ysd = []
    for i in range(len(Y_label)):
        print(Y_label[i], 'is fitting')
        model = prepare_DML(X, Y[:,i], T, W)
        model.fit(X=X, T=T, Y=Y[:,i], W=W, inference='blb')
        # assume the log based relationship
        treatment_effects = model.effect(X=X, T0=T0, T1=T)
        treatment_effects_interval = model.effect_interval(X=X, T0=T0, T1=T, alpha=0.1)
        delta_Y.append(treatment_effects)
        delta_Ysd.append(treatment_effects_interval)
    delta_Y = np.array(delta_Y).T[0]
    
    plt.scatter(np.log10(T[:,0]), treatment_effects, alpha=0.1, s=6)
    plt.title(Y_label[i]+' causal test:'+labelbroken )
    plt.xlim(-2,2.6)
    plt.show()
    print(f'{Y_label[i]} causal test: {labelbroken}')
    print(f'average treatment_effect: {np.average(treatment_effects):.5f}, sd {np.std(treatment_effects):.5f}')
    sortedarr = np.sort(treatment_effects)
    print(sortedarr[int(0.975*len(treatment_effects))], sortedarr[int(0.025*len(treatment_effects))])
    return delta_Y, T

def plot_SHAPs(data, X_label, Y_label, T_label, W_label, model):
    X = np.array( [data[x] for x in X_label] ).T
    # tree interpreter
    def plot_tree():
        from econml.cate_interpreter import SingleTreeCateInterpreter
        intrpX = SingleTreeCateInterpreter(include_model_uncertainty=Fa, max_depth=2, min_samples_leaf=10)
        # We interpret the CATE model's behavior based on the features used for heterogeneity
        intrpX.interpret(model, X)
        # Plot the tree
        intrpX.plot(feature_names=X_label, fontsize=12)
        return
    shap_values = model.shap_values(X, feature_names=X_label)
    
    # Create prediction function
    def predict_cate(X):
        return model.effect(X)
    
    # Compute SHAP values
    background = shap.sample(X, 800)  # Representative background
    explainer = shap.KernelExplainer(predict_cate, background, feature_names=X_label)
    
    # Calculate SHAP values (use small batches if dataset is large)
    shap_values = explainer.shap_values(X[6000:6800])  # First 100 samples
    
    # Summarize results
    shap.summary_plot(shap_values, X[6000:6800])
    
    return

def save_DMLresults(data,T_label,Y_label,deltaY_DML, path = 'H:/projects/BLUE FOOD/causal_dose response/CausalForestDML/',
                    filename = 'BPQ020_predictions_2003-2016.xlsx'):
    D_difference = {}
    for i in range(len(T_label)):
        D_difference[T_label[i]] = np.array(data[T_label[i]])
    for i in range(len(Y_label)):
        D_difference[Y_label[i]] = deltaY_DML[:,i]
    df = pandas.DataFrame(D_difference)
    df.index = data.index
    df.to_excel(path+Y_label[0]+'_'+filename)
    return

def save_random_results(T_label,Y_label,T_deltaY_DML_brokenX,deltaY_DML,deltaY_DML_brokenX, deltaY_DML_brokenT,T_deltaY_DML_brokenT):
    L_head = T_label + ['org '+y for y in Y_label] + ['causal_X '+y for y in Y_label] + [l+'_random' for l in T_label] + ['causal_T '+y for y in Y_label]
    df = {}
    a = len(T_label)
    b = len(Y_label)
    
    for i in range(len(L_head)):
        if i < a:
            df[L_head[i]] = T_deltaY_DML_brokenX[:,i]
        if i >= a and i < a+b:
            df[L_head[i]] = deltaY_DML[:,0]
        if i >= a+b and i < a+2*b:
            df[L_head[i]] = deltaY_DML_brokenX[:,0]
        if i >= a+2*b and i < 2*a+2*b:
            df[L_head[i]] = T_deltaY_DML_brokenT[:,i-a-2*b]
        if i >= 2*a+2*b:
            df[L_head[i]] = deltaY_DML_brokenT[:,0]
    
    df = pandas.DataFrame(df)
    df.to_excel('.../double machine learning/sensitivity_results/permutation/causal_result_BPQ020.xlsx')
    return

def predictfuture(data, X_label, Y_label, T_label, W_label, model, path, filename, ground=1e-12):
    df_serum_level = pandas.read_excel(path+filename, index_col='SEQN')
    df_serum_level = df_serum_level.loc[data['SEQN']]
    
    X = np.array( [data[x] for x in X_label], dtype=np.float32 ).T
    T = np.array( [df_serum_level[t] for t in T_label], dtype=np.float32 ).T
    W = np.array( [data[w] for w in W_label], dtype=np.float32 ).T
    T0 = np.ones_like(T)*ground
    os.makedirs(path+'effects', exist_ok=True)
    p_incresed = model.effect(X=X, T0=T0, T1=T)[:,0]
    df_result = pandas.DataFrame( {'SEQN':data['SEQN'], 'treat_effect':p_incresed})
    df_result.to_excel(path + 'effects/'+ Y_label[0]+'_effect_'+filename)
    return

def test_DML_OrthForest():
    L_files = ['data_outcome diseases.xlsx']
    path = '.../double machine learning/input_file/NHANES data'
    data = load_data(L_files, path)
    print('raw data length:',len(data.columns))
    #data = delete_poor_col(data)
    #print('filted by model estimation quality, data length:',len(data.columns))
    tagfile = 'tag diseases.csv'
    D_tagtype = readtag(tagfile, path+'/')
    mode = 'Binary' # or Reg Binary Multiclass
    
    X_label = [ tag for tag in D_tagtype['covariate'] if tag in data.columns]
    Y_label = [ tag for tag in D_tagtype['outcome'] if tag in data.columns]
    T_label = [ tag for tag in D_tagtype['treatment'] if tag in data.columns]
    W_label = [ tag for tag in D_tagtype['instrumental'] if tag in data.columns]
    
    '''#first test by compare the results of other models'''
    # 1. obtain the banchmark value of outcome difference (assumed the ground =0.01)
    deltaY_XG, best_params, selected_label, y_i_label = prepare_banchmark(data, X_label, Y_label, T_label, W_label, mode=mode, ground = 1e-2)
    '''
    def save_banchmark():
        import joblib
        # save deltaY banchmark
        #df = pandas.DataFrame(deltaY_RF)
        #df.to_excel(path+'/'+'banchmark_treatment_effect_by_RF.xlsx')
        # save model, print parameter
        #joblib.dump(tup_model[0], path+'/'+'banchmark_RF.json')
        print('parameters used by banchmark_RF',tup_model[1])
        #save overfiting check
        L_score, L_split_train, N_cv_overfit = tup_overfitvalid
        print([L_score[i] for i in range(10)])
        return
    '''
    #save_banchmark()
    
    # 2. compute the treatment effect, sd_deltaY_DML has [array for uplim, array for lowlim], scores {outcome: r2, mse, mae}
    X_label = [l for l in X_label if l in selected_label]
    T_label = [l for l in T_label if l in selected_label]
    W_label = [l for l in W_label if l in selected_label]
    Y_label = [y_i_label]
    deltaY_DML, sd_deltaY_DML, socres_DML, DML_model = compare_banchmark(data, X_label, Y_label, T_label, W_label, deltaY_XG, mode=mode, ground = 1e-2, params = best_params)
    
    #save_DMLresults(data,T_label,Y_label,deltaY_DML)
    # done (250624)
    '''#second test by adding random factors'''
    # 1. check the effect on random value treatments; 2. sd variation on by addin random coveriates
    dy_test1, dy_test2 = stability_valid(data, X_label, Y_label, T_label, W_label, mode=mode, ground = 0.01)
    # done (250626)
    '''#thrid test by resheffle treatments, coveriates'''
    # 1. randomized treatments
    deltaY_DML_brokenT,T_deltaY_DML_brokenT = broken_relationship_test(data, X_label, Y_label, T_label, W_label, mode=mode, ground = 0.01)
    # 2. randomized coveriates
    deltaY_DML_brokenX, T_deltaY_DML_brokenX = broken_relationship_test(data, X_label, Y_label, T_label, W_label, mode=mode, ground = 0.01, labelbroken = 'X' )
    save_random_results(T_label,Y_label,T_deltaY_DML_brokenX,deltaY_DML,deltaY_DML_brokenX, deltaY_DML_brokenT,T_deltaY_DML_brokenT)
    
    #fourth test to check SHAPs
    #plot_SHAPs(data, X_label, Y_label, T_label, W_label, DML_model)
    #print(X_label[2], X_label[4], X_label[5], X_label[3], X_label[0], X_label[7], X_label[6], X_label[8], X_label[1])
    
    '''last predict the projected values'''
    L_country = ['Australia','Austria','Belgium','Bulgaria','Canada','Chile','Croatia','Czechia','Denmark','Estonia','Finland','France',
                 'Germany','Greece','Iceland','Ireland','Israel','Italy','Japan','Korea','Latvia','Lithuania','Luxembourg','Netherlands',
                 'New Zealand','Norway','Poland','Portugal','Romania','Slovak Republic','Slovenia','Spain','Sweden','Switzerland',
                 'United Kingdom','United States','India','Indonesia','Argentina','Brazil','China','Colombia','Costa Rica','Hungary',
                 'Mexico','South Africa','Turkiye']
    for country in L_country:
        path_pred = '.../EDIs vs NHANES serum concentrations/results/BPQ020/'+country+'/'
        L_head = ['2020', 'BAU', 'BAUMeta', 'HL', 'HLMeta', 'LL', 'LLMeta']
        for head in L_head:
            file_pred = head + 'predicted serum level.xlsx'
            predictfuture(data, X_label, Y_label, T_label, W_label, DML_model, path_pred, file_pred)
    
    return
import time
#time.sleep(600)
test_DML_OrthForest()
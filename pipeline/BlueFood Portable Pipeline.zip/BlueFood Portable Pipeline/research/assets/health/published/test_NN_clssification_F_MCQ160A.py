# -*- coding: utf-8 -*-
"""
Created on Sat May 24 17:29:02 2025

@author: Admin
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import xgboost as xgb
from sklearn.tree import _tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
from sklearn.preprocessing import OneHotEncoder
from sklearn.utils.class_weight import compute_class_weight
from sklearn.model_selection import KFold

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class CustomLoss(nn.Module):
    def __init__(self, pos_weight=None):
        super().__init__()
        self.pos_weight = pos_weight  # Set this using class ratios
    
    def forward(self, inputs, targets):
        # Use sigmoid instead of clamping for gradient flow
        probabilities = torch.sigmoid(inputs)
        
        # Calculate absolute error
        abs_error = torch.abs(probabilities - targets)
        
        # Apply class balancing weights
        if self.pos_weight is not None:
            weights = targets * self.pos_weight + (1 - targets)
            weighted_error = abs_error * weights
        else:
            weighted_error = abs_error * (targets + 1)  # Your original weighting
        
        return weighted_error.mean()/(2-2/self.pos_weight)

class BoundedL1Loss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, inputs, targets):
        inputs = torch.clamp(inputs, 0.0, 1.0)  # Ensure bounded outputs
        return torch.abs(inputs - targets)*(targets+1).mean()

def tune_xgb(X, y):
    #return {'n_estimators':30, 'colsample_bytree': 0.5, 'gamma': 1, 'learning_rate': 0.01, 'max_depth': 7, 'min_child_weight': 0.2, 'reg_alpha': 3, 'scale_pos_weight': 2.0}
    return {'n_estimators':120, 'colsample_bytree': 0.5, 'gamma': 10, 'learning_rate': 0.1, 'max_depth': 8, 'min_child_weight': 0.1, 'reg_alpha': 10, 'scale_pos_weight': 2.0}
    #return {'n_estimators':30, 'colsample_bytree': 0.75, 'gamma': 2, 'learning_rate': 0.1, 'max_depth': 9, 'min_child_weight': 0.2, 'reg_alpha': 1, 'scale_pos_weight': 2.0}
    '''
    from sklearn.metrics import mean_squared_error, r2_score, classification_report, roc_curve
    import pandas as pd
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    if len(set(list(y_train))) > 1 and len(set(list(y_test))) > 1:
        from sklearn.model_selection import GridSearchCV, StratifiedKFold
        basemodel = xgb.XGBClassifier(n_estimators=120)
        w0, w1 = list(compute_class_weight(class_weight = None,classes = np.array([0,1]),y = y))
        params = {'max_depth': [3,5,7,8,9,11], #2,3,8,12,16,20  3,5,7,
                  'learning_rate': [0.003,0.01,0.03,0.1],
                  'colsample_bytree': [0.5,0.75],
                  'min_child_weight': [0.5],
                  'gamma': [10], #[0.5,1,3],
                  'reg_alpha': [10],#[1,3,6],
                  'scale_pos_weight': [(w1+w0)/w1], #[3,4]
                  }
        grid = GridSearchCV(basemodel, params, cv=StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
                            , scoring='f1' ,verbose=1)
        grid.fit(X_train, y_train)
        basemodel = grid.best_estimator_
        df = pd.DataFrame(grid.cv_results_)
        df.to_excel('H:/projects/BLUE FOOD/causal_dose response/MCQ160A_XGB_cvresults.xlsx')
        
        # validate
        y_pred = basemodel.predict(X_test)
        test_probs = basemodel.predict_proba(X_test)[:,1]
        
        fpr, tpr, th = roc_curve(y_test, test_probs)
        auc = roc_auc_score(y_test, y_pred)
        df_auc = {'fpr':fpr, 'tpr':tpr, 'th':th}
        df_auc = pd.DataFrame(df_auc)
        df_auc.to_excel('H:/projects/BLUE FOOD/causal_dose response/MCQ160A_XGB_bestAUC.xlsx')
        bestparams = grid.best_params_
        
        auc = roc_auc_score(y_test, test_probs)
        bestparams = grid.best_params_
        print(grid.best_params_)
        print('best f1 score', grid.best_score_)
        print('train',classification_report(y_train, basemodel.predict(X_train)))
        print('test',classification_report(y_test, y_pred))
        print("AUC:", round(auc,4))
        return bestparams
        
    else:
        print('very well classiflyed')
        return None
    '''
    
class NeuralRandomForestRegressor(nn.Module):
    def __init__(self, level, input_dim, xgb_params=None, hidden_dim=128):
        super(NeuralRandomForestRegressor, self).__init__()
        self.constant_output = None
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.xgb_params = xgb_params or {
            'objective': 'reg:squarederror',
            'max_depth': 5,
            'n_estimators': 20
        }
        self.encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
        self.xgb_model = None
        self.nn = None
        self.level = level


    def fit_(self, X, y, k=10):
        if len(np.unique(y)) == 1:
            self.constant_output = float(np.unique(y)[0])
            print(f"All samples have label {self.constant_output}. Skipping training.")
            return
        w0, w1 = list(compute_class_weight(class_weight = None,classes = np.array([0,1]),y = y))
        # Train XGBoost model on the full data
        self.xgb_model = xgb.XGBRegressor(**self.xgb_params)
        self.xgb_model.fit(X, y)
    
        # Get leaf indices and encode them
        leaf_indices = self.xgb_model.apply(X)
        if leaf_indices.ndim == 3:
            leaf_indices = leaf_indices[:, 0, :]
    
        self.encoder.fit(leaf_indices)
        leaf_features = self.encoder.transform(leaf_indices)
        input_dim = leaf_features.shape[1]
        print('input_dim:',input_dim)
        # Define neural network if not already defined
        self.nn = nn.Sequential(
            nn.Linear(input_dim, self.hidden_dim),
            nn.GELU(),
            nn.Dropout(0.3),
            nn.Linear(self.hidden_dim, self.hidden_dim),
            nn.GELU(),
            nn.Dropout(0.3),
            nn.Linear(self.hidden_dim, 1),
            nn.Sigmoid()
        )
    
        # K-Fold cross-validation training for the NN
        kf = KFold(n_splits=k, shuffle=True, random_state=42)
        optimizer = torch.optim.Adam(self.nn.parameters(), lr=1e-4, weight_decay=1e-5)
        w = (w1+w0)/w1*1.5
        criterion = CustomLoss(w)
        self.train()
        
        for fold, (train_idx, val_idx) in enumerate(kf.split(leaf_features)):
            #print(f"\nFold {fold+1}/{k}")
            X_train = torch.tensor(leaf_features[train_idx], dtype=torch.float32)
            y_train = torch.tensor(y[train_idx].reshape(-1, 1), dtype=torch.float32)
            last_loss = 1000
            for epoch in range(15):
                self.nn.train()
                optimizer.zero_grad()
                output = self.nn(X_train)
                loss = criterion(output, y_train)
                '''
                if last_loss - loss.item() < 1e-4:
                    print(f"  Epoch {epoch}: Loss={loss.item():.4f}")
                    break
                '''
                #print(loss)
                loss.backward()
                optimizer.step()
                last_loss = loss.item()
                #if epoch % 1 == 0:
                #    print(f"  Epoch {epoch}: Loss={loss.item():.4f}")

    
    def transform(self, X):
        leaf_indices = self.xgb_model.apply(X)
        if leaf_indices.ndim == 3:
            leaf_indices = leaf_indices[:, 0, :]
        return self.encoder.transform(leaf_indices)

    def forward(self, X):
        if isinstance(X, np.ndarray):
            X = torch.tensor(X, dtype=torch.float32)
        if self.constant_output is not None:
            return torch.full((X.shape[0], 1), self.constant_output)
        return self.nn(X)

    def predict(self, X):
        X_transformed = self.transform(X)
        with torch.no_grad():
            X_tensor = torch.tensor(X_transformed, dtype=torch.float32)
            preds = self.forward(X_tensor)
            return preds.numpy().flatten()


class NRFRegressionTreeNode:
    def __init__(self, level, max_level, input_dim, path_label=None, xgb_params=None):
        self.level = level
        self.max_level = max_level
        self.input_dim = input_dim
        self.path_label = path_label  # <-- Add this line
        self.model = NeuralRandomForestRegressor(input_dim, level, xgb_params)
        self.children = {}
    
    def fit(self, X, y):
        if len(np.unique(y)) == 1:
            # Stop training and set constant output
            self.model.constant_output = float(y[0])
            print(f"Level {self.level}: All targets are {y[0]}. Skipping training.")
            return
    
        #self.model.fit(X, y)
        self.model.fit_(X, y)
        if self.level >= self.max_level:
            return
    
        # Route based on regression output threshold
        y_pred = self.model.predict(X)
        for direction in [0, 1]:
            idx = np.where((y_pred <= 0.5) if direction == 0 else (y_pred > 0.5))[0]
            if len(idx) == 0:
                continue
            child_X = X[idx]
            child_y = y[idx]
            if len(np.unique(child_y)) == 1:
                print(f"Level {self.level + 1}: All targets are {child_y[0]} in direction {direction}. Skipping child.")
                continue
            child_node = NRFRegressionTreeNode(self.level + 1, self.max_level, X.shape[1], path_label=f"{direction}")
            #child_node.fit(child_X, child_y)
            child_node.fit(child_X, child_y)
            self.children[direction] = child_node

    def predict(self, X):
        if self.model.constant_output is not None:
            return np.full(X.shape[0], self.model.constant_output)

        preds = self.model.predict(X)
        if not self.children:
            return preds

        result = np.zeros_like(preds)
        for direction in [0, 1]:
            idx = np.where((preds <= 0.5) if direction == 0 else (preds > 0.5))[0]
            if direction in self.children and len(idx) > 0:
                result[idx] = self.children[direction].predict(X[idx])
            else:
                result[idx] = preds[idx]
        return result
    
    def predict_proba(self, X):
        if self.model.constant_output is not None:
            Constants = self.model.constant_output
            return np.full(X.shape[0], np.concatenate([[1-Constants], [Constants]], axis=0).T)
    
        probs = self.model.predict(X)
        if not self.children:
            return np.concatenate([[1-probs], [probs]], axis=0).T
    
        result = np.zeros_like(probs)
        for direction in [0, 1]:
            idx = np.where((probs <= 0.5) if direction == 0 else (probs > 0.5))[0]
            if direction in self.children and len(idx) > 0:
                result[idx] = self.children[direction].predict_proba(X[idx])
            else:
                result[idx] = probs[idx]  # fallback to current node's output
        return np.concatenate([[1-result], [result]], axis=0).T

# Example usage
#if __name__ == '__main__':
def main():
    from sklearn.datasets import make_regression, make_classification, load_breast_cancer
    from sklearn.metrics import mean_squared_error, r2_score, classification_report, roc_curve
    import pandas as pd
    
    import sys
    sys.path.append('./') #current path
    import Data_Matrix_Load as DML
    def generate_data():
        X, y, X_0 = DML.data_matrix_load()
        print(np.shape(X))
        return X, y, X_0
    X, y, X_0 = generate_data()
    '''
    X, y = make_classification(n_samples=10000, n_features=20, n_informative=10, random_state=42)
    #X, y = load_breast_cancer().data, load_breast_cancer().target
    #y = 1 / (1 + np.exp(-y / 100))  # Normalize to (0,1) using sigmoid
    '''
    xgb_params = tune_xgb(X, y)
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    tree = NRFRegressionTreeNode(level=1, max_level=1, xgb_params=xgb_params, input_dim=X.shape[1])
    tree.fit(X_train, y_train)
    
    y_pred = tree.predict(X_test) > 0.5
    y_pred = np.array(y_pred, dtype=np.int8)
    y_proba = tree.predict_proba(X_test)[:,1]
    y_pred_train = np.array(tree.predict_proba(X_train)>0.5, dtype=np.int8)[:,1]
    
    print('train',classification_report(y_train, y_pred_train))
    print('test',classification_report(y_test, y_pred))
    #print(roc_auc_score(y_test, y_proba))
    
    plt.scatter(y_test+np.random.normal(0,0.05,size=len(y_test)), y_proba, alpha=0.2, s=4)
    plt.show()
    
    fpr, tpr, th = roc_curve(y_test, y_proba)
    auc = roc_auc_score(y_test, y_proba)
    print("AUC:", round(auc,4))
    
    plt.plot(fpr, tpr)
    plt.title('MCQ160A AUC curve:' +str(round(auc,4)))
    plt.show()
    df_auc = {'fpr':fpr, 'tpr':tpr, 'th':th}
    df_auc = pd.DataFrame(df_auc)
    #df_auc.to_excel('H:/projects/BLUE FOOD/causal_dose response/MCQ160A_NN_bestAUC.xlsx')
    
    
    import torch
    tree.fit(X,y)
    torch.save(tree, './NNTree_MCQ160A.pth')
    '''
    import pandas
    tree.fit(X, y)
    D_ground = dict()
    y_ground_p = tree.predict_proba(X_0)[:,1]
    y_i_p = tree.predict_proba(X)[:,1]
    D_ground['MCQ160A_control'] = y_ground_p
    D_ground['MCQ160A_treated'] = y_i_p
    df = pandas.DataFrame(D_ground)
    df.to_excel('../results/MCQ160A_outcomes_controlVStreat.xlsx')
    '''
    return


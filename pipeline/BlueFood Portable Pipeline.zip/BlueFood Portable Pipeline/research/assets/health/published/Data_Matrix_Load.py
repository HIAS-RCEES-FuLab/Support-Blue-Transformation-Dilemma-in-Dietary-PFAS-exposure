# -*- coding: utf-8 -*-
"""
Created on Mon Apr 21 16:15:56 2025

@author: huboy
"""


from scipy.stats import norm
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt
import numpy as np
# Use defaults
import pandas
import random
import warnings
from sklearn.utils.class_weight import compute_class_weight

warnings.simplefilter('ignore')
def ifAllInt(L):
    Yes = True
    for x in L:
        if x != int(x):
            Yes = False
            break
    return Yes

def read_taginfo(path, filename):
    D_info = dict()
    with open(path+filename, mode='r', encoding='utf-8-sig') as file:
        Info = False
        for line in file:
            if 'row' in line:
                Info = True
                if 'classification' in line:
                    row_number = int( line.split(' ')[2] )
                    info = [row_number, 'classification']
                elif 'regression' in line:
                    row_number = int( line.split(' ')[2] )
                    info = [row_number, 'regression']
            elif Info and 'row' not in line:
                score = float( line.split(' ')[0] )
                info.append( score )
                D_info[info[0]] = [info[1], info[2]]
                Info = False
            else:
                pass
                    
    return D_info

def get_info(D_info, class_th=0.9, reg_th=0.49):
    L_rownumber = []
    for num in D_info:
        if D_info[num][0] == 'classification':
            if D_info[num][1] >= class_th and D_info[num][1] != 1:
                L_rownumber.append(num)
        elif D_info[num][0] == 'regression' and D_info[num][1] != 1:
            if D_info[num][1] >= reg_th:
                L_rownumber.append(num)
    return L_rownumber
    
def read_tagtouse(path = 'G:/correlation 2013-2014 NHANEs/0906 filter (all)/',
                  filename = 'dataclean exp50 records by histXGB.txt',
                  class_th=0.9,
                  reg_th=0.49):
    D = read_taginfo(path, filename)
    L_rownumber = get_info(D, class_th, reg_th)
    return L_rownumber


def load_data(L_files, path, disease):
    dataframe = None
    for filename in L_files:
        dataframe_new = pandas.read_excel(path + '/' +filename, sheet_name=disease)
        try:
            dataframe = pandas.merge(dataframe, dataframe_new, how='outer')
        except:
            dataframe = dataframe_new
            
    #print(dataframe)
    return dataframe

def delete_poor_col(df, path = 'G:/correlation 2013-2014 NHANEs/0906 filter (all)/',
                  filename = 'dataclean exp50 records by histXGB.txt',
                  class_th=0.9,
                  reg_th=0.49):
    L_tag = read_tagtouse(path, filename, class_th, reg_th)
    arr_tag = np.arange(len(df.columns))
    L_tag_del = [i for i in arr_tag if i not in L_tag if i >=28]
    colnames = df.columns
    L_tagname = [colnames[i] for i in L_tag_del]
    df = df.drop(labels = L_tagname, axis=1)
    return df

def readtag(tagfile, path):
    import csv
    D_tagtype = dict()
    with open(path+tagfile, mode='r', encoding='utf-8-sig') as file:
        data = csv.reader(file)
        for line in data:
            try:
                D_tagtype[line[0]].append(line[1])
            except KeyError:
                D_tagtype[line[0]] = [line[1]]
    return D_tagtype

def split_data(data, X_label, Y_label, Y0_label, T_label, W_label, r=5):
    #data['P_heart_attack'] = norm.ppf(data['P_heart_attack'] )
    n = len(data)
    # food A	food B	chemconc Aa	chemconc Ab	chemconc Ba	chemconc Bb	exposure a	exposure b	geno_defact	age	indicator 1	indicator 2	indicator 3	P_heart_attack confirmed
    X_arr = np.array([ data[item] for item in X_label + W_label]).T
    Y_arr = np.array([ data[item] for item in Y_label + T_label + Y0_label]).T
    #print(np.shape(X_arr), np.shape(Y_arr))
    X_train, X_test, y_train, y_test = train_test_split(X_arr, Y_arr, test_size=1/r )
    if W_label != []:
        nx = len(X_label)
        W_train = X_train[:,nx:]
        W_test= X_test[:,nx:]
        X_train = X_train[:,0:nx]
        X_test = X_test[:,0:nx]
    else:
        W_train, W_test = None, None
        
    ly = len(Y_label)
    lT = len(T_label)
    ly0 = len(Y0_label)
    
    
    Y_train = y_train[:,0:ly]
    T_train = y_train[:,ly:ly+lT]
    y0_train = y_train[:,ly+lT:]
    
    Y_test= y_test[:,0:ly]
    T_test = y_test[:,ly:ly+lT]
    y0_test = y_test[:,ly+lT:]
    
    if lT == 0 and ly0 == 0:
        y0_train, y0_test, T_train, T_test = None, None, None, None
    elif lT == 0:
        T_train, T_test = None, None
    elif ly0 == 0:
        y0_train, y0_test = None, None
        
        
    return X_train, X_test, Y_train, Y_test, y0_train, y0_test, T_train, T_test, W_train, W_test

def save_effects(T0, T1, effect, path, filename):
    import pandas as pd
    Data = dict()
    a,b = np.shape(T0)
    for i in range(b):
        Data['T0:'+str(i)] = [x for x in T0[:,i]]
    for i in range(b):
        Data['T1:'+str(i)] = [x for x in T1[:,i]]
    N = np.ndim(effect)
    if N == 2:
        u,v = np.shape(effect)
        for i in range(v):
            Data['effect:'+str(i)] = [x for x in effect[:,i]]
    elif N == 1:
        Data['effect:0'] = [x for x in effect]
    else:
        raise ValueError('effect has invalid dim. '+str(N))
        
    df = pd.DataFrame(Data)
    df.to_excel(path+filename)
    
    return

#from econml.orf import DMLOrthoForest
def DMLOrthoForest():
    return
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor, GradientBoostingRegressor
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, GradientBoostingClassifier
from sklearn.gaussian_process import GaussianProcessRegressor
from xgboost import XGBRegressor as xgbReg
from xgboost import XGBClassifier as xgbCls
from xgboost import plot_tree
from sklearn.neural_network import MLPRegressor
import scipy

from sklearn import metrics
from sklearn.model_selection import train_test_split
from scipy.stats import pearsonr
import shap

def striplist_by_mae(y_pred, y, inds, mae):
    diff = np.abs(y_pred-y)
    return inds[diff>2.3*mae]

def check_overfit_reg(best_model, X, y):
    clf = best_model
    L_mse = []
    L_r2 = []
    L_r2_tr = []
    L_split = []
    N_parallals = 20
    train_lim = int(0.05*len(y))
    for split in np.arange(0.75,0.96,0.05):
        split = round(split,2)
        for state in range(N_parallals):
            X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=split, test_size=0.0499, random_state=state)
            clf.fit(X_train, y_train)
            y_testpred = clf.predict(X_test)
            L_mse.append(metrics.mean_squared_error(y_test, y_testpred))
            L_r2.append(metrics.r2_score(y_test, y_testpred))
            L_r2_tr.append(metrics.r2_score(y_train[:train_lim], clf.predict(X_train[:train_lim])))
            L_split.append(split)
    r, p = pearsonr(L_r2_tr, L_split)
    X_splits = np.array(L_split)+scipy.stats.norm.rvs(0,0.001,size=len(L_split))
    plt.scatter(X_splits, L_r2, alpha=0.8)
    plt.scatter(X_splits, L_r2_tr, alpha=0.8)
    plt.show()
    print('prob being not overfit:', p, 'mse pearson r to test size', r,
          'mse average:', np.average(np.array(L_mse)), 'R2 average:', np.average(np.array(L_r2)))
    return L_mse, L_split, N_parallals
    
def check_overfit_class(best_params, X, y):
    clf = xgbCls(max_depth=best_params['max_depth'],
                 learning_rate=best_params['learning_rate'],
                 n_estimators = best_params['n_estimators'],
                 colsample_bytree = best_params['colsample_bytree'],
                 gamma = best_params['gamma'],
                 reg_alpha = best_params['reg_alpha'],
                 min_child_weight = best_params['min_child_weight']
                 )
    L_f1 = []
    L_split = []
    for split in np.arange(0.65,0.96,0.05):
        split = round(split,2)
        for state in range(10):
            X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=split, test_size=0.05, random_state=state)
            clf.fit(X_train, y_train)
            y_testpred = clf.predict(X_test)
            L_f1.append(metrics.f1_score(y_test, y_testpred))
            L_split.append(split)
    r, p = pearsonr(L_f1, L_split)
    print('prob being not overfit:', p, 'F1 pearson r to test size', r, 'f1 average:', np.average(np.array(L_f1)))
    return L_f1, L_split, 10

def check_shapvalues(trained_model, X_test):
    # Explain predictions using SHAP
    explainer = shap.Explainer(trained_model)
    shap_values = explainer(X_test)    # X_test: DataFrame or numpy array
    
    # Visualize feature importance
    shap.summary_plot(shap_values, X_test)
    return

def filtering(X, X_ground):
    from sklearn.decomposition import PCA
    pca = PCA()
    a,b = np.shape(X)
    for j in range(b):
        k = 1/np.sum(X[:,j])
        X[:,j] = X[:,j]*k
        X_ground[:,j] = X_ground[:,j]*k
    #X = pca.fit_transform(X)
    
    return X, X_ground

def grid_y(X, y):
    X = X[y > 0.1]
    y = y[y > 0.1]
    ave = np.average(y)
    sd = np.std(y)
    t_th = 10
    y = y[(y<t_th*sd+ave)+(y>-t_th*sd+ave)]
    X = X[(y<t_th*sd+ave)+(y>-t_th*sd+ave)]
    print('filtered by y and its sd')
    return X, y, (ave, sd, t_th)

from sklearn.metrics import make_scorer, precision_score
negative_precision = make_scorer(
    lambda y_true, y_pred: ((2-precision_score(y_true, y_pred))**4-1)**0.25,
    greater_is_better=False  # Minimize the score
)


def prepare_banchmark(data, X_label, Y_label, T_label, W_label, mode='Reg', ground = 0.01):
    X_cov = np.array([data[x] for x in X_label]+[data[w] for w in W_label]).T
    X = np.concatenate([ X_cov, np.array( [data[t] for t in T_label]  ).T], axis=1) # 
    X_ground= np.concatenate([ X_cov, np.array( [np.ones(len(data[t]))*ground for t in T_label] ).T ], axis=1)
    y = np.array( [data[Y] for Y in Y_label] ).T
    L_labels = X_label + W_label + T_label
    # for each outcome, first get SHAP values, then refine data
    from sklearn.inspection import permutation_importance
    from sklearn.model_selection import GridSearchCV
    outcomes = ['MCQ080', 'BPQ020', 'MCQ160A', 'DIQ010'] # for classification xgb
    
    #outcomes = ['BMXBMI']
    #excluses = []
    #outcomes = ['LBXHGB']
    #excluses = ['LBXMCHSI','LBXRBCSI']
    #outcomes = ['LBDSGBSI']
    #excluses = ['LBXSGB']
    #outcomes = ['LBXTC'] 
    #excluses = ['LBDHDDSI','LBXSCH'] # 'LBXHGB'|'LBXTC', 'LBDHDDSI', 'LBXRBCSI'
    outcomes = ['BPQ020']
    excluses = []
    # 'MCQ080', 'BPQ020', 'MCQ160A', 'KIQ022' tested in (c).py
    # medium value of 'MCQ160E' = 0~
    # medium value of 'MCQ220', 'MCQ160C', 'MCQ010' < 0
    # 'MCQ160F' has 60% increasing risk rate
    # 'PFQ057' is also good
    L_inds = [ Y_label.index(outcome) for outcome in outcomes ]
    L_excs = [ Y_label.index(excluse) for excluse in excluses ]
    D_ground = dict()
    df_score = dict()
    for i in L_inds:
        print(Y_label[i],'/',Y_label,len(Y_label))
        X_i = X #np.concatenate( [X, y[:,[j for j in range(len(Y_label)) if not j in [i]+L_excs]]], axis=1)
        L_labels_i = L_labels# + [Y_label[j] for j in range(len(Y_label)) if not j in [i]+L_excs]

        if mode == 'Binary':
            y_i = 2-y[:,i]
            # use GB to prepare the SHAP value

            if Y_label[i] == 'BPQ020':
                L_selcted_label = ['DMDMARTL','HUQ030','HUQ010','DMDCITZN','SMAQUEX','LBXHA','LBXPFOS','HSD010','BPACSZ',
                                   'DR2TCRYP']
            # BPQ020
            
            if Y_label[i] == 'MCQ160A':
                L_selcted_label = ['DMDMARTL','HUQ010','HUQ030','DR1TNUMF','DR2TTFAT','DR1TVB2','PFQ051','SMAQUEX','IMQ020',
                                   'WTDR2D','DR2TS060','LBDSIRSI','DR1TVB1','LBXPFHS','LBXPFNA','LBXPFOA','LBXPFOS' ] #
            #(MCQ160A), objective='binary:hinge'
            
            X_= X_i[:,[L_labels_i.index(feature) for feature in L_selcted_label]]
            X_ground_i = X_ground[:,[L_labels_i.index(feature) for feature in L_selcted_label]]
            '''
            # for all outcomes, the results are in 
            params = {'max_depth': [1,3,5,8,11,15],
                      'learning_rate': [0.01,0.03,0.1],
                      'n_estimators': [120],
                      'colsample_bytree':[0.5], #0.7,0.8
                      'min_child_weight':[0.1], #,0.07,0.13
                      'gamma': [10], #[0.5,1,3],
                      'reg_alpha':[10] #[1,3,6]
                      }
            clf = xgbCls(objective="binary:logistic", scale_pos_weight=2.1)
            grid = GridSearchCV(clf, params, cv=5, scoring='f1' ,verbose=1) #negative_precision
            grid.fit(X_, y_i)
            best_model = grid.best_estimator_
            best_params = grid.best_params_
            print('precision score of banchmark model:', -grid.best_score_)
            print(best_params)
            #check_overfit_class(best_params, X_, y_i)
            L_f1 = []
            L_auc = []
            for k in range(1):
                X_train, X_test, y_train, y_test = train_test_split(X_, y_i, test_size=0.3)
                best_model.fit(X_train, y_train)
                y_pred_proba = best_model.predict_proba(X_test)[:,1]
                y_pred_t = best_model.predict(X_train)
                auc = metrics.roc_auc_score(y_test, y_pred_proba)
                L_auc.append(auc)
                y_pred = best_model.predict(X_test)
                precision, recall, thresholds = metrics.precision_recall_curve(y_test, y_pred_proba)
                # Find threshold that maximizes F1
                L_f1.append(metrics.f1_score(y_test, y_pred))
            print(metrics.classification_report(y_train, y_pred_t))
            print(metrics.classification_report(y_test, y_pred))            
            
            fpr, tpr, th = metrics.roc_curve(y_test, y_pred_proba)
            aveauc = np.average(np.array(L_auc))
            stdauc = np.std(np.array(L_auc))
            
            print(f'refined model-->average_diagnosed {aveauc:.4f}, stdev {stdauc:.4f}')
            plt.plot(fpr, tpr)
            plt.title('AUC curve:' +str(round(aveauc,4)))
            plt.show()
            
            print('contribution values:')
            X_train, X_test, y_train, y_test = train_test_split(X_, y_i, test_size=0.3)
            best_model.fit(X_train, y_train)
            result_all = permutation_importance(best_model, X_test, y_test, n_repeats=10, random_state=42)
            print(list(result_all.importances_mean))
            L_score, L_split_train, N_cv_overfit = check_overfit_class(best_params, X_, y_i)
            print('##################-----------------##################-----------------#######################')
            
            y_ground_p = best_model.predict_proba(X_ground[:,np.abs(result.importances_mean) > threshold])
            y_i_p = best_model.predict_proba(X_)
            D_ground[Y_label[i] +'_control'] = y_ground_p[:,0]
            D_ground[Y_label[i] +'_treated'] = y_i_p[:,0]
            '''
            #delta_y = best_model.predict_proba(X)[:,1] - best_model.predict_proba(X_ground)[:,1]
            
        #check_shapvalues(best_model, X_test=X_)
    #df = pandas.DataFrame(D_ground)
    #df.to_excel('F:/NHANEs 2003-2016 (add 2018)/conditioned patients/ground_PFAS_outcome_classification 2504280845.xlsx')
    # return the change of outcome (or proba for binary) from ground; model_trained and parameters; overfit test scores, split train size, and cv level for each split size
    return X_, y_i, X_ground_i #delta_y, tuple([best_model, best_params]), tuple([L_score, L_split_train, N_cv_overfit])

def compare_banchmark(data, X_label, Y_label, T_label, W_label, delta_y, mode='Reg', ground = 0.01):
    X = np.array( [data[x] for x in X_label] ).T
    T = np.array( [data[t] for t in T_label] ).T
    W = np.array( [data[w] for w in W_label] ).T
    Y = np.array( [data[y] for y in Y_label] ).T
    T0 = np.ones_like(T)*ground
    model = DMLOrthoForest()
    delta_Y = []
    delta_Ysd = []
    for i in range(len(Y_label)):
        print(Y_label[i], 'is fitting')
        model.fit(X=X, T=T, Y=Y[:,i], W=W, inference='bootstrap')
        # assume the log based relationship
        treatment_effects = model.effect(X=X, T0=np.log10(T0), T1=np.log10(T))
        treatment_effects_interval = model.effect_interval(X=X, T0=np.log10(T0), T1=np.log10(T), alpha=0.1)
        delta_Y.append(treatment_effects)
        delta_Ysd.append(treatment_effects_interval)
    delta_Y = np.array(delta_Y).T
    D_scores = compare_dyvalues(Y_label, delta_y, delta_Y, mode)
    return delta_Y, np.array(delta_Ysd).T, D_scores

def compare_dyvalues(Y_label, delta_y, delta_Y, mode):
    D_scores = dict()
    if mode == 'Reg':
        for i in range(len(Y_label)):
            D_scores[Y_label[i]] = [ metrics.r2_score(delta_y[:,i], delta_Y[:,i]), metrics.mean_squared_error(delta_y[:,i], delta_Y[:,i]), metrics.mean_absolute_error(delta_y[:,i], delta_Y[:,i]) ]
    elif mode == 'Binary':
        for i in range(len(Y_label)):
            D_scores[Y_label[i]] = [ metrics.r2_score(delta_y[:,i], delta_Y[:,i]), metrics.mean_squared_error(delta_y[:,i], delta_Y[:,i]), metrics.mean_absolute_error(delta_y[:,i], delta_Y[:,i]) ]
    return D_scores

def stability_valid(data, X_label, Y_label, T_label, W_label, mode='Reg', ground = 0.01):
    X = np.array( [data[x] for x in X_label] ).T
    T = np.array( [data[t] for t in T_label] ).T
    W = np.array( [data[w] for w in W_label] ).T
    Y = np.array( [data[y] for y in Y_label] ).T
    model = DMLOrthoForest()
    
    '''test by add random varibles in treatment''' 
    T_test1 = np.concatenate([T, ground + 10**norm.rvs(0.3,0.3, size=(np.shape(T)[0],1))], axis=0)
    T0_test1 = np.ones_like(T_test1)*ground
    arr_dy_test1 = []
    for i in range(len(Y_label)):
        model.fit(X=X, T=T_test1, Y=Y[:,i], W=W, inference='bootstrap')
        treatment_effects = model.effect(X=X, T0=np.log10(T0_test1), T1=np.log10(T_test1))
        arr_dy_test1.append(treatment_effects)
    arr_dy_test1 = np.array(arr_dy_test1).T
    
    '''test by add random varibels in covariates'''
    D_results = dict()
    X_random = X
    for i in range(10):
        X_random = np.concatenate([X_random, norm.rvs(size=(np.shape(X)[0],1))], axis=0)
        arr_dy_test2 = []
        sd_dy_test2 = []
        for j in range(len(Y_label)):
            model.fit(X=X, T=T, Y=Y[:,i], W=W, inference='bootstrap')
            treatment_effects = model.effect(X=X_random, T0=np.log10(np.ones_like(T)*ground), T1=np.log10(T))
            treatment_effects_interval = model.effect_interval(X=X_random, T0=np.log10(np.ones_like(T)*ground), T1=np.log10(T), alpha=0.1)
            arr_dy_test2.append(treatment_effects)
            sd_dy_test2.append(treatment_effects_interval)
        D_results[i] = [np.array(arr_dy_test2).T, np.array(sd_dy_test2).T] # second term contains [uplim, lowlim]
        
    '''compare the test results'''
    # for test1, diract subtruction
    # for test2, check variation of sd by increasment of error covariates
    
    return arr_dy_test1, D_results

def broken_relationship_test(data, X_label, Y_label, T_label, W_label, mode='Reg', ground = 0.01, labelbroken = 'T'):
    #import random
    X = np.array( [data[x] for x in X_label] ).T
    T = np.array( [data[t] for t in T_label] ).T
    W = np.array( [data[w] for w in W_label] ).T
    Y = np.array( [data[y] for y in Y_label] ).T
    T0 = np.ones_like(T)*ground
    if labelbroken == 'T':
        T = list(T)
        random.shuffle(T)
        T = np.array(T)
    elif labelbroken == 'X':
        X = list(X)
        random.shuffle(X)
        X = np.array(X)
    elif labelbroken == 'Y':
        Y = list(Y)
        random.shuffle(Y)
        Y = np.array(Y)
    model = DMLOrthoForest()
    delta_Y = []
    delta_Ysd = []
    for i in range(len(Y_label)):
        print(Y_label[i], 'is fitting')
        model.fit(X=X, T=T, Y=Y[:,i], W=W, inference='bootstrap')
        # assume the log based relationship
        treatment_effects = model.effect(X=X, T0=np.log10(T0), T1=np.log10(T))
        treatment_effects_interval = model.effect_interval(X=X, T0=np.log10(T0), T1=np.log10(T), alpha=0.1)
        delta_Y.append(treatment_effects)
        delta_Ysd.append(treatment_effects_interval)
    delta_Y = np.array(delta_Y).T
    
    return delta_Y, np.array(delta_Ysd).T
        
def data_matrix_load(disease):
    L_files = ['data_outcome diseases.xlsx']
    path = '.../double machine learning/input_file/NHANES data'
    data = load_data(L_files, path, disease)
    print('raw data length:',len(data.columns))
    #data = delete_poor_col(data)
    #print('filted by model estimation quality, data length:',len(data.columns))
    tagfile = 'tag diseases.csv'
    D_tagtype = readtag(tagfile, path+'/')
    mode = 'Binary' # or Reg Binary Multiclass
    
    X_label = [ tag for tag in D_tagtype['covariate'] if tag in data.columns]
    Y_label = [ tag for tag in D_tagtype['outcome'] if tag in data.columns]
    T_label = [ tag for tag in D_tagtype['treatment'] if tag in data.columns]
    W_label = [ tag for tag in D_tagtype['instrumental'] if tag in data.columns]
    
    '''#first test by compare the results of other models'''
    # 1. obtain the banchmark value of outcome difference (assumed the ground =0.01)
    X, y, X_0 = prepare_banchmark(data, X_label, Y_label, T_label, W_label, mode=mode, ground = 0.01)
    
    return X, y, X_0

#test_DML_OrthForest()
"""Execute the original 0106 annual workflow; only paths and US output storage are adapted."""
import os
from tempfile import TemporaryDirectory
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[name]='1'
import argparse,ast,concurrent.futures,contextlib,csv,hashlib,json,math,random,re,statistics,time,zipfile
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
import scipy.stats as stat
ROOT=Path(__file__).resolve().parent.parent;INPUT=ROOT/'inputs';OUT=ROOT/'results'
SETTINGS=json.loads((ROOT/'settings.json').read_text())
CHEMS=['PFOS','PFOA','PFHxS','PFNA','PFDA','PFUnDA','PFDoDA']
LAND={'Pork','Beef','Meat, Other','Mutton','Egg','Poultry'}
BW=62.
START_SEED=301
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def seed(*parts):return int.from_bytes(hashlib.sha256('|'.join(map(str,parts)).encode()).digest()[:4],'little')
def gm(a):
    a=np.asarray(a,float)
    if not np.isfinite(a).all() or (a<0).any():raise ValueError('Nonfinite or negative simulated values')
    return 0. if (a==0).any() else float(np.exp(np.log(a).mean()))
def load_model():
    source=ROOT/'code/exposure_model.py';tree=ast.parse(source.read_text(encoding='utf-8-sig'))
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) or (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='D_contaminatedregion' for t in n.targets))]
    module=ast.Module(body=nodes,type_ignores=[]);ast.fix_missing_locations(module)
    ns={'np':np,'pd':pd,'csv':csv,'random':random,'math':math,'stat':stat,'scipy':scipy,'stats':statistics,'os':os,'re':re,
        'Path':Path,'ROOT':ROOT,'INPUT':INPUT,'RUN_OUTPUT':OUT/'standalone'}
    exec(compile(module,str(source),'exec'),ns)
    models=ns['read_piecewise']();assert len(models)==42
    for food in LAND:
        assert ns['filterout_outtime']('PFOS',food,0,2016)
        assert ns['get_k'](models,0,2016,food,'PFOS')==1
    return ns
def run_case(year,rep,case,folder):
    ns=load_model();captured={'concentrations':{},'exposures':{},'dishes':[]}
    counts={'terrestrial_k_calls':0,'terrestrial_nonunit_k':0,'terrestrial_filter_rejections':0,'aquatic_filter_acceptances':0,'aquatic_filter_rejections':0}
    original_k=ns['get_k'];original_filter=ns['filterout_outtime'];original_dishes=ns['get_dishes']
    def observe_k(models,sampling_year,simyear,food,chem):
        value=original_k(models,sampling_year,simyear,food,chem)
        if food in LAND:counts['terrestrial_k_calls']+=1;counts['terrestrial_nonunit_k']+=int(value!=1)
        return value
    def observe_filter(chem,food,sampling_year,simyear):
        result=original_filter(chem,food,sampling_year,simyear)
        if food in LAND:counts['terrestrial_filter_rejections']+=int(not result)
        else:counts['aquatic_filter_acceptances' if result else 'aquatic_filter_rejections']+=1
        return result
    def observe_dishes(*args,**kwargs):
        result=original_dishes(*args,**kwargs);captured['dishes'].append({k:v.copy() for k,v in result.items()});return result
    def save_conc(values,name,*args,**kwargs):
        component='terrestrial' if name.startswith('terri') else 'aquatic'
        captured['concentrations'][component]={k:np.asarray(v,float) for k,v in values.get('United States',{}).items()}
    def save_expo(values,path,*args,**kwargs):
        component='aquatic' if '_aqours_exposure' in path else 'terrestrial' if '_terri_exposure' in path else 'total'
        captured['exposures'][component]={k:np.asarray(v,float) for k,v in values.get('United States',{}).items()}
    ns.update(get_k=observe_k,filterout_outtime=observe_filter,get_dishes=observe_dishes,save_concbynation=save_conc,save_exposure=save_expo)
    random.seed(seed(year,START_SEED+rep-1,'full_raw','python'));np.random.seed(seed(year,START_SEED+rep-1,'full_raw','numpy'))
    started=time.monotonic()
    with (folder/f'{case}_r{rep}.log').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
        with TemporaryDirectory(prefix='bluefood-us-') as intermediate:
            ns['RUN_OUTPUT']=Path(intermediate)
            ns['flowwork_year']('PFAS',year,str(INPUT/'diets')+'/',str(INPUT/'trades')+'/',str(INPUT/'concentration_cases'/case)+'/')
    assert len(captured['dishes'])==2
    assert counts['terrestrial_nonunit_k']==0 and counts['terrestrial_filter_rejections']==0
    arrays={};metrics=[];ref=json.loads((INPUT/'reference.json').read_text())[str(year)]
    for comp,values in captured['concentrations'].items():
        for (food,chem),v in values.items():gm(v);arrays[f'conc_{comp}^{food}^{chem}']=v
    for comp,values in captured['exposures'].items():
        for chem,v in values.items():assert len(v)==100000;arrays[f'expo_{comp}^{chem}']=v
    for index,dishes in enumerate(captured['dishes']):
        for food,v in dishes.items():arrays[f'dish_{index}^{food}']=v
    filename=folder/f'{case}_r{rep}.npz';np.savez_compressed(filename,**arrays)
    for comp in ['aquatic','terrestrial','total']:
        values=captured['exposures'].get(comp,{})
        for chem in CHEMS:
            v=values.get(chem)
            metrics.append({'year':year,'replicate':rep,'case':case,'component':comp,'chemical':chem,
                'status':'available' if v is not None else 'missing_compound','gmean_EDI':None if v is None else gm(v/BW),
                'mean_EDI':None if v is None else float(v.mean()/BW),'zero_products':None if v is None else int((v==0).sum()),
                'reference_gmean_EDI':ref['total'][chem] if comp=='total' else ref['aquatic'][chem] if comp=='aquatic' else None})
    total=captured['exposures'].get('total',{});available=all(c in total for c in CHEMS)
    summed={'year':year,'replicate':rep,'case':case,'status':'available' if available else 'incomplete','compounds_available':len(set(total)&set(CHEMS)),
        'Sum7_gmean':sum(gm(total[c]/BW) for c in CHEMS) if available else None,
        'true_total_gmean':gm(np.sum([total[c] for c in CHEMS],axis=0)/BW) if available else None,'reference_Sum7_gmean':sum(ref['total'].values())}
    record={'year':year,'replicate':rep,'case':case,'seed':START_SEED+rep-1,'body_weight_kg':BW,'seconds':round(time.monotonic()-started,1),'counts':counts,
        'npz_sha256':sha(filename),'available_total_compounds':len(set(total)&set(CHEMS)),'full_original_flowwork_year':True}
    (folder/f'{case}_r{rep}.json').write_text(json.dumps(record,indent=2))
    return metrics,summed,record

def run_replicate(rep):
    started=time.monotonic();metrics=[];sums=[];checks=[]
    assert list(SETTINGS['cases'])==['baseline']
    for year in range(2003,2017):
        folder=OUT/'annual'/str(year);folder.mkdir(parents=True,exist_ok=True)
        checkpoint=folder/f'baseline_r{rep}_metrics.json'
        if checkpoint.exists():
            cached=json.loads(checkpoint.read_text())
            assert cached['source_sha256']==SETTINGS['source_sha256']
            m,s,c=cached['metrics'],cached['sum'],cached['check']
            assert sha(folder/f'baseline_r{rep}.npz')==c['npz_sha256']
        else:
            m,s,c=run_case(year,rep,'baseline',folder)
            checkpoint.write_text(json.dumps({'source_sha256':SETTINGS['source_sha256'],'metrics':m,'sum':s,'check':c}))
        metrics.extend(m);sums.append(s);checks.append(c)
        print('CELL_COMPLETE '+json.dumps({'replicate':rep,'year':year,'seconds':c['seconds'],'total_compounds':c['available_total_compounds']}),flush=True)
    folder=OUT/'replicates'/f'rep_{rep}';folder.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(metrics).to_csv(folder/'EDI.csv',index=False)
    pd.DataFrame(sums).to_csv(folder/'Sum7.csv',index=False)
    report={'replicate':rep,'years':14,'seconds':round(time.monotonic()-started,1),'checks':checks}
    (folder/'complete.json').write_text(json.dumps(report,indent=2))
    return {'replicate':rep,'years_complete':14,'seconds':report['seconds'],'all_total_compounds_available':all(c['available_total_compounds']==7 for c in checks)}

def verify_first_three_replay():
    baseline=ROOT.parent/SETTINGS['replay_baseline'];identical=0
    for year in range(2003,2017):
        for rep in (1,2,3):
            previous=baseline/f'results/annual/{year}/baseline_r{rep}.npz'
            current=OUT/f'annual/{year}/baseline_r{rep}.npz'
            expected=json.loads(previous.with_suffix('.json').read_text())['npz_sha256']
            assert sha(previous)==expected,str(previous)
            with np.load(previous) as a,np.load(current) as b:
                assert set(a.files)==set(b.files)
                for key in a.files:
                    assert np.array_equal(a[key],b[key],equal_nan=True),(year,rep,key)
                    identical+=1
    result={'status':'verified','replayed_runs':42,'arrays_bitwise_identical':identical,'earlier_source_arrays_hash_unchanged':True}
    (ROOT/'REPLAY_VERIFICATION.json').write_text(json.dumps(result,indent=2))
    return result

def finish():
    runs=pd.concat([pd.read_csv(OUT/f'replicates/rep_{r}/EDI.csv') for r in range(1,8)],ignore_index=True)
    sums=pd.concat([pd.read_csv(OUT/f'replicates/rep_{r}/Sum7.csv') for r in range(1,8)],ignore_index=True)
    assert len(runs)==2058 and len(sums)==98
    assert not runs.duplicated(['year','replicate','case','component','chemical']).any()
    total=runs[runs.component=='total']
    assert len(total)==686 and (total.status=='available').all()
    assert (total.groupby(['year','chemical']).replicate.nunique()==7).all()
    runs.sort_values(['year','replicate','component','chemical']).to_csv(OUT/'EDI_replicates.csv',index=False)
    sums.sort_values(['year','replicate']).to_csv(OUT/'Sum7_replicates.csv',index=False)
    summary=runs.groupby(['case','component','year','chemical']).agg(gmean_EDI=('gmean_EDI','mean'),gmean_run_SD=('gmean_EDI','std'),mean_EDI=('mean_EDI','mean'),repeats_available=('gmean_EDI','count'),reference_gmean_EDI=('reference_gmean_EDI','first')).reset_index()
    summary.to_csv(OUT/'annual_compound_EDI.csv',index=False)
    sums.groupby(['case','year']).agg(Sum7_gmean=('Sum7_gmean','mean'),Sum7_run_SD=('Sum7_gmean','std'),true_total_gmean=('true_total_gmean','mean'),true_total_run_SD=('true_total_gmean','std'),repeats_available=('true_total_gmean','count')).reset_index().to_csv(OUT/'annual_Sum7.csv',index=False)
    allchecks=[c for r in range(1,8) for c in json.loads((OUT/f'replicates/rep_{r}/complete.json').read_text())['checks']]
    assert len(allchecks)==98
    assert all(c['counts']['terrestrial_nonunit_k']==0 and c['counts']['terrestrial_filter_rejections']==0 for c in allchecks)
    for row in json.loads((ROOT/'INPUT_MANIFEST.json').read_text()):
        p=ROOT/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
    verify_first_three_replay()
    report={'status':'verified','execution':'Alibaba ECS','host':os.environ.get('COMPUTERNAME'),'years':14,'repeats_per_year':7,
        'annual_workflows_completed':98,'PFAS_year_pairs':98,'total_run_gmean_estimates':686,'body_weight_kg':BW,
        'parallel_replicate_workers':7,'source_sha256':SETTINGS['source_sha256'],'workbook_sha256':SETTINGS['workbook_sha256'],
        'all_input_hashes_unchanged':True,'terrestrial_k':1,'terrestrial_filter_rejections':0,
        'full_original_0106_workflow':True,'trend_input':'0106_added','missing_total_rows':0,
        'versions':{'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__}}
    (ROOT/'ECS_COMPLETION.json').write_text(json.dumps(report,indent=2))
    files=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='COMPLETED_MANIFEST.json']
    (ROOT/'COMPLETED_MANIFEST.json').write_text(json.dumps([{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)],indent=2))
    print('COMPLETED '+json.dumps(report),flush=True)

def package():
    assert json.loads((ROOT/'ECS_COMPLETION.json').read_text())['status']=='verified'
    archive=ROOT.parent.parent/'historical_exposure_summary.zip'
    files=[p for p in ROOT.rglob('*') if p.is_file() and p.suffix!='.npz' and '__pycache__' not in p.parts]
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
        for p in files:z.write(p,p.relative_to(ROOT).as_posix())
    print('PACKAGE '+json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'files':len(files)}),flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=7);ap.add_argument('--package',action='store_true');args=ap.parse_args()
    if args.package:package();return
    assert os.environ.get('PYTHONHASHSEED')=='0'
    OUT.mkdir(exist_ok=True)
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(run_replicate,rep) for rep in range(1,8)]
        for future in concurrent.futures.as_completed(futures):print('REPLICATE_COMPLETE '+json.dumps(future.result()),flush=True)
    finish();package()
if __name__=='__main__':main()

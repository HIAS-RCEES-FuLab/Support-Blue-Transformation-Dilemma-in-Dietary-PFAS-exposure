# -*- coding: utf-8 -*-
"""
Created on Thu Nov  7 10:48:08 2024

@author: huboy

Created on Fri Nov 24 13:22:51 2023
1. read the file for pollutant
    1.1 filter the file infor with, std them into avalible set: uniform, normal, lognormal
    1.2 read the fishery distribution file for FW, PS, SS
2. get the conc summary for their sumvalues, and save with the same format as individuals
    2.1 for each country, get a simulation pool for each individual and their sum
    2.2 for each country, save the conc summary for each individual in: mean, medium, sd, 97.5%, 99%
"""

import codecs
import re
import csv
import numpy as np
import scipy.stats as stat
import scipy
import statistics as stats
import random
import os
import matplotlib.pyplot as plt
from pyecharts import options as opts
from pyecharts.charts import Map
import math
import pandas as pd

from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
INPUT = ROOT/'inputs'
RUN_OUTPUT = ROOT/'results/standalone'

heatmap_colors = [
    "#1919CC",  # 0.00 - darkest blue
    "#4C4CFF",  # 0.33
    "#7F7FFF",  # 0.66 - lightest blue
    "#FFFFFF",  # 1.00 - pure white (pivot)
    "#FFFF99",  # 1.10
    "#FFFF66",  # 1.15 - bright yellow
    "#FFEE58",  # 1.20 - lemon
    "#FFDD33",  # 1.25 - golden yellow
    "#FFCC00",  # 1.30 - gold
    "#FFBB00",  # 1.40 - amber
    "#FFAA00",  # 1.50
    "#FF9900",  # 1.60 - orange
    "#FF8800",  # 1.70
    "#FF7700",  # 1.80 - bright orange
    # Reds to Black (7 steps)
    "#FF6600",  # 1.90 - orange-red
    "#FF4400",  # 2.00
    "#DD2200",  # 2.20
    "#CC0000",  # 2.40 - pure red
    "#AA0000",  # 2.60 - dark red
    "#660000",  # 2.80 - very dark red
    "#000000"   # 3.00 - black
]

D_contaminatedregion = ['US,Mississippi River(MR 11)',
                        'China,Xiaoqing River',
                        'China,Lake Baiyangdian',
                        #'France,Loire River/France,North Atlantic',
                        'Canada,Etobicoke Creek River/Lake Ontario',
                        #'South Africa,Vaal River',
                        #'Canada,Arctric Lakes',
                        #'Austria/Belgium/Cyprus/Czech/France/German/Greece/Ireland/Italy/Norway/Slovenia/Spain/UK',
                        #'China,South China Sea/China,Pearl River',
                        'Netherlands(village market)',
                        'Netherlands, polluted',
                        #'Netherlands',
                        'US,Mississippi River(2008 hotsite)',
                        #'US,Mississippi River',
                        #'Denmark,North Sea/Denmark,Baltic Sea',
                        'Spain,Ebro river',
                        #'Norway,Norwegian Sea',
                        #'US,Lake Ontario',
                        #'Canada,Lake Ontario',
                        #'France,Loire River/France,Rhone River/France,Seine River/France,Garonne River/France,Dorgogne River/France,Rhine River',
                        #'US,Lake Michigan',
                        'US,Lake Little Pine',
                        #'US,Lake Erie',
                        'China(Lake Baiyangdian)',
                        #'Canada,Binbrook Reservoir',
                        'Canada,Welland Canal'
                        ]

def read_PollInFood(path, filename, simyear=None):
    '''
    Pollutant Name/ PollutantName.ABB/ Sample Type/ Sample Fish Type/ Sample Region/ Sample Size/ 0-5
    Sample Name/ Sampling Time/ Site/ Mean(ng/g)/ Median(ng/g)/ Data Type/ SD/ 6-12
    Max/ Min/ LOD(ng/g)/ LOQ(ng/g)
    '''
    D_trans = read_datatrans(path, 'aq and lip fraction.csv')
    D_functions = read_piecewise()
    #D_params = read_decay_by_time()
    D_pollutant_distribution = dict()
    D_summary_pollutants = dict()
    L_sites = set()
    L_pollutant = set()
    with open(path+filename, mode='r', encoding='utf-8-sig', errors='ignore') as file:
        data = csv.reader(file)
        headline = True
        ind_line = 0
        for line in data:
            ind_line = 1 +ind_line
            if headline:
                headline = False
            else:
                # loading data
                if line[8] not in D_contaminatedregion:
                    L_Site = line[8].split('/')
                    #pollname = re.sub('\xa0','',line[0])
                    if '{' in line[1]:
                        PollABB = line[1].split('{')[0]
                    else:
                        PollABB = line[1]
                    if PollABB not in ['PFHxS','PFOS','PFOA','PFDA','PFDoDA','PFNA','PFUnDA']:
                        continue
                    L_years = get_years(line[7])
                    if simyear == None:
                        pass
                    else:
                        for year in L_years:
                            SampleName = line[6]
                            Mean = line[9]
                            Mid = line[10]
                            DataTP = line[11]
                            SD = line[12]
                            Min = line[14]
                            Max = line[13]
                            LOD = line[15]
                            LOQ = line[16]
                            thLOD = 0.1*2
                            try:
                                if float(LOD) >= thLOD:
                                    continue
                            except ValueError:
                                pass
                            try:
                                if float(LOQ) >= thLOD*3.3:
                                    continue
                            except ValueError:
                                pass
                            if '/' not in line[2]:
                                SampleTPs = []
                                SampleSize = int(line[5])
                                SampleTP = line[2]
                                if SampleTP == 'Fishery Product':
                                    Sample_fishTP = line[3]
                                    fish_region = line[4]
                                #check data
                                r, ind1, ind2, Distri, SampleSize = check_data(SampleTP, DataTP, Mean, Mid, SD, Min, Max, LOD, LOQ, SampleSize, D_trans)
                                #SampleSize = int(SampleSize*30/(np.abs(year-simyear)+1))
                                if SampleTP == 'Fishery Product':
                                    if Sample_fishTP == 'Marine/FreshWater' or Sample_fishTP == 'Marine,FreshWater':
                                        SampleTPs = [tuple(['Marine',fish_region]), tuple(['FreshWater',''])]
                                    else:
                                        SampleTP = tuple([Sample_fishTP,fish_region])
                                if len(SampleTPs)==0:
                                    SampleTPs = [SampleTP]
                                for Site in L_Site:
                                    for SampleTP in SampleTPs:
                                        if filterout_outtime(PollABB, SampleTP, year, simyear):
                                            k_bytime = get_k(D_functions, year, simyear, SampleTP, PollABB)
                                            #k_bytime = get_k_segmented(D_params, year, simyear, SampleTP, PollABB)
                                            r = r*k_bytime
                                            try:
                                                D_pollutant_distribution[Site, PollABB, SampleTP, SampleName].append([Distri, ind1, ind2, SampleSize, r])
                                            except KeyError:
                                                D_pollutant_distribution[Site, PollABB, SampleTP, SampleName] = [[Distri, ind1, ind2, SampleSize, r]]
                                            try:
                                                D_summary_pollutants[Site].append( [PollABB, SampleTP, SampleName] )
                                            except KeyError:
                                                D_summary_pollutants[Site] = [[PollABB, SampleTP, SampleName]]
                                            L_sites.add(Site)
                                            L_pollutant.add(PollABB)
                            else:
                                
                                L_SampleTP = line[2].split('/')
                                L_SampleSize = line[5].split('/')
                                L_SampleSize = [int(n) for n in L_SampleSize]
                                #has several ints in a list
                                if len(L_SampleTP)==len(L_SampleSize):
                                    for i in range(len(L_SampleTP)):
                                        SampleTPs = []
                                        if L_SampleTP[i] == 'Fishery Product':
                                            Sample_fishTP = line[3]
                                            fish_region = line[4]
                                            if Sample_fishTP == 'Marine/FreshWater' or Sample_fishTP == 'Marine,FreshWater':
                                                SampleTPs = [tuple(['Marine',fish_region]), tuple(['FreshWater',''])]
                                            else:
                                                SampleTP = tuple([Sample_fishTP,fish_region])
                                        else:
                                            SampleTP =L_SampleTP[i]
                                        if len(SampleTPs)==0:
                                            SampleTPs = [SampleTP]
                                        for Site in L_Site:
                                            for SampleTP in SampleTPs:
                                                if filterout_outtime(PollABB,SampleTP, year, simyear):
                                                    k_bytime = get_k(D_functions, year, simyear, SampleTP, PollABB)
                                                    #k_bytime = get_k_segmented(D_params, year, simyear, SampleTP, PollABB)
                                                    r, ind1, ind2, Distri, SampleSize = check_data(SampleTP, DataTP, Mean, Mid, SD, Min, Max, LOD, LOQ, L_SampleSize[i], D_trans)
                                                    r = r*k_bytime
                                                    #SampleSize = int(SampleSize*30/(np.abs(year-simyear)+1))
                                                    try:
                                                        D_pollutant_distribution[Site, PollABB, SampleTP, SampleName].append([Distri, ind1, ind2, SampleSize, r])
                                                    except KeyError:
                                                        D_pollutant_distribution[Site, PollABB, SampleTP, SampleName] = [[Distri, ind1, ind2, SampleSize, r]]
                                                    try:
                                                        D_summary_pollutants[Site].append( [PollABB, SampleTP, SampleName] )
                                                    except KeyError:
                                                        D_summary_pollutants[Site] = [[PollABB, SampleTP, SampleName]]
                                                    L_sites.add(Site)
                                                    L_pollutant.add(PollABB)
                                else:
                                    #print('lenSampleTP is not lenSampleSize:', len(L_SampleTP), len(L_SampleSize))
                                    for i in range(len(L_SampleTP)):
                                        SampleTPs = []
                                        if L_SampleTP[i] == 'Fishery Product':
                                            Sample_fishTP = line[3]
                                            fish_region = line[4]
                                            if Sample_fishTP == 'Marine/FreshWater' or Sample_fishTP == 'Marine,FreshWater':
                                                SampleTPs = [tuple(['Marine',fish_region]), tuple(['FreshWater',''])]
                                            else:
                                                SampleTP = tuple([Sample_fishTP,fish_region])
                                        else:
                                            SampleTP = L_SampleTP[i]
                                        if len(SampleTPs)==0:
                                            SampleTPs = [SampleTP]
                                        for Site in L_Site:
                                            for SampleTP in SampleTPs:
                                                if filterout_outtime(PollABB,SampleTP, year, simyear):
                                                    k_bytime = get_k(D_functions, year, simyear, SampleTP, PollABB)
                                                    #k_bytime = get_k_segmented(D_params, year, simyear, SampleTP, PollABB)
                                                    r, ind1, ind2, Distri, SampleSize = check_data(L_SampleTP[i], DataTP, Mean, Mid, SD, Min, Max, LOD, LOQ, 1, D_trans)
                                                    r = r*k_bytime
                                                    #SampleSize = int(SampleSize*30/(np.abs(year-simyear)+1))
                                                    try:
                                                        D_pollutant_distribution[Site, PollABB, SampleTP, SampleName].append([Distri, ind1, ind2, SampleSize, r])
                                                    except KeyError:
                                                        D_pollutant_distribution[Site, PollABB, SampleTP, SampleName] = [[Distri, ind1, ind2, SampleSize, r]]
                                                    try:
                                                        D_summary_pollutants[Site].append( [PollABB, SampleTP, SampleName] )
                                                    except KeyError:
                                                        D_summary_pollutants[Site] = [[PollABB, SampleTP, SampleName]]
                                                    L_sites.add(Site)
                                                    L_pollutant.add(PollABB)
                else:
                    pass #print(line[7],line[8])
                        
    return D_pollutant_distribution, D_summary_pollutants, list(L_sites), list(L_pollutant)

def filterout_outtime(poll, SampleTP, year, yearsim):
    D_poll = {'PFOA':[14,14],
              'PFOS':[7,20],
              'PFDA':[0,20],
              'PFDoDA':[1,11],
              'PFUnDA':[0,9],
              'PFHxS':[0,10],
              'PFNA':[0,14]}
    if SampleTP in ['Pork', 'Beef', 'Meat, Other', 'Mutton', 'Egg', 'Poultry']:
        return True
    else:
        if year - yearsim > D_poll[poll][0] or yearsim - year > D_poll[poll][1]:
            return False
        else:
            return True

class PiecewiseFunction:
    def __init__(self, breaks, slopes, intercepts):
        """
        breaks: list of breakpoints [x0, x1, x2, ...]
        slopes: list of slopes for each segment
        intercepts: list of intercepts for each segment
        """
        self.breaks = np.array(breaks)
        self.slopes = np.array(slopes)
        self.intercepts = np.array(intercepts)

    def __call__(self, x):
        """
        Makes the object callable: y = f(x)
        Works for scalars, lists, and numpy arrays.
        """
        x = np.asarray(x)
        y = np.zeros_like(x, dtype=float)

        for i in range(len(self.slopes)):
            left = self.breaks[i]
            right = self.breaks[i+1]

            mask = (x >= left) & (x <= right)
            y[mask] = self.slopes[i] * x[mask] + self.intercepts[i]

        # Return scalar if input was scalar
        return y if y.size > 1 else float(y)

def read_piecewise(file='aquatic_time_trends.xlsx'):
    path = str(INPUT) + '/'
    # setup piecewise functions for all aquatic foods to caliberate
    df = pd.read_excel(path+file)
    D_params = {}
    for i in df['index']:
        if 'Demersal' in df['sample'][i]:
            sample = 'Demersal'
        elif 'Pelagic' in df['sample'][i]:
            sample = 'Pelagic'
        elif 'FreshWater' in df['sample'][i]:
            sample = 'FreshWater'
        elif "Blue" in df['sample'][i]:
            sample = 'Blue Foods'
        else:
            sample = df['sample'][i]
        try:
            D_params[sample, df['chem'][i]] = D_params[sample, df['chem'][i]] + [df['a'][i], df['b'][i]]
        except KeyError:
            D_params[sample, df['chem'][i]] = [df['fix_year'][i], df['a'][i], df['b'][i]]
    D_functions = {}
    for item in D_params:
        str_years = D_params[item][0]
        fix_year = [ float(f) for f in str_years.split('-') ]
        if len(fix_year) == 3:
            str_years, a1, b1, a2, b2 = D_params[item] #, a3, b3, a4, b4
            D_functions[item] = PiecewiseFunction(fix_year, [a1,a2], [b1,b2])
        if len(fix_year) == 4:
            str_years, a1, b1, a2, b2, a3, b3 = D_params[item] #, a3, b3, a4, b4
            D_functions[item] = PiecewiseFunction(fix_year, [a1,a2,a3], [b1,b2,b3])
        if len(fix_year) == 5:
            str_years, a1, b1, a2, b2, a3, b3, a4, b4= D_params[item] #, a3, b3, a4, b4
            D_functions[item] = PiecewiseFunction(fix_year, [a1,a2,a3,a4], [b1,b2,b3,b4])
    return D_functions

def get_k(D_functions, year, simyear, sampleTP, PollABB):
    if sampleTP in ['Pork', 'Beef', 'Meat, Other', 'Mutton', 'Egg', 'Poultry']:
        return 1
    else:
        if "Meat, Aquatic Mammals" == sampleTP:
            sampleTP = 'Blue Foods'
        if type(sampleTP) == tuple:
            if 'Demersal' in sampleTP:
                sampleTP = 'Demersal'
            elif 'Pelagic' in sampleTP:
                sampleTP = 'Pelagic'
            elif 'FreshWater' in sampleTP:
                sampleTP = 'FreshWater'
            else:
                sampleTP = 'Blue Foods'
        if PollABB in ['PFNA', 'PFDoDA']:
            model = D_functions[sampleTP, PollABB]
        else:
            model = D_functions['Blue Foods', PollABB]
        k = 10**(model(simyear)-model(year))
        return k

def read_decay_by_time():
    calib_path = 'I:/simulation for diet HI/time trend analysis/'
    calib_file_aquatic = 'most significant periods 1229.xlsx'
    df = pd.read_excel(calib_path+calib_file_aquatic)
    D_params = {}
    for i in df['ind']:
        if 'Demersal' in df['sample'][i]:
            sample = 'Demersal'
        elif 'Pelagic' in df['sample'][i]:
            sample = 'Pelagic'
        elif 'FreshWater' in df['sample'][i]:
            sample = 'FreshWater'
        else:
            sample = df['sample'][i]
        period = df['period'][i]
        period = period.strip('[')
        period = period.strip(']')
        Period = [int(i) for i in period.split(', ')]
        D_params[df['chem'][i],sample]=[df['a'][i], df['b'][i], df['p'][i], Period]
    
    return D_params

def get_k_segmented(D_params, year, simyear, sampleTP, PollABB):
    def correct_year(yr, period):
        if yr < period[0]:
            return period[0]
        elif yr>period[1]:
            return period[1]
        else:
            return yr
    if type(sampleTP) == tuple:
        if 'Demersal' in sampleTP:
            sampleTP = 'Demersal'
        elif 'Pelagic' in sampleTP:
            sampleTP = 'Pelagic'
        elif 'FreshWater' in sampleTP:
            sampleTP = 'FreshWater'
        else:
            sampleTP = 'Blue Foods'
    if sampleTP in ['Meat, Other']:
        sampleTP = 'Terri Foods'
    if sampleTP in ['Pork', 'Beef', 'Meat, Other', 'Mutton', 'Egg', 'Poultry', 'Terri Foods'] or year == 0:
        return 1
    else:
        try:
            a, b, p, period = D_params[PollABB, sampleTP]
            if p < 1 :
                simyear = correct_year(simyear, period)
                year = correct_year(year, period)
                k = 10**(a*(simyear - year))
                return k
            else:
                return 1
        except KeyError:
            return 1
        
def get_years(L_years):
    if '/' in L_years:
        Ys = L_years.split('/')
    elif L_years == '':
        return [0]
    else:
        Ys = [L_years]
    Y_ = []
    for Y in Ys:
        try:
            Y_ = Y_ + [y for y in range(int(Y.split('-')[0]), int(Y.split('-')[1]), 1)]
        except:
            Y_ = Y_ + [int(y) for y in Y.split('-')]
    return Y_

def read_datatrans(path, filename):
    '''
    read the file for lipid/dry weight/water weight in different type of food
    '''
    D_trans = dict()
    with open(path + filename, mode='r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        head = True
        for line in data:
            if head:
                head = False
            else:
                D_trans[line[0], 'aq'] = float(line[1])
                D_trans[line[0], 'lip'] = float(line[2])
    return D_trans

def check_data(SampleTP, DataTP, Mean, Mid, SD, Min, Max, LOD, LOQ, n, D_trans):
    #print(Mean, SD)
    '''_______________________ transform dw/fw/ww _________________________'''
    if DataTP == 'ww':
        r = 1
    elif DataTP == 'dw':
        r = 1 - D_trans[SampleTP, 'aq']
    elif DataTP == 'fw' or DataTP == 'lw':
        r = D_trans[SampleTP, 'lip']
    else:
        print('Data Type Error: need dw/fw/ww')
        r=0
    
    '''_______________________ check LOD/LOQ ______________________________'''
    IsLOD = False
    try:
        LOD = float(LOD)
        IsLOD = True
    except:
        pass
    IsLOQ = False
    try:
        LOQ = float(LOQ)
        IsLOQ = True
    except:
        pass
    if IsLOD and IsLOQ:
        pass
    elif IsLOD:
        LOQ = LOD/3*10
        IsLOQ = True
    elif IsLOQ:
        LOD = LOQ/10*3
        IsLOD = True
    else:
        pass
        #print('No LOD, LOQ')
    '''_______________________ check Min/Max ______________________________'''
    IsMinMax = False
    try:
        Max = float(Max)
        IsMinMax = True
    except:
        if '<' in Max:
            Max = LOQ
            Min = LOD
            IsMinMax = True
        elif 'nd' in Max or 'ND' in Max:
            Max = LOD
            Min = LOD/3
            IsMinMax = True
        else:
            pass
    try:
        Min = float(Min)
        IsMinMax = True
    except:
        if '<' in Min:
            Min = LOD
            IsMinMax = True
        elif 'nd' in Min or 'ND' in Min:
            Min = LOD/2+LOD/6
            IsMinMax = True
        else:
            pass
    
    '''_______________________ check Mean/SD ______________________________'''
    IsMean = False
    SoloMean = False
    try:
        Mean = float(Mean)
        IsMean = True
    except:
        if '<' in Mean:
            if IsLOD or IsLOQ:
                Min = LOD
                Max = LOQ
                IsMinMax = True
            else:
                print('No LOD/LOQ for Mean subsititution')
        elif 'nd' in Mean or 'ND' in Mean:
            if IsLOD or IsLOQ:
                Mean = LOD/2
                SD = LOD/3
                IsMean = True
        else:
            pass
            #print(Mean,': Mean value error')
    IsSD = False
    try:
        SD = float(SD)
        IsSD = True
    except:
        if IsMean:
            if IsLOD:
                SD = LOD/3
            else:
                SoloMean = True
        else:
            if IsLOD:
                pass
            elif IsMinMax:
                pass
            else:
                try:
                    Mid = float(Mid)
                except:
                    print('Value for conc. missed')
    
    '''_______________________ check Mid vs Mean ______________________________'''
    IsMid = False
    try:
        Mid = float(Mid)
        IsMid = True
    except:
        if '<' in Mid:
            Mid = (LOQ-LOD)/2 + LOD
            IsMid = True
        elif Mid == 'nd' or Mid == 'ND':
            Mid = LOD/3
            IsMid = True
        else:
            pass
        
    if IsMid and IsMean and IsSD:
        if Mid < Mean:
            sigma_a_square = 2*(np.log(Mean) - np.log(Mid))
            sigma_b_square = np.log( 1/2 + np.sqrt(SD**2/Mean**2 + 1/4) )
            if sigma_a_square > sigma_b_square:
                kai_a2b = sigma_a_square/sigma_b_square*(n-1)
            else:
                kai_a2b = sigma_b_square/sigma_a_square*(n-1)
            p095 = stat.chi2.ppf(0.95, n)
            if p095 < kai_a2b:
                Distri = 'LogNormal'
                ind1 = np.log(Mid)
                ind2 = np.exp((np.log(sigma_a_square)+np.log(sigma_b_square))/4)
            else:
                Distri = 'Normal'
                ind1 = Mean
                ind2 = SD
        else:
            Distri = 'Normal'
            ind1 = Mean
            ind2 = SD        
    elif IsMean and IsSD:
        Distri = 'Normal'
        ind1 = Mean
        ind2 = SD
    elif IsMid and IsSD:
        Distri = 'Normal'
        ind1 = Mid
        ind2 = SD
    elif SoloMean:
        Distri = 'Mono'
        ind1 = Mean
        ind2 = np.nan
    elif IsMid or IsMean and not IsSD:
        Distri = 'Mono'
        if IsMid:
            ind1 = Mid
        elif IsMean:
            ind1 = Mean
        ind2 = np.nan
    elif IsMinMax:
        Distri = 'Uniform'
        ind1 = Min
        ind2 = Max
    else:
        print( 'UnknonwDistributionError' )
    '''_________________________reweight by LOD/LOQ________________________________'''
    if IsLOD or IsLOQ:
        ndweight = math.ceil(3*(0.02/LOD))
    elif Distri == 'Uniform':
        ndweight = 3
    else:
        ndweight = 1
    return r, ind1, ind2, Distri, ndweight*n

def read_territorial_region(path, filename='SampleSite-Terri.csv'):
    # read country as sites, get their correlated regions (Continent in this case)
    D_TerranSite = dict()
    with open(path+filename, mode='r', encoding='utf-8-sig') as file:
        data = csv.reader(file)
        head = True
        for line in data:
            if head:
                head = False
            else:
                D_TerranSite[line[0]] = set([line[1]])
    return D_TerranSite
    
def read_aquatic_region(path, filename = 'SampleSite-Waters.csv'):
    # read the country/ waters names, get their correlated nature zones
    D_WatersSite = dict()
    with open(path+filename, mode='r', encoding='utf-8-sig') as file:
        data = csv.reader(file)
        for line in data:
            if line[0] != '':
                try:
                    D_WatersSite[line[0]].add(line[1])
                except KeyError:
                    D_WatersSite[line[0]] = set([line[1]])
        file.close()
    D_RiverLakeSea = dict()
    with open(path+filename, mode='r', encoding='utf-8-sig') as file:
        data = csv.reader(file)
        for line in data:
            if line[2] != '':
                if '/' in line[2]:
                    for country in line[2].split('/'):
                        try:
                            D_RiverLakeSea[line[1]].add(country)
                        except KeyError:
                            D_RiverLakeSea[line[1]] = set([country])
                else:
                    try:
                        D_RiverLakeSea[line[1]].add(line[2])
                    except KeyError:
                        D_RiverLakeSea[line[1]] = set([line[2]])
    return D_WatersSite, D_RiverLakeSea


def read_trade_matrix(path, filename):
    df_T = pd.read_excel(path+filename, sheet_name='Terri', index_col=0)
    df_W = pd.read_excel(path+filename, sheet_name='Water', index_col=0)
    
    return df_T, df_W, df_W.columns

'''_____________________________________________________________________some dict tools________________________________________________________________'''
def separate(D_pollutant_distribution, MajorCatPoll):
    D_EachPoll = dict()
    D_SumPoll = dict()
    SumHead = 'Sum_' + MajorCatPoll + 's'
    for Site, PollABB, SampleTP, SampleName in D_pollutant_distribution:
        if 'Sum_' not in PollABB:
            D_EachPoll[Site, PollABB, SampleTP, SampleName] = D_pollutant_distribution[Site, PollABB, SampleTP, SampleName]
        elif SumHead in PollABB:
            D_SumPoll[Site, PollABB, SampleTP, SampleName] = D_pollutant_distribution[Site, PollABB, SampleTP, SampleName]
    return D_SumPoll, D_EachPoll

'''_______________________________________1.2 read the fishery distribution file for FW, PS, SS_______________________________________________________'''
def read_worldmap(path, filename):
    '''
    file: Country Code FAO	|Region Code	|Continent	|International Innerland waters |Ocean Name |Ocean Code
    Returns
    D_FAOcountry(dictionary): {FAOcountry: continent, InnerLandWater, Ocean }
    D_PollRegion(dictionary): {Ocean: L_PollRegion},{continent: L_PollRegion},{InnerLandWater: L_PollRegion}
    D_label(dictionary)
    '''
    D_FAOcountry = dict()
    D_PollRegion = dict()
    D_Label = dict()
    with open(path+filename, mode='r', encoding='utf-8-sig') as file:
        data = csv.reader(file)
        head = True
        for line in data:
            if head:
                head = False
            else:
                FAOcountry = line[0]
                PollRegion = line[1]
                Continent = line[2]
                L_Waters = line[3].split(',')
                L_Oceans = line[4].split(',')
                
                if FAOcountry != '':
                    try:
                        D_FAOcountry[FAOcountry]['Continent'].add(Continent)
                        for water in L_Waters:
                            D_FAOcountry[FAOcountry]['InnerLandWater'].add(water)
                        for ocean in L_Oceans:
                            D_FAOcountry[FAOcountry]['Ocean'].add(ocean)
                    except KeyError:
                        D_FAOcountry[FAOcountry] = dict()
                        D_FAOcountry[FAOcountry]['Continent'] = set()
                        D_FAOcountry[FAOcountry]['InnerLandWater'] = set()
                        D_FAOcountry[FAOcountry]['Ocean'] = set()
                        if Continent != '':
                            D_FAOcountry[FAOcountry]['Continent'].add(Continent)
                        for water in L_Waters:
                            if water != '':
                                D_FAOcountry[FAOcountry]['InnerLandWater'].add(water)
                        for ocean in L_Oceans:
                            if ocean != '':
                                D_FAOcountry[FAOcountry]['Ocean'].add(ocean)
               
    return D_FAOcountry, D_PollRegion, D_Label

'''______________________________________________________________form a pool of sample conc._____________________________________________________________'''
def get_poll_pool(D_poll_distri, D_region, TorW, N_conc=1000):
    '''
        D_poll_distri = { Site, PollABB, SampleTP, SampleName : [[Distri_type, ind1, ind2, SampleSize, r] ... ]  }
        D_region = {  Site : [region] } #region could be continent(for terran)/water(for aquatics)
    return:
        D_pool= { region, PollABB, SampleTP : [N_sims concs]}
    '''
    D_pool_distri = dict()
    D_pool_totalN = dict()
    for Site, PollABB, SampleTP, SampleName in D_poll_distri:
        Pass = False
        if TorW == 'T':
            if SampleTP in ['Pork', 'Beef', 'Meat, Other', 'Mutton', 'Egg', 'Poultry']:
                Pass = True
        else:
            if SampleTP not in ['Pork', 'Beef', 'Meat, Other', 'Mutton', 'Egg', 'Poultry']:
                Pass = True
        if Pass:
            for region in D_region[Site]:
                for analysis_result in D_poll_distri[Site, PollABB, SampleTP, SampleName]:
                    try:
                        D_pool_distri[ region, PollABB, SampleTP ].append(analysis_result)
                        D_pool_totalN[ region, PollABB, SampleTP ] = D_pool_totalN[ region, PollABB, SampleTP ] + analysis_result[-2]
                    except KeyError:
                        D_pool_distri[ region, PollABB, SampleTP ] = [analysis_result]
                        D_pool_totalN[ region, PollABB, SampleTP ] = analysis_result[-2]
    # from a dirstribution pool, get a sampling pool
    D_pool = dict()
    for Sample in D_pool_distri:
        D_pool[Sample] = []
        for analysis_result in D_pool_distri[Sample]:
            Distri, ind1, ind2, N, r = analysis_result
            N_sims_analysis = int(N_conc*N/D_pool_totalN[Sample])
            L = random_choice(Distri, ind1, ind2, N_sims_analysis)
            D_pool[Sample] = D_pool[Sample] + [r*conc for conc in L]
    # check pool
    
    return D_pool
    
def random_choice(Distri, ind1, ind2, n):
    if Distri == 'Uniform':
        L = []
        for i in range(n):
            a = 0
            while a <= 0:
                a = random.uniform(ind1, ind2)
            L.append(a)
        return L
    elif Distri == 'Mono':
        L = []
        for i in range(n):
            L.append(ind1)
        return L
    elif Distri == 'Normal':
        L = []
        for i in range(n):
            a = 0
            while a <= 0:
                a = random.normalvariate(ind1, ind2)
            L.append(a)
        return L
    elif Distri == 'LogNormal':
        L = []
        for i in range(n):
            L.append(random.lognormvariate(ind1, ind2))
        return L
'''________________________________________get simulated country sites_____________________________________________________________'''
def read_countrycode(path, filename ='Map_Country_Code.csv'):
    D_Sample2FAO = dict()
    D_FAO2map = dict()
    with open(path+filename, mode='r', encoding='utf-8-sig') as file:
        data = csv.reader(file)
        head = True
        for line in data:
            if head:
                head = False
            else:
                if line[2] != '':
                    D_Sample2FAO[line[2]] = line[0]
                    D_FAO2map[line[0]] = line[1]
    return D_Sample2FAO, D_FAO2map

'''_______________________________________3.1 for each country, simulate the diet_______________________________________________________'''
def read_FAO_diet(path, filename):
    D_eatlive_ratio = {'Bovine Meat':0.4, "Mutton & Goat Meat":0.37, 'Pigmeat':0.52, 'Poultry Meat':0.51, 'Eggs':0.89, 'Meat, Other':0.85,
                       'Crustaceans':0.4, 'Molluscs, Other':0.15, 'Freshwater Fish':0.56, 'Demersal Fish':0.56, 'Pelagic Fish':0.56,
                       'Marine Fish, Other':0.56, 'Aquatic Animals, Others':0.56,}
    D_FAO_diet = dict()
    with open(path+filename, mode='r', encoding='utf-8-sig') as file:
        data = csv.reader(file)
        head = True
        for line in data:
            if head:
                head = False
            else:
                FAOCountry = line[0]
                FoodTP = line[1]
                try:
                    r = D_eatlive_ratio[FoodTP]
                    FoodAmount = float(line[2])*1000/365 #data in kg/year/capita, transform into g/day/capita
                    try:
                        D_FAO_diet[FAOCountry][FoodTP] = FoodAmount*r+1e-4
                    except KeyError:
                        D_FAO_diet[FAOCountry] = dict()
                        D_FAO_diet[FAOCountry][FoodTP] = FoodAmount*r+1e-4
                except KeyError:
                    pass
    return D_FAO_diet

def get_dishes(D_FAO_diet, FAOCountry,  N_sims=1000, all_blue = False):
    '''
    for a given country, get the amount of food of different food types for N_simulators'
    return
        D_dish(dictionary) = { FoodTP: array([ food amount ])}
    '''
    D_FoodTP_label = {'Bovine Meat':'Green','Mutton & Goat Meat':'Green','Pigmeat':'Green','Poultry Meat':'Green','Meat, Other':'Green','Eggs':'Green',
                      'Freshwater Fish':'Blue', 'Demersal Fish':'Blue', 'Pelagic Fish':'Blue', 'Aquatic Animals, Others':'Blue', 'Marine Fish, Other':'Blue', 'Meat, Aquatic Mammals':'Blue'}
    
    D_dish = dict()
    if not all_blue:
        for FoodTP in D_FAO_diet[FAOCountry]:
            FoodAmount = D_FAO_diet[FAOCountry][FoodTP]
            if FoodAmount > 0:
                u = FoodAmount//100*3*4*12+1
                arr = np.random.poisson(u,N_sims)
                #arr = np.ones(N_sims)*u
                arr = arr*FoodAmount/u
                D_dish[FoodTP] = arr
        #df = pd.DataFrame(D_dish)
        #df.to_excel('H:/projects/BLUE FOOD/simulation for diet HI/input_file/test/food from US.xlsx')
        return D_dish
    else:
        L_Blue = []
        L_Green = []
        L_Bluename = []
        L_Greenname = []
        for FoodTP in D_FAO_diet[FAOCountry]:
            if D_FoodTP_label[FoodTP] == 'Green':
                L_Green.append(D_FAO_diet[FAOCountry][FoodTP])
                L_Greenname.append(FoodTP)
            elif D_FoodTP_label[FoodTP] == 'Blue':
                L_Blue.append(D_FAO_diet[FAOCountry][FoodTP])
                L_Bluename.append(FoodTP)
        L_Blue = np.array(L_Blue)
        L_Green = np.array(L_Green)
        L_allBlue = L_Blue*(np.sum(L_Green)/np.sum(L_Blue) + 1)
        
        print(np.sum(L_allBlue), np.sum(L_Blue), np.sum(L_Green))
        for i in range(len(L_Bluename)):
            FoodAmount = L_allBlue[i]
            if FoodAmount > 0:
                u = FoodAmount//100*3*4*12+1
                arr = np.random.poisson(u,N_sims)
                arr = arr*FoodAmount/u
                D_dish[L_Bluename[i]] = arr
        for i in range(len(L_Greenname)):
            D_dish[L_Greenname[i]] = np.zeros(N_sims)
        
        return D_dish

def ConvProduct(L1,L2):
    L = []
    for x in L1:
        for y in L2:
            L.append(x*y)
    return np.array(L)

def SimuConsum(D_conclist, FAOcountry, L_Region, WorT ,N_conc = 1000):
    '''
    use convlution product to get the exposre profile of a country
        L_region is D_FAOcountry[FAOcountry], list of regions
        D_conclist = {Region, pollname, SampleTP: [ list of conc sims: N_sims many ]}
        D_dish(dictionary) = { FoodTP: array([ food amount: N_sims ])}
    return
        D_exposure(dictionary)= {FAOcountry: {pollname^CAS: conc} }
    L_foodTP = ['Bovine Meat','Eggs','Pigmeat','Poultry Meat','Mutton & Goat Meat','Meat, Other',
                'Aquatic Animals, Others','Demersal Fish','Pelagic Fish','Marine Fish, Other','Freshwater Fish']
    '''
    
    D_translation = {'Mollusc':'Molluscs, Other',
                     'Crustacean':'Crustaceans',
                     'Beef':'Bovine Meat',
                     'Egg':'Eggs',
                     'Pork':'Pigmeat',
                     'Poultry':'Poultry Meat',
                     'Mutton':'Mutton & Goat Meat',
                     'Meat, Other':'Meat, Other',
                     'Meat, Aquatic Mammals':'Meat, Aquatic Mammals'}
    D_exposure = dict()
    D_exposure[FAOcountry] = dict()
    D_subconc = dict()
    #print(L_Region)
    for item in D_conclist:
        Region, pollname, SampleTP = item
        if Region in L_Region:
            #a. match the FoodTP
            if type(SampleTP) == tuple:
                # changed Region to FAOcountry
                if 'Cooked' in SampleTP:
                    # Cooked
                    FoodTP = 'Marine Fish, Other'
                    try:
                        D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                    except KeyError:
                        D_subconc[FAOcountry,pollname,FoodTP ] = list(D_conclist[item])
                
                elif 'Marine' in SampleTP:
                    if 'Demersal' in SampleTP:
                        FoodTP = 'Demersal Fish'
                        try:
                            D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                        except KeyError:
                            D_subconc[FAOcountry,pollname,FoodTP ] = list(D_conclist[item])
                    elif 'Pelagic' in SampleTP:
                        FoodTP = 'Pelagic Fish'
                        try:
                            D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                        except KeyError:
                            D_subconc[FAOcountry,pollname,FoodTP ] = list(D_conclist[item])
                    elif 'Mix' in SampleTP:
                        FoodTP = 'Demersal Fish'
                        try:
                            D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                        except KeyError:
                            D_subconc[FAOcountry,pollname,FoodTP ] = list(D_conclist[item])
                        FoodTP = 'Pelagic Fish'
                        try:
                            D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                        except KeyError:
                            D_subconc[FAOcountry,pollname,FoodTP ] = list(D_conclist[item])
                elif 'Marine,FreshWater' in SampleTP or 'Marine/FreshWater' in SampleTP:
                    FoodTP = 'Freshwater Fish'
                    try:
                        D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                    except KeyError:
                        D_subconc[FAOcountry,pollname,FoodTP ] = list(D_conclist[item])
                    if 'Demersal' in SampleTP:
                        FoodTP = 'Demersal Fish'
                        try:
                            D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                        except KeyError:
                            D_subconc[FAOcountry,pollname,FoodTP ] = list(D_conclist[item])
                    elif 'Pelagic' in SampleTP:
                        FoodTP = 'Pelagic Fish'
                        try:
                            D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                        except KeyError:
                            D_subconc[FAOcountry,pollname,FoodTP ] = list(D_conclist[item])
                    elif 'Mix' in SampleTP:
                        FoodTP = 'Demersal Fish'
                        try:
                            D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                        except KeyError:
                            D_subconc[Region,pollname,FoodTP ] = list(D_conclist[item])
                        FoodTP = 'Pelagic Fish'
                        try:
                            D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                        except KeyError:
                            D_subconc[FAOcountry,pollname,FoodTP ] = list(D_conclist[item])
                elif 'FreshWater' in SampleTP:
                    FoodTP = 'Freshwater Fish'
                    try:
                        D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                    except KeyError:
                        D_subconc[FAOcountry,pollname,FoodTP ] = list(D_conclist[item])
                else:
                    print(SampleTP)
                
            else:
                try:
                    FoodTP = D_translation[SampleTP]
                except KeyError:
                    print(SampleTP)
                try:
                    D_subconc[FAOcountry,pollname,FoodTP ] = D_subconc[FAOcountry,pollname,FoodTP ] + list(D_conclist[item])
                except KeyError:
                    D_subconc[FAOcountry,pollname,FoodTP ] = list(D_conclist[item])
    #b. check avalibility of FoodTPs, add in the not avalible ones
    D_FoodTP_check = dict()
    
    for faocountry, poll, FoodTP in D_subconc:
        try:
            #D_FoodTP_check[region,poll].append(FoodTP)
            D_FoodTP_check[faocountry,poll].append(FoodTP)
        except KeyError:
            #D_FoodTP_check[region,poll] = [FoodTP]
            D_FoodTP_check[faocountry,poll] = [FoodTP]
    
    def fill_in_spares(D_FoodTP_check, faocountry, poll,D_subconc, L1):
        L_samples = [x for x in L1 if x in D_FoodTP_check[faocountry, poll]]
        L_candidates = [x for x in L1 if x not in D_FoodTP_check[faocountry, poll]]
        if len(L_samples) > 0:
            L_mix = []
            for sample in L_samples:
                L_mix = L_mix + D_subconc[faocountry, poll, sample] 
            for candidate in L_candidates:
                D_subconc[faocountry, poll, candidate] = L_mix
            D_FoodTP_check[faocountry, poll] = D_FoodTP_check[faocountry, poll] + L_candidates
            return D_FoodTP_check,D_subconc, True
        else:
            return D_FoodTP_check,D_subconc, False
        
    for faocountry, poll in D_FoodTP_check:
        if WorT == 'T':
            L = ['Bovine Meat','Pigmeat','Mutton & Goat Meat','Meat, Other', 'Poultry Meat', 'Eggs']
            L0 = []
            for food in D_FoodTP_check[faocountry,poll]:
                if food in L:
                    L.pop(L.index(food))
                    L0.append(food)
            L_mix = []
            if len(L0) > 0:
                for FoodTP in L0:
                    L_mix = L_mix + D_subconc[faocountry, poll, FoodTP]
                for FoodSubed in L:
                    D_subconc[faocountry, poll, FoodSubed] = L_mix
                D_FoodTP_check[faocountry, poll] = D_FoodTP_check[faocountry, poll] + L
            else:
                pass
        elif WorT == 'W':
            L1 = ['Demersal Fish','Pelagic Fish','Marine Fish, Other']
            D_FoodTP_check, D_subconc, MarineFishadded = fill_in_spares(D_FoodTP_check, faocountry, poll,D_subconc, L1)
            if not MarineFishadded:
                pass
                #print(f'{faocountry}^{poll} has_no marine_fish')
            
            L2 = ['Aquatic Animals, Others','Crustaceans','Molluscs, Other']
            D_FoodTP_check, D_subconc, MarineAnimalsadded = fill_in_spares(D_FoodTP_check, faocountry, poll,D_subconc, L2)
            if not MarineAnimalsadded:
                pass
                #print(f'{faocountry}^{poll} has_no marine_animals')
                
            if MarineFishadded or MarineAnimalsadded:
                D_FoodTP_check, D_subconc, Marinesadded = fill_in_spares(D_FoodTP_check, faocountry, poll,D_subconc, L1+L2)
            if not MarineFishadded and not MarineAnimalsadded:
                Marinesadded = False
            
            if 'Freshwater Fish' in D_FoodTP_check[faocountry, poll]:
                FreshwaterFishadded = True
            else:
                FreshwaterFishadded = False
                #print(f'{faocountry}^{poll} has_no freshwater_fish')
            
            if Marinesadded or FreshwaterFishadded:
                L3 = L1 + L2 + ['Freshwater Fish', 'Meat, Aquatic Mammals']
                D_FoodTP_check, D_subconc, MarineAlladded = fill_in_spares(D_FoodTP_check, faocountry, poll,D_subconc, L3)
                if not MarineAlladded:
                    pass
                    #print(f'{faocountry}^{poll} has_no aquatic food')
                
    '''
    D_poll_allhavedata = dict()
    for region, poll in D_FoodTP_check:
        try:
            D_poll_allhavedata[poll] = D_poll_allhavedata[poll] + D_FoodTP_check[region, poll]
        except KeyError:
            D_poll_allhavedata[poll] = D_FoodTP_check[region, poll]
    for poll in D_poll_allhavedata:
        if 'Bovine Meat' not in D_poll_allhavedata[poll]:
            for region in L_Region:
                try:
                    del(D_FoodTP_check[region, poll])
                except KeyError:
                    pass
    del(D_poll_allhavedata)
    '''
    #c. record N_conc many info randomly
    D_conc = dict()
    for faocountry, poll in D_FoodTP_check:
        for foodTP in D_FoodTP_check[faocountry, poll]:
            D_conc[faocountry, poll, foodTP] = random.choices( D_subconc[faocountry, poll, foodTP] , k = N_conc )
    del(D_subconc)
    
    #d. get Conc by country & consider if there is international trade
    D_conc_specific = D_exposure.copy()
    for region, poll in D_FoodTP_check:
        for foodTP in D_FoodTP_check[region, poll]:
            try:
                concs_region = np.array(D_conc[region, poll, foodTP])
                D_conc_specific[FAOcountry][foodTP, poll] = np.concatenate( [D_conc_specific[FAOcountry][foodTP, poll], concs_region], axis=0)
            except KeyError:
                try:
                    D_conc_specific[FAOcountry][foodTP, poll] = D_conc[region, poll, foodTP]
                except KeyError:
                    pass
                    #print(FAOcountry, 'has no such food pollinfo', region, poll, foodTP)
    for food_poll in D_conc_specific[FAOcountry]:
        concs = np.sort(D_conc_specific[FAOcountry][food_poll])
        Mix = 7
        c0 = concs.copy()
        for i in range(Mix-1):
            c1 = concs.copy()
            np.random.shuffle(c1)
            c0 = c0 + c1
        D_conc_specific[FAOcountry][food_poll] = random.choices(c0/Mix, k = N_conc )
    
    del(D_FoodTP_check)
    del(D_conc)
    return D_conc_specific

def tradeing(target_country, D_conc_specific, D_FAO_diet, D_trade = None, N_sims=1000, all_blue = False):
    L_FAOcountry = [c for c in D_FAO_diet if c in D_conc_specific]
    D_exposure = dict()
    for FAOcountry in [target_country]:
        D_exposure[FAOcountry] = {}
        D_dish = get_dishes(D_FAO_diet, FAOcountry, N_sims=N_sims, all_blue = all_blue)
        
        diet = np.zeros(N_sims)
        for i in D_dish:
            diet = diet + D_dish[i]
        #print(FAOcountry, np.average(diet), np.std(diet))
        
        s_poll = set( [poll for foodtp, poll in D_conc_specific[FAOcountry] ] )
        for foodTP in D_FAO_diet[FAOcountry]:
            #print(foodTP)
            if D_trade is None:
                df_trade = pd.DataFrame(np.identity(len(L_FAOcountry)))
                df_trade.columns = L_FAOcountry
                df_trade.index = L_FAOcountry
            else:
                df_trade = D_trade
            food1d = D_dish[foodTP] # N_sims length
            weight = df_trade.loc[L_FAOcountry, FAOcountry]
            # check avalible country
            for poll in s_poll:
                L_ava = []
                for c in L_FAOcountry:
                    try:
                        D_conc_specific[c][foodTP, poll]
                        L_ava.append(1)
                    except KeyError:
                        L_ava.append(0)
                re_weight = weight*np.array(L_ava)
                #print(poll, np.average(food1d), np.std(food1d))
                #print(np.sum(re_weight))
                if np.sum(re_weight) == 0:
                    continue
                else:
                    re_weight = re_weight/np.sum(re_weight)
                    food2d = np.array([i*re_weight for i in food1d])
                    for i in range(len(L_FAOcountry)):
                        c = L_FAOcountry[i]
                        try:
                            arr_conc = D_conc_specific[c][foodTP, poll]
                            food = food2d[:,i]
                            np.random.shuffle(food)
                            try:
                                D_exposure[FAOcountry][poll] = D_exposure[FAOcountry][poll] + ConvProduct(food,arr_conc)
                            except KeyError:
                                D_exposure[FAOcountry][poll] = ConvProduct(food,arr_conc)
                        except:
                            pass
        #print(FAOcountry, 'exposed')
                #print(poll, np.average(np.sum(food2d, axis=1)), np.std(np.sum(food2d, axis=1)))
    
    #arr_pfos = np.sort(D_exposure['United States']['PFOS'])
    #plt.hist(np.log10(arr_pfos))
    #plt.show()
    #print( arr_pfos[int(len(arr_pfos)/2)], np.std(arr_pfos))
    return D_exposure

def SumWandT_expo(D_exposure_T, D_exposure_W):
    D_exposure = {}
    for FAOcountry in D_exposure_W:
        D_exposure[FAOcountry] = {}
        for poll in D_exposure_W[FAOcountry]:
            try:
                Arr = D_exposure_W[FAOcountry][poll] + D_exposure_T[FAOcountry][poll]
                D_exposure[FAOcountry][poll] = Arr
            except KeyError:
                pass
    return D_exposure

'''___________________________________________________________________________________________________________________________________________________'''
def get_L_country(D_Water2Country):
    L_country = set()
    for Water in D_Water2Country:
        for country in D_Water2Country[Water]:
            L_country.add(country)
    return list(L_country)
    
def get_country2region(D_Water2Country, D_TerranSite):
    # for each country (in sample notation), get their correlated region
    L_country = get_L_country(D_Water2Country)
    D_C2Water_region = dict()
    D_C2Tarren_region = dict()
    for country in L_country:
        try:
            D_C2Water_region[country] = set([country])
            for region in D_Water2Country:
                if country in D_Water2Country[region]:
                    D_C2Water_region[country].add(region)
            D_C2Tarren_region[country] = D_TerranSite[country]
        except KeyError:
            pass
            #print(country, 'not in list')
    #print(D_C2Water_region['Slovenia'])
    return D_C2Water_region, D_C2Tarren_region, L_country

'''___________________________________________________________summary the D_exposure for each chemical___________________________________________________________'''
def summary(D_exposure, L_Chem4Sum):
    ava_count = 0
    total_count = 0
    for country in D_exposure:
        total_count = total_count +1
        IN = True
        for y in L_Chem4Sum:
            if y not in [x for x in D_exposure[country]]:
                IN = False
        if not IN:
            print(country,':',[x for x in D_exposure[country]])
        else:
            ava_count = ava_count + 1
    print(ava_count,'/',total_count)
    return

def MetricRefD_QR(D_Ref, D_exposure, label = None):
    D_risk = dict()
    for FAOCountry in D_exposure:
        for poll in D_exposure[FAOCountry]:
            if label == None:
                try:
                    ref = D_Ref[poll]
                    arr_expo_risk = D_exposure[FAOCountry][poll]/60
                    mean = arr_expo_risk[int(len(arr_expo_risk)/2)]
                    #mean = stats.mean(arr_expo_risk)
                    D_risk[FAOCountry, poll] = np.log10(mean/ref)
                except KeyError:
                    pass
            elif label != 'CSF':
                try:
                    ref = D_Ref[poll,label]
                    arr_expo_risk = D_exposure[FAOCountry][poll]/60
                    mean = arr_expo_risk[int(len(arr_expo_risk)/2)]
                    #mean = stats.mean(arr_expo_risk)
                    D_risk[FAOCountry, poll] = np.log10(mean/ref)
                except KeyError:
                    pass
            else:
                try:
                    ref = D_Ref[poll,label]
                    arr_expo_risk = D_exposure[FAOCountry][poll]/60
                    mean = arr_expo_risk[int(len(arr_expo_risk)/2)]
                    #mean = stats.mean(arr_expo_risk)
                    D_risk[FAOCountry, poll] = np.log10(mean*ref)
                except KeyError:
                    pass
    return D_risk

def MetricRef_SumQR(D_Ref, D_exposure, L_poll = [], label = None):
    D_risk = dict()
    D_sumQR = dict()
    for FAOCountry in D_exposure:
        for poll in D_exposure[FAOCountry]:
            D_exposure[FAOCountry][poll] = np.sort(D_exposure[FAOCountry][poll])
            if poll in L_poll:
                if label == None:
                    try:
                        ref = D_Ref[poll]
                        arr_expo_risk = D_exposure[FAOCountry][poll]/65
                        mean = arr_expo_risk[int(len(arr_expo_risk)/2)]
                        #mean = stats.mean(arr_expo_risk)
                        D_risk[FAOCountry, poll] = mean/ref
                    except KeyError:
                        pass
                elif label != 'CSF':
                    try:
                        ref = D_Ref[poll,label]
                        arr_expo_risk = D_exposure[FAOCountry][poll]/65
                        mean = arr_expo_risk[int(len(arr_expo_risk)/2)]
                        #mean = stats.mean(arr_expo_risk)
                        D_risk[FAOCountry, poll] = mean/ref
                    except KeyError:
                        pass
                else:
                    try:
                        ref = D_Ref[poll,label]
                        arr_expo_risk = D_exposure[FAOCountry][poll]/65
                        mean = arr_expo_risk[int(len(arr_expo_risk)/2)]
                        #mean = stats.mean(arr_expo_risk)
                        D_risk[FAOCountry, poll] = mean*ref
                    except KeyError:
                        pass
                try:
                    if label != 'CSF':
                        D_sumQR[FAOCountry] = D_sumQR[FAOCountry] + D_risk[FAOCountry, poll]
                    else:
                        D_sumQR[FAOCountry] = D_sumQR[FAOCountry] + D_risk[FAOCountry, poll]
                except KeyError:
                    if label != 'CSF':
                        D_sumQR[FAOCountry] =  D_risk[FAOCountry, poll]
                    else:
                        D_sumQR[FAOCountry] = D_risk[FAOCountry, poll]
 
    return D_sumQR
'''__________________________________________________________measure by probability_____________________________________________________________________________'''
def MetricRef_SumProb(D_Ref, D_exposure, L_poll = [],  label = None):
    if label == 'CSF':
        print('not a sutibale analysis')
        return
    D_risk = dict()
    D_sumProb = dict()
    for FAOCountry in D_exposure:
        for poll in D_exposure[FAOCountry]:
            if poll in L_poll:
                if label == None:
                    try:
                        ref = D_Ref[poll]
                        arr_expo_risk = D_exposure[FAOCountry][poll]/60
                        arr_expo_risk = np.sort(arr_expo_risk)
                        P_th = get_threathold(arr_expo_risk, ref)/len(arr_expo_risk)
                        #mean = stats.mean(arr_expo_risk)
                        D_risk[FAOCountry, poll] = P_th
                    except KeyError:
                        pass
                elif label != 'CSF':
                    try:
                        ref = D_Ref[poll,label]
                        arr_expo_risk = D_exposure[FAOCountry][poll]/60
                        arr_expo_risk = np.sort(arr_expo_risk)
                        P_th = get_threathold(arr_expo_risk, ref)/len(arr_expo_risk)
                        #mean = stats.mean(arr_expo_risk)
                        D_risk[FAOCountry, poll] = P_th
                    except KeyError:
                        pass
              
                try:
                    if label != 'CSF':
                        D_sumProb[FAOCountry] = min(D_sumProb[FAOCountry],D_risk[FAOCountry, poll]) # consider the chemcials are fully dependent in rouseing diseases

                except KeyError:
                    if label != 'CSF':
                        D_sumProb[FAOCountry] =  D_risk[FAOCountry, poll]

    for FAOCountry in D_sumProb:
        D_sumProb[FAOCountry] = 1-D_sumProb[FAOCountry]
    return D_sumProb

def get_threathold(arr, a):
    for i in range(len(arr)):
        if np.where(arr[i]>a, True, False):
            #print(i)
            break
    return i + 1

def display_worldmap_risk(L_MapCountry, pollname, D_risk, D_translate, path, Mapfilename = "Map of Polltant Risk in Protein Diet.html"):
    L_risk  = []
    L_Country = []
    for country in L_MapCountry:
        if country == "Côte d'Ivoire":
            try:
                disp_risk = D_risk[country]
                L_Country.append(country)
                #L_risk.append(np.log10(disp_risk))
                L_risk.append(disp_risk)
            except KeyError:
                print(country, 'has wrong risk/ no country info')
        else:
            try:
                disp_country = D_translate[country]
                disp_risk = D_risk[country]
                L_Country.append(disp_country)
                #L_risk.append(np.log10(disp_risk))
                L_risk.append(disp_risk)
            except KeyError:
                print(country, 'has wrong risk/ no country info')
    #print(len(L_risk),len(L_Country))
    stages = [i for i in np.arange(0,1.01,1/3)] + [i for i in np.arange(1,41,40/16)] +[np.inf]
    #stages = [0,1/6,1/3,1/2,2/3,5/6,1]
    color = heatmap_colors #['#0045BF','#5BAAFF','#A8DEFF','#FF96A9','#FF3C3F','#C20104', '#9C3700']
    c = (
        Map(init_opts=opts.InitOpts(width="1400px",height='600px'))  # 图表大小
        # 添加数据系列名称, 数据(list格式), 地图名称, 不显示小红点
        .add("", [list(z) for z in zip(L_Country, L_risk)], "world",is_map_symbol_show=False)
        .set_series_opts(label_opts=opts.LabelOpts(is_show=False))  # 标签不显示(国家名称不显示)
        .set_global_opts(
            title_opts=opts.TitleOpts(title="Map of "+pollname+" Risk",subtitle=''),   # 主标题与副标题名称
            visualmap_opts=opts.VisualMapOpts( is_piecewise = True, pieces = [
                {'min':stages[i], 'max':stages[i+1], 'color':color[i]} for i in range(len(stages)-1)
                ]),               # 值映射最大值
        )
    )
    c.render(path + Mapfilename)
'''________________________________________________________save files___________________________________________________________'''
def save_concbynation(D_conc_specific, filename, path):
    os.makedirs(path+filename, exist_ok=True)
    savepath = path+filename+'/'
    for country in D_conc_specific:
        D_country = {}
        for foodTP, poll in D_conc_specific[country]:
            arr = np.sort(D_conc_specific[country][foodTP, poll])
            D_country[foodTP+'^'+poll] = arr
        df = pd.DataFrame(D_country)
        df.to_excel(savepath+country+'.xlsx')
    return

def save_conclist(D_conclist, filename, path='', Save=True):
    if Save:
        with open(path+filename, mode = 'w', newline='', encoding='utf-8-sig') as file:
            data = csv.writer(file)
            data.writerow(["OceWatCont",'pollABB','SampleTP'] + [ 'ave','sd','med','97.5%','99%' ])
            for item in D_conclist:
                OceWatCont, pollABB, SampleTP = item
                
                L_conc = D_conclist[item]
                L_conc.sort()
                u = scipy.mean(L_conc)
                sd = stats.stdev(L_conc)
                Medium = L_conc[int(0.5*len(L_conc))]
                P975 = L_conc[int(0.975*len(L_conc))]
                P990 = L_conc[int(0.99*len(L_conc))]
                '''
                if type(SampleTP) == tuple:
                    S = ''
                    for item in SampleTP:
                        S + item + ','
                    SampleTP = S.strip(',')
                '''
                data.writerow([OceWatCont,pollABB,str(SampleTP),u,sd,Medium,P975,P990])
    return

def save_exposure(D_exposure, path, filename='expo.csv'):
    for country in D_exposure:
        try:
            for poll in D_exposure[country]:
                length = len(D_exposure[country][poll])
                break
            with open(path + 'N'+str(length)+'_'+country+'_'+filename, mode='w', newline='') as file:
                data = csv.writer(file)
                lineone= [poll for poll in D_exposure[country]]
                data.writerow(lineone)
                for i in range(length):
                    line = []
                    for poll in lineone:
                        line.append( D_exposure[country][poll][i] )
                    data.writerow(line)
        except UnboundLocalError:
            print(country, 'has no effective results')
    return
'''___________________________________________________________________________________________________________________________________________________'''
def flowwork_year(MajorCatPoll, year, dietpath, tradepath, concpath = 'E:/BlueFood/input_file/'):
    N_sims = 100
    N_conc = 1000
    all_blue = False
    poll_filename = MajorCatPoll + ' in food data.csv' #1113
    D_pollutant_distribution, D_summary_pollutants, L_sites, L_pollutant = read_PollInFood(concpath, poll_filename, simyear = year)
    D_SumPoll_distri, D_EachPoll_distri  = separate(D_pollutant_distribution, MajorCatPoll)
    del(D_pollutant_distribution)
    
    D_TerranSite = read_territorial_region(concpath, filename='SampleSite-Terri.csv')
    D_WatersSite, D_Water2Country = read_aquatic_region(concpath, filename = 'SampleSite-Waters.csv')
    D_Sample2FAO, D_FAO2map = read_countrycode(concpath, 'Map_Country_Code_OECD.csv')
    
    # for specific pollutants/ in Tarren, get the pollution conc pool
    D_pool_Terran_Each = get_poll_pool(D_EachPoll_distri, D_TerranSite, 'T', N_conc)
    # for specific pollutants/ in waters, get the pollution conc pool
    D_pool_Waters_Each = get_poll_pool(D_EachPoll_distri, D_WatersSite, 'W', N_conc)
    #save_conclist({**D_pool_Terran_Each,**D_pool_Waters_Each}, 'PFAS individual conc 0918.csv', path=path, Save=True)
    
    D_C2Water_region, D_C2Tarren_region, L_country = get_country2region(D_Water2Country, D_TerranSite)
    del(D_TerranSite)
    
    D_conc_country_T = {}
    D_conc_country_W = {}
    
    L_FAOcountry = []
    # get specific conc of poll by country
    for country in L_country:
        try:
            FAOcountry = D_Sample2FAO[country]
            L_FAOcountry.append(FAOcountry)
            #all_blue = False
            #D_dish = get_dishes(D_FAO_diet, FAOcountry,  N_sims=N_sims, all_blue = all_blue)
            if not all_blue:
                L_Region_T = list( D_C2Tarren_region[country] )
                D_conc_country_T = {**SimuConsum(D_pool_Terran_Each, FAOcountry, L_Region_T, 'T', N_conc = N_conc), **D_conc_country_T}
                #print(country,'Tarren concentration estimated')
            L_Region_W = list( D_C2Water_region[country] )
            D_conc_country_W = {**SimuConsum(D_pool_Waters_Each, FAOcountry, L_Region_W, 'W', N_conc = N_conc), **D_conc_country_W}
            
        except KeyError:
            pass
            #print(country, 'is not in diet survey file')
    #print('Conc_W', [i for i in D_conc_country_W['Costa Rica']])
    #print('Conc_T', [i for i in D_conc_country_T['Costa Rica']])    
    os.makedirs(RUN_OUTPUT, exist_ok=True)
    savepath = str(RUN_OUTPUT) + '/'
    print(savepath)
    concfile = 'terri_conc year '+str(year)
    save_concbynation(D_conc_country_T, concfile, savepath)
    concfile = 'water_conc year '+str(year)
    save_concbynation(D_conc_country_W, concfile, savepath)
    
    trade_file = 'consump_trade matrix '+str(year)+'.xlsx'
    dietfile = 'FAOSTAT_'+str(year)+'.csv'
    #Simulated_country = Simulated_country[39:]
    
    'simulation for year:'
    D_trade_T, D_trade_W, Simulated_country = read_trade_matrix(tradepath, trade_file)
    D_FAO_diet = read_FAO_diet(dietpath, dietfile)
    from scipy.stats import gmean
    os.makedirs(savepath+str(year)+'_US_aqours_exposure/', exist_ok=True); os.makedirs(savepath+str(year)+'_US_terri_exposure/', exist_ok=True); os.makedirs(savepath+str(year)+'_US_total_exposure/', exist_ok=True)
    for FAOcountry in ['United States']:
        D_exposure_W = tradeing(FAOcountry, D_conc_country_W, D_FAO_diet, D_trade = D_trade_W, N_sims=N_sims, all_blue = all_blue)
        D_exposure_T = tradeing(FAOcountry, D_conc_country_T, D_FAO_diet, D_trade = D_trade_T, N_sims=N_sims, all_blue = all_blue)
        D_exposure = SumWandT_expo(D_exposure_T, D_exposure_W)
        save_exposure(D_exposure_W, savepath+str(year)+'_US_aqours_exposure/', filename='expo.csv')
        save_exposure(D_exposure_T, savepath+str(year)+'_US_terri_exposure/', filename='expo.csv')
        save_exposure(D_exposure, savepath+str(year)+'_US_total_exposure/', filename='expo.csv')
        print(year, 'trade PFOS', FAOcountry, gmean(D_exposure[FAOcountry]['PFOS'])/65 )
        print(year, 'trade PFOA', FAOcountry, gmean(D_exposure[FAOcountry]['PFOA'])/65 )
        print(year, 'trade PFHS', FAOcountry, gmean(D_exposure[FAOcountry]['PFHxS'])/65 )
    
import time
#time.sleep(3600)
for year in range(2003,2017,1):
    flowwork_year('PFAS',
                  year,
                  dietpath = str(INPUT/'diets')+'/',
                  tradepath = str(INPUT/'trades')+'/',
                  concpath = str(INPUT/'concentration_cases/0106_folder')+'/')
'''
#'FAOSTAT_diet_2021 (baseline proj)' 'FAOSTAT_diet_2020 (baseline).csv' 'FAOSTAT_2050 (bluefood).csv';
# 'FAOSTAT_diet_2050 (high load 250716)'
# FAOSTAT_diet_2021 (baseline no_aqua); FAOSTAT_diet_2021 (baseline proj)
# 'FAOSTAT_diet_2050_BAU.csv'

100ng/g * 300g = 30000ng/day --> 500ng/kg/day -->
PFOS
PFOA
PFNA
PFUnDA
PFDA
PFHxS
PFTrDA
PFHpA
PFHxA
PFDoDA
PFTeDA
PFBS
'''
'''
PFOS
PFOA
PFBS
PFBA
PFDoDA
PFHxS
PFHxA
PFNA
PFOcDA*
PFPrA
PFTeDA
PFUnDA
'''
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 13 15:24:17 2025

@author: huboy

calculation of GHG emission
"""

import pandas as pd
import numpy as np

L_country = ['Argentina', 'Australia', 'Austria', 'Belgium', 'Brazil', 'Bulgaria', 'Canada', 'Chile', 
             'China', 'Colombia', 'Costa Rica', 'Croatia', 'Czechia', 'Denmark', 'Estonia', 'Finland', 
             'France', 'Germany', 'Greece', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Ireland', 'Israel',
             'Italy', 'Japan', 'Korea', 'Latvia', 'Lithuania', 'Luxembourg', 'Mexico', 'Netherlands',
             'New Zealand', 'Norway', 'Poland', 'Portugal', 'Romania', 'Slovak Republic', 'Slovenia', 
             'South Africa', 'Spain', 'Sweden', 'Switzerland', 'Turkiye', 'United Kingdom', 'United States']

D_eatlive_ratio = {'Bovine Meat':0.4, "Mutton & Goat Meat":0.37, 'Pigmeat':0.52, 'Poultry Meat':0.51, 'Eggs':0.89, 'Meat, Other':0.85,
                   'Crustaceans':0.4, 'Molluscs, Other':0.15, 'Freshwater Fish':0.56, 'Demersal Fish':0.56, 'Pelagic Fish':0.56,
                   'Marine Fish, Other':0.56, 'Aquatic Animals, Others':0.56,}

def read_GHG_intensity(path, file):
    D_GHG = {}
    df = pd.read_excel(path+file, sheet_name='summary')
    for i in range(len(df['name'])):
        D_GHG[df['name'][i]] = df['GHG'][i]
    return D_GHG #g CO2 eq/ g food

def read_countryratio(path, file):
    sheet = 'ratio'
    D_r = {}
    df = pd.read_excel(path+file, sheet_name=sheet)
    for i in range(len(df['Country'])):
        D_r[df['Country'][i]] = {'Bovine Meat': df['Bovine Meat'][i],
                                 "Mutton & Goat Meat": df['Mutton & Goat Meat'][i],
                                 'Pigmeat': df['Pigmeat'][i],
                                 'Poultry Meat': df['Poultry Meat'][i],
                                 'Eggs': df['Eggs'][i],
                                 'Meat, Other': df['Meat, Other'][i]
                                 }
    return D_r

def read_diet(path, file):
    df = pd.read_csv(path+file)
    D_food_volumn = {}
    for i in range(len(df['country'])):
        try:
            D_food_volumn[df['country'][i]][df['food'][i]] = df['value'][i]/365*1000*D_eatlive_ratio[df['food'][i]]
        except KeyError:
            D_food_volumn[df['country'][i]] = {df['food'][i] : df['value'][i]/365*1000*D_eatlive_ratio[df['food'][i]] }
    return D_food_volumn #g/day
            
def compute_E(country, D_food_volumn, D_GHG, D_r, L_food = None, D_E = {}):
    if L_food == None:
        L_food = ['Molluscs, Other', 'Demersal Fish', 'Pelagic Fish', 'Marine Fish, Other', 'Freshwater Fish','Crustaceans', 'Aquatic Animals, Others'
                  , 'Eggs', 'Poultry Meat', 'Pigmeat', 'Mutton & Goat Meat', 'Bovine Meat', 'Meat, Other']
    arr_ratio = []
    for food in L_food:
        try:
            arr_ratio.append(D_r[country][food])
        except KeyError:
            arr_ratio.append(1)
    arr_ratio = np.array(arr_ratio)
    arr_GHG = np.array([D_GHG[food] for food in L_food])
    arr_vol = np.array([D_food_volumn[country][food] for food in L_food])
    arr_E = arr_GHG*arr_vol*arr_ratio
    D_E[country] = list(arr_E) + [np.sum(arr_E)]
    return D_E, L_food+['Total']

def save_file(path, file, D_E, L_labels):
    df = pd.DataFrame(D_E, index=L_labels)
    df_T = df.transpose()
    df_T.to_excel(path+file)
    return

def main():
    GHG_file = 'GHG emission intensity (2020).xlsx'
    r_file = 'terri GHG intensity by country.xlsx'
    food_file = 'FAOSTAT_diet_2020 (baseline).csv'
    food_file = 'FAOSTAT_diet_2050_LowLoad_EggResidualToPoultry.csv'
    #food_file = 'FAOSTAT_diet_2050_BAU.csv'
    #food_file = 'emissions/FAOSTAT_diet_2050 (high load).csv'
    savefile = 'GHG emission LR egg residual to poultry in 47 countries.xlsx'
    path = 'G:/projects/BLUE FOOD/CO2 emission/'
    D_Emission = {}
    D_GHG = read_GHG_intensity(path, GHG_file)
    D_r = read_countryratio(path, r_file)
    D_food_volumn =  read_diet(path, food_file)
    for country in L_country:
        D_Emission, L_labels = compute_E(country, D_food_volumn, D_GHG, D_r, D_E = D_Emission)
    save_file(path, savefile, D_Emission, L_labels)
    return

main()
    
    
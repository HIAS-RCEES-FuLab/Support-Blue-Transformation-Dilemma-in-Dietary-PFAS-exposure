# US 2003-2016 longitudinal PFOA/PFOS runner for the adapted original R model.
# All model fitting, integration, population reconstruction and validation run on ECS.
args <- commandArgs(trailingOnly=TRUE)
arg <- function(key, default=NULL) { i <- match(key,args); if (is.na(i)) default else args[i+1L] }
job <- normalizePath(arg('--job'), winslash='/', mustWork=TRUE)
mode <- arg('--mode','smoke')
.libPaths(c(file.path(job,'Rlibrary'),.libPaths()))
stopifnot(requireNamespace('deSolve',quietly=TRUE),requireNamespace('openxlsx',quietly=TRUE),requireNamespace('jsonlite',quietly=TRUE))
options(pbk.parameter_workbook=file.path(job,'original_source','Fabrega_2015_data.xlsx'))
source(file.path(job,'code','PFAS_PBK_US_2003_2016_Fabrega_2015.R'))
original_env <- new.env(parent=globalenv())
expressions <- parse(file.path(job,'original_source','PFAS_PBK_validation_Fabrega_2015.R'))
for (e in expressions) if (is.call(e) && identical(e[[1]],as.name('<-')) && as.character(e[[2]]) %in% c('create.params','create.inits','create.events','ode.func')) eval(e,original_env)
original_env$create.params <- create.params
YEARS <- 2003:2016
dates <- as.Date(paste0(c(YEARS,2017),'-01-01'))
bounds <- as.integer(dates-dates[1])
state_retained <- c('APlas','AG','AL','AF','ALu','AB','ABm','AK','AFil','AStor','AR')
substances <- c('PFOA','PFOS')
fractions <- list(PFOA=c(aquatic=.151,terrestrial=.183),PFOS=c(aquatic=.50,terrestrial=.771))
targets <- c(PFOA=3.95,PFOS=20.70)
# Fixed virtual populations; worker/grid options only control acceleration.
pop_sizes <- c(PFOA=100000L,PFOS=100000L)
stopifnot(all(pop_sizes==100000L))
scenarios <- c('no_exposure','aquatic_only','terrestrial_only','aquatic_plus_terrestrial')
out <- file.path(job,'results')
dir.create(out,showWarnings=FALSE,recursive=TRUE)
json <- function(x,path) jsonlite::write_json(x,path,pretty=TRUE,auto_unbox=TRUE,digits=16,na='null')
gm <- function(x) {stopifnot(all(is.finite(x)),all(x>0));exp(mean(log(x)))}
summary_values <- function(x) {
  stopifnot(all(is.finite(x)),all(x>=0))
  p <- quantile(x,c(.05,.10,.25,.5,.75,.90,.95),names=FALSE,type=7)
  c(geometric_mean=if(any(x==0)) 0 else gm(x),arithmetic_mean=mean(x),sd=sd(x),
    setNames(p,c('p05','p10','p25','median','p75','p90','p95')))
}
parameters <- function(compound) create.params(list(BW=70,substance=compound,exposure=0,exposure_times=0))
equilibrium_plasma <- function(p,ngday) {
  rate <- ngday/1000/24
  cf <- rate/p$QFil
  (rate+p$Tm*cf/(p$Kt+cf))/(p$QFil*p$Free)
}
balanced_state <- function(p,ngday) {
  rate <- ngday/1000/24
  cf <- rate/p$QFil
  reabs <- p$Tm*cf/(p$Kt+cf)
  cp <- equilibrium_plasma(p,ngday)
  cg <- p$PG*(cp+rate/(p$QG*p$Free))
  cl <- p$PL*(p$QL*cp+p$QG*cg/p$PG)/(p$QL+p$QG)
  ck <- p$PK*(cp+reabs/(p$QK*p$Free))
  y <- create.inits(p)
  y[state_retained] <- c(cp*p$VPlas,cg*p$VG,cl*p$VL,p$PF*cp*p$VF,
      p$PLu*cp*p$VLu,p$PB*cp*p$VB,p$PBm*cp*p$VBm,ck*p$VK,cf*p$VFil,rate/p$kurine,p$PR*cp*p$VR)
  y['Intake'] <- rate
  y['A_in'] <- sum(y[state_retained])
  stopifnot(all(is.finite(y)),all(y>=0))
  y
}
run_path <- function(p,annual,initial_ngday,rtol=1e-8,atol=1e-10,keep_states=FALSE,output_step_days=7L) {
  y <- balanced_state(p,initial_ngday)
  cp <- numeric(tail(bounds,1)+1L)
  cp[1] <- y['APlas']/p$VPlas
  max_mass_error <- 0
  min_amount <- Inf
  # Keep the original continuous hourly input convention. Each year's rates are constant.
  for (i in seq_len(nrow(annual))) {
    y['Intake'] <- annual[i,'water_solution']/1000/24
    pp <- p
    pp$Intake_aquatic <- annual[i,'aquatic']/1000/24
    pp$Intake_terrestrial <- annual[i,'terrestrial']/1000/24
    pp$f_aqua <- annual[i,'f_aqua'];pp$f_terri <- annual[i,'f_terri'];pp$f_water <- 1
    days <- bounds[i+1L]-bounds[i]
    evaluation_days <- sort(unique(c(seq(0,days,by=output_step_days),0:min(7,days),days)))
    sol <- deSolve::ode(y=y,times=evaluation_days*24,func=ode.func,parms=pp,
                       method='lsodes',rtol=rtol,atol=atol)
    stopifnot(nrow(sol)==length(evaluation_days),all(is.finite(sol)),tail(sol[,'time'],1)==days*24)
    cp[(bounds[i]+1L):(bounds[i+1L]+1L)] <- approx(evaluation_days,sol[,'CPlas'],xout=0:days)$y
    max_mass_error <- max(max_mass_error,max(abs(sol[,'Mass_Balance'])))
    min_amount <- min(min_amount,min(sol[,state_retained]))
    y <- setNames(as.numeric(tail(sol[,names(y),drop=FALSE],1)),names(y))
  }
  stopifnot(min_amount>=-1e-8,max_mass_error<1e-4,all(cp>=0))
  list(curve=cp,mass_error=max_mass_error,min_amount=min_amount,final_state=if(keep_states)y else NULL)
}

if (mode=='smoke') {
  checks <- list()
  for (compound in substances) {
    p <- parameters(compound)
    y <- create.inits(p);y['Intake'] <- 40/1000/24
    times <- c(0,1,24,240,8760,87600)
    a <- deSolve::ode(y,times,original_env$ode.func,p,method='lsodes',rtol=1e-8,atol=1e-10)
    b <- deSolve::ode(y,times,ode.func,p,method='lsodes',rtol=1e-8,atol=1e-10)
    delta <- max(abs(a-b));stopifnot(delta<1e-9)
    z <- balanced_state(p,40)
    pp <- p;pp$f_aqua <- .25;pp$Intake_aquatic <- 160/1000/24;pp$Intake_terrestrial <- 0
    z['Intake'] <- 0
    residual <- ode.func(0,z,pp)[[1]][match(state_retained,names(z))]
    stopifnot(max(abs(residual))<1e-8)
    zz <- create.inits(p)
    pp$f_aqua <- 0
    zzsol <- deSolve::ode(zz,c(0,24,240),ode.func,pp,method='lsodes',rtol=1e-8,atol=1e-10)
    stopifnot(max(abs(zzsol[,'CPlas']))==0,max(abs(zzsol[,'A_in']))==0)
    # Equal available input must yield the same state derivatives, including A_in.
    qa <- p;qa$Intake_aquatic <- 40/1000/24;qa$f_aqua <- .5
    qt <- p;qt$Intake_terrestrial <- 40/1000/24;qt$f_terri <- .5
    da <- ode.func(0,zz,qa)[[1]];dt <- ode.func(0,zz,qt)[[1]]
    stopifnot(max(abs(da-dt))<1e-14)
    elapsed <- system.time({test <- run_path(p,cbind(water_solution=rep(40,14),aquatic=0,terrestrial=0,f_aqua=1,f_terri=1),40)})[['elapsed']]
    checks[[compound]] <- list(original_f1_max_absolute_difference=delta,
      equilibrium_max_retained_derivative=max(abs(residual)),f0_zero_food_input_verified=TRUE,
      fraction_applied_once_verified=TRUE,mass_balance_error_ug=test$mass_error,
      continuous_equilibrium_relative_drift=max(abs(test$curve/equilibrium_plasma(p,40)-1)),
      full_14_year_path_seconds=elapsed)
  }
  json(list(status='passed',checks=checks,R=R.version.string),file.path(out,'SMOKE_VERIFICATION.json'))
  print(checks)
  quit(status=0)
}

stopifnot(mode %in% c('prepare','run'))
input_root <- file.path(dirname(job),'exposure_inputs','US 2003-2016 time depend Mix_k')
if (mode=='prepare') {
  annual <- setNames(vector('list',length(substances)),substances)
  manifest <- list();k <- 0L
  for(compound in substances) annual[[compound]] <- list()
  for (year in YEARS) for (kind in c('total','aqours','terri')) {
    path <- file.path(input_root,paste0(year,'_US_',kind,'_exposure'),'N100000_United States_expo.csv')
    x <- read.csv(path,check.names=FALSE)
    stopifnot(nrow(x)==100000L,all(substances %in% names(x)))
    for (compound in substances) {
      values <- x[[compound]]
      stopifnot(all(is.finite(values)),all(values>=0))
      annual[[compound]][[paste(year,kind,sep='_')]] <- sort(values)
    }
    k <- k+1L;manifest[[k]] <- list(path=path,md5=unname(tools::md5sum(path)),rows=nrow(x),year=year,kind=kind)
    cat('READ_INPUT',year,kind,'\n');flush.console()
  }
  saveRDS(annual,file.path(out,'annual_intake_sorted.rds'),compress=TRUE)
  json(manifest,file.path(out,'EXPOSURE_INPUT_MANIFEST.json'))
  json(list(compounds=substances,years=YEARS,population_n=as.list(pop_sizes),physiological_body_weight_kg=70,
    input_unit='ng/person/day; use raw exposure, no body-weight re-scaling',
    serum_unit='ng/mL = ug/L',oral_input='continuous hourly input as in the GitHub R script',
    food_fractions=fractions,water_solution_fraction=1,post2004_exposure_multiplier=1,
    baseline='Calibrate only 2003-2004 solution-equivalent input and equilibrium initialization to the first NHANES GM',
    scenarios=scenarios,persistence='Same exposure percentile retained across years and food branches; marginal intake files sorted separately',
    parameter_workbook=getOption('pbk.parameter_workbook')),file.path(out,'settings.json'))
  quit(status=0)
}

annual_sorted <- readRDS(file.path(out,'annual_intake_sorted.rds'))
requested <- arg('--compound',NULL)
if(!is.null(requested)) substances <- requested
grid_n <- as.integer(arg('--grid','257'))
workers <- as.integer(arg('--workers','3'))
stopifnot(workers>=1L,grid_n>=33L)
cl <- if(workers>1L) parallel::makeCluster(workers,type='PSOCK') else NULL
if(!is.null(cl)) {
  parallel::clusterExport(cl,c('job'))
  parallel::clusterEvalQ(cl,{
    .libPaths(c(file.path(job,'Rlibrary'),.libPaths()))
    options(pbk.parameter_workbook=file.path(job,'original_source','Fabrega_2015_data.xlsx'))
    source(file.path(job,'code','PFAS_PBK_US_2003_2016_Fabrega_2015.R'))
    NULL
  })
  parallel::clusterExport(cl,c('YEARS','bounds','state_retained','balanced_state','equilibrium_plasma','run_path'))
}
map_paths <- function(jobs,p) {
  fun <- function(j,p) run_path(p,j$annual,j$initial,output_step_days=if(isTRUE(j$dense))1L else 7L)
  if(is.null(cl)) lapply(jobs,fun,p=p) else parallel::parLapplyLB(cl,jobs,fun,p=p)
}
make_grid <- function(n,ranks) sort(unique(c(seq(min(ranks),max(ranks),length.out=n),
  exp(seq(log(min(ranks)),log(.02),length.out=40)),1-exp(seq(log(min(ranks)),log(.02),length.out=40)))))
at_samples <- function(curves,grid,ranks,day) {
  result <- numeric(length(ranks));lower <- floor(day);frac <- day-lower
  for(d in unique(lower)) {
    idx <- which(lower==d)
    a <- splinefun(grid,curves[,d+1L],method='monoH.FC')(ranks[idx])
    b <- splinefun(grid,curves[,d+2L],method='monoH.FC')(ranks[idx])
    result[idx] <- a*(1-frac[idx])+b*frac[idx]
  }
  stopifnot(all(is.finite(result)),all(result>=0));result
}
rows_period <- list();rows_year <- list();diagnostics <- list()
bench <- read.csv(file.path(dirname(job),'code_and_results','benchmarks','nhanes_pfas_total_population.csv'))
for(compound in substances) {
  started <- proc.time()[['elapsed']]
  p <- parameters(compound);N <- pop_sizes[[compound]]
  stopifnot(length(N)==1L,!is.na(N),N==100000L)
  ranks <- (seq_len(N)-.5)/N
  annual <- matrix(0,nrow=N,ncol=length(YEARS)*3L)
  for(i in seq_along(YEARS)) for(k in seq_len(3L)) {
    key <- paste(YEARS[i],c('total','aqours','terri')[k],sep='_')
    annual[,3L*(i-1L)+k] <- approx((seq_len(100000L)-.5)/100000,annual_sorted[[compound]][[key]],xout=ranks,rule=2)$y
  }
  grid <- make_grid(grid_n,ranks)
  grid_annual <- vapply(seq_len(ncol(annual)),function(i) approx(ranks,annual[,i],xout=grid,rule=2)$y,numeric(length(grid)))
  set.seed(if(compound=='PFOA')2601105 else 2601106)
  sample_period <- lapply(seq(1,13,2),function(i)runif(N,bounds[i],bounds[i+2L]))
  sample_year <- lapply(seq_along(YEARS),function(i)runif(N,bounds[i],bounds[i+1L]))
  baseline_plan <- function(values,m) cbind(water_solution=c(values[1:2]*m,rep(0,12)),aquatic=0,terrestrial=0,f_aqua=0,f_terri=0)
  # Root fit uses the full rank distribution for initial equilibrium, then checks the
  # actual 2003-2004 sampling window with the R ODE. No future measurement enters it.
  m <- uniroot(function(x) log(gm(equilibrium_plasma(p,annual[,1]*x))/targets[[compound]]),c(1e-5,1000),tol=1e-10)$root
  fit_grid <- make_grid(65L,ranks)
  fit_annual <- vapply(seq_len(ncol(annual)),function(i)approx(ranks,annual[,i],xout=fit_grid,rule=2)$y,numeric(length(fit_grid)))
  baseline_gm <- function(multiplier) {
    jobs <- lapply(seq_along(fit_grid),function(i)list(annual=baseline_plan(fit_annual[i,seq(1,42,3)],multiplier)[1:2,,drop=FALSE],initial=fit_annual[i,1]*multiplier))
    solved <- map_paths(jobs,p)
    curves <- do.call(rbind,lapply(solved,`[[`,'curve'))
    gm(at_samples(curves,fit_grid,ranks,sample_period[[1]]))
  }
  m <- uniroot(function(x)log(baseline_gm(x)/targets[[compound]]),c(m/2,m*2),tol=1e-8)$root
  cat('CALIBRATED_BASELINE',compound,m,'\n');flush.console()
  compound_out <- file.path(out,compound);dir.create(compound_out,showWarnings=FALSE)
  for(scenario in scenarios) {
    cat('START_SCENARIO',compound,scenario,'grid',length(grid),'\n');flush.console()
    plan <- function(values) {
      raw_total <- values[seq(1,42,3)];raw_aq <- values[seq(2,42,3)];raw_terr <- values[seq(3,42,3)]
      aq_on <- scenario %in% c('aquatic_only','aquatic_plus_terrestrial')
      tr_on <- scenario %in% c('terrestrial_only','aquatic_plus_terrestrial')
      cbind(water_solution=c(raw_total[1:2]*m,rep(0,12)),
        aquatic=c(0,0,raw_aq[3:14]*aq_on),terrestrial=c(0,0,raw_terr[3:14]*tr_on),
        f_aqua=fractions[[compound]][['aquatic']],f_terri=fractions[[compound]][['terrestrial']])
    }
    jobs <- lapply(seq_along(grid),function(i)list(annual=plan(grid_annual[i,]),initial=grid_annual[i,1]*m))
    solved <- map_paths(jobs,p)
    curves <- do.call(rbind,lapply(solved,`[[`,'curve'))
    scenario_out <- file.path(compound_out,scenario);dir.create(scenario_out,showWarnings=FALSE)
    saveRDS(list(grid=grid,curves=curves,baseline_multiplier=m),file.path(scenario_out,'solver_grid.rds'),compress=TRUE)
    # Independent ranks validate interpolation against freshly integrated R paths.
    check_ranks <- c(.0002,.003,.0137,.087,.219,.411,.638,.831,.974,.9967,.9998)
    check_ranks <- check_ranks[check_ranks>min(ranks)&check_ranks<max(ranks)]
    check_values <- vapply(seq_len(ncol(annual)),function(i)approx(ranks,annual[,i],xout=check_ranks,rule=2)$y,numeric(length(check_ranks)))
    check_jobs <- lapply(seq_along(check_ranks),function(i)list(annual=plan(check_values[i,]),initial=check_values[i,1]*m,dense=TRUE))
    exact <- map_paths(check_jobs,p)
    check_days <- sort(unique(c(seq(0,tail(bounds,1),by=91),unlist(lapply(bounds[-length(bounds)],function(d)d+0:14)))))
    errors <- c()
    for(j in seq_along(check_ranks)) {
      predicted <- vapply(check_days,function(d)splinefun(grid,curves[,d+1L],method='monoH.FC')(check_ranks[j]),numeric(1))
      actual <- exact[[j]]$curve[check_days+1L]
      errors <- c(errors,abs(predicted-actual)/pmax(abs(actual),1e-10))
    }
    max_interp <- max(errors)
    stopifnot(max_interp<.01)
    mass_error <- max(vapply(c(solved,exact),`[[`,numeric(1),'mass_error'))
    for(k in seq_along(sample_period)) {
      values <- at_samples(curves,grid,ranks,sample_period[[k]])
      cycle <- paste(YEARS[2*k-1],YEARS[2*k],sep='-')
      reference <- bench$gm[bench$compound==compound&bench$cycle==cycle]
      stopifnot(length(reference)==1L)
      s <- summary_values(values)
      rows_period[[length(rows_period)+1L]] <- c(list(compound=compound,scenario=scenario,period=cycle,n=N,
         NHANES_gmean=reference,gmean_percent_difference=100*(s[['geometric_mean']]/reference-1)),as.list(s))
      con <- gzfile(file.path(scenario_out,paste0(cycle,'_population.csv.gz')),'wt')
      write.csv(data.frame(individual_id=seq_len(N),persistent_percentile=ranks,
        sampling_day=sample_period[[k]],plasma_ng_ml=values),con,row.names=FALSE)
      close(con)
    }
    for(k in seq_along(sample_year)) {
      values <- at_samples(curves,grid,ranks,sample_year[[k]])
      rows_year[[length(rows_year)+1L]] <- c(list(compound=compound,scenario=scenario,year=YEARS[k],n=N),as.list(summary_values(values)))
    }
    diagnostics[[paste(compound,scenario,sep='_')]] <- list(mass_balance_max_error_ug=mass_error,
      interpolation_max_relative_error=max_interp,validation_ranks=check_ranks,grid_size=length(grid),
      baseline_only_multiplier=m,post2004_multiplier=1,food_f=as.list(fractions[[compound]]))
    json(diagnostics[[paste(compound,scenario,sep='_')]],file.path(scenario_out,'verification.json'))
    cat('FINISHED_SCENARIO',compound,scenario,'mass_error',mass_error,'interpolation',max_interp,'\n');flush.console()
  }
  json(list(compound=compound,runtime_seconds=proc.time()[['elapsed']]-started,baseline_only_multiplier=m,
      initial_equilibrium_GM=gm(equilibrium_plasma(p,annual[,1]*m)),n=N),file.path(compound_out,'settings.json'))
}
as_rows <- function(x) do.call(rbind,lapply(x,function(r)as.data.frame(r,stringsAsFactors=FALSE)))
periods <- as_rows(rows_period);annual_results <- as_rows(rows_year)
suffix <- if(length(substances)==1L)paste0('_',substances)else ''
write.csv(periods,file.path(out,paste0('period_results',suffix,'.csv')),row.names=FALSE)
write.csv(annual_results,file.path(out,paste0('annual_results',suffix,'.csv')),row.names=FALSE)
json(list(status='passed',compound=substances,checks=diagnostics,completed_utc=format(Sys.time(),tz='UTC',usetz=TRUE),
  future_serum_measurements_used_for_fitting=FALSE,baseline_only_calibration=TRUE,
  original_equations_preserved_except_explicit_fractional_gut_input=TRUE),file.path(out,paste0('COMPLETE',suffix,'.json')))
print(periods[,c('compound','scenario','period','geometric_mean','NHANES_gmean','gmean_percent_difference')])
if(!is.null(cl)) {parallel::stopCluster(cl);cl <- NULL}

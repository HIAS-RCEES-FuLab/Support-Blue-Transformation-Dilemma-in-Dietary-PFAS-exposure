"""Seven-run PFAS sensitivity study, with original uncalibrated arrays retained.

Use the reviewed Zenodo concentration model and its full Cartesian exposure
distribution.  Matrix multiplication replaces only summation over source
countries; the original country-specific diet shuffles and RNG state remain.
"""
import argparse
import ast
import contextlib
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import subprocess
import sys
import time

import numpy as np
import pandas as pd
from weighted_median_fast import statistics as pooled_statistics

MODEL_HASH = '717f5c12825a8ff609fd075273a6dcd5b6d422a94c8aedac45162674f12b5e98'
RFD = {'PFOS': 2., 'PFHxS': 20.0, 'PFOA': 3., 'PFDA': 15.0, 'PFDoDA': 12., 'PFUnDA': 12.0, 'PFNA': 3.}
FACTORS = (0.5, 1., 2.)
SEEDS = tuple(range(301, 308))
DIETS = [('2020', 'diet/2020 diet.csv', ('notrade', 'trade')),
         ('2050_LL', 'diet/LR diet.csv', ('trade', 'Metatrade')),
         ('2050_BAU', 'diet/BAU diet.csv', ('trade', 'Metatrade')),
         ('2050_HL', 'diet/HR diet.csv', ('trade', 'Metatrade'))]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_model(source):
    if digest(source) != MODEL_HASH:
        raise ValueError('Unreviewed model source')
    tree = ast.parse(source.read_text(encoding='utf-8-sig'), filename=str(source))
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'flowwork_year')
    tree.body = [n for n in tree.body if n.lineno <= function.end_lineno]
    stop = next(i for i, n in enumerate(function.body)
                if isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant)
                and n.value.value == 'simulation for 2020:')
    function.body = function.body[:stop]
    function.body.append(ast.Return(value=ast.Call(func=ast.Name(id='_requested', ctx=ast.Load()),
        args=[ast.Name(id=n, ctx=ast.Load()) for n in ('path', 'D_conc_country_T', 'D_conc_country_W', 'N_sims')], keywords=[])))
    ast.fix_missing_locations(tree)
    ns = {'__name__': 'bluefood_seven_run_model', '__file__': str(source)}
    exec(compile(tree, str(source), 'exec'), ns)
    ns['save_concbynation'] = lambda *a, **k: None
    ns['ConvProduct'] = lambda a, b: np.multiply.outer(np.asarray(a), np.asarray(b)).reshape(-1)
    return ns


def fast_trade(ns, target, concentrations, diet, matrix, n_sims):
    sources = [c for c in diet if c in concentrations]
    dishes = ns['get_dishes'](diet, target, N_sims=n_sims, all_blue=False)
    pollutants = set(chem for _, chem in concentrations[target])
    if matrix is None:
        weights = np.asarray([float(c == target) for c in sources])
    else:
        weights = matrix.loc[sources, target].to_numpy(dtype=float)
    if not np.isfinite(weights).all() or (weights < 0).any():
        raise ValueError('Invalid trade matrix weights')
    result = {}
    for food in diet[target]:
        amounts = dishes[food]
        for chemical in pollutants:
            available = [i for i, c in enumerate(sources) if (food, chemical) in concentrations[c]]
            reweight = weights * np.asarray([int(i in available) for i in range(len(sources))])
            if np.sum(reweight) == 0:
                continue
            reweight = reweight / np.sum(reweight)
            meals = np.asarray([v * reweight for v in amounts])
            # Match the original shuffle even when a source's weight is zero.
            for i in available:
                np.random.shuffle(meals[:, i])
            active = [i for i in available if reweight[i] != 0]
            pool = np.vstack([concentrations[sources[i]][food, chemical] for i in active])
            values = np.matmul(meals[:, active], pool).reshape(-1)
            result[chemical] = result.get(chemical, 0.) + values
    return result


def statistics(groups):
    """Pooled individual median/geomean; population-weighted available mean."""
    vectors = [np.asarray(v, dtype=float) for v, p in groups]
    if any(v.ndim != 1 or not v.size or not np.isfinite(v).all() or (v < 0).any() for v in vectors):
        raise ValueError('Invalid exposure vector')
    pops = [float(p) for v, p in groups]
    covered = sum(pops)
    mean = sum(float(v.mean()) * p for v, p in zip(vectors, pops)) / covered
    if len(vectors) == 1:
        v = vectors[0]
        return mean, float(np.median(v)), (0. if (v == 0).any() else float(np.exp(np.log(v).mean()))), int(v.size)
    zeros = any((v == 0).any() for v in vectors)
    geometric = 0. if zeros else float(np.exp(sum(float(np.log(v).mean()) * p for v, p in zip(vectors, pops)) / covered))
    values = np.concatenate(vectors)
    weights = np.concatenate([np.full(v.size, p / v.size) for v, p in zip(vectors, pops)])
    order = np.argsort(values, kind='stable')
    cumulative = np.cumsum(weights[order])
    midpoint = covered / 2.
    i = int(np.searchsorted(cumulative, midpoint, side='left'))
    median = float(values[order[i]])
    if i + 1 < values.size and np.isclose(cumulative[i], midpoint, rtol=1e-12, atol=1e-12):
        median = (median + float(values[order[i + 1]])) / 2.
    return mean, median, geometric, int(values.size)


def aggregate_scenario(run_dir, scenario, records, geography, replicate, seed):
    rows = []
    year = scenario[:4]
    countries = list(geography)
    cached = {}
    for country in countries:
        with np.load(records[country], allow_pickle=False) as source:
            cached[country] = {key: source[key] for key in source.files}
    for pollutant in list(RFD) + ['SUM_AVAILABLE_PFAS', 'HI']:
        for factor in FACTORS:
            vectors = {}; counts = {}
            for country in countries:
                data = cached[country]
                labels = data['labels'].tolist()
                if pollutant in RFD and pollutant not in labels:
                    continue
                selected = labels if pollutant not in RFD else [pollutant]
                value = None
                for chem in selected:
                    i = labels.index(chem)
                    v = (data['terrestrial_' + str(i)] + factor * data['aquatic_' + str(i)]) / 62.
                    if pollutant == 'HI':
                        v = v / RFD[chem]
                    value = v.copy() if value is None else value + v
                vectors[country] = value
                counts[country] = len(selected)
            locations = [('country', c, [c]) for c in countries]
            locations += [('region', r, [c for c in countries if geography[c]['region'] == r])
                          for r in sorted({g['region'] for g in geography.values()})]
            locations += [('world', 'All represented countries', countries)]
            for level, place, members in locations:
                available = [c for c in members if c in vectors]
                total_population = sum(geography[c][year] for c in members)
                covered = sum(geography[c][year] for c in available)
                row = dict(replicate=replicate, seed=seed, scenario=scenario, year=int(year), aquatic_factor=factor,
                           pollutant=pollutant, geography_level=level, geography=place,
                           units='dimensionless' if pollutant == 'HI' else 'ng/kg_bw/day', mean='', median='', geometric_mean='',
                           mean_available_population='', population_total=total_population,
                           population_covered=covered, coverage_fraction=covered / total_population,
                           countries_covered=len(available), compound_count_min='', compound_count_max='', samples=0,
                           status='missing' if not available else ('partial' if len(available) != len(members) else 'ok'))
                if available:
                    mean, med, gm, n = pooled_statistics([(vectors[c], geography[c][year]) for c in available])
                    row.update(mean=mean * covered / total_population, median=med, geometric_mean=gm,
                               mean_available_population=mean, samples=n,
                               compound_count_min=min(counts[c] for c in available), compound_count_max=max(counts[c] for c in available))
                rows.append(row)
    print('Summarized', scenario, 'rows', len(rows), time.strftime('%H:%M:%S'), flush=True)
    return rows


def worker(args):
    root = args.root.resolve(); run = args.output.resolve() / ('run_' + str(args.worker))
    run.mkdir(parents=True, exist_ok=False)
    os.chdir(root / 'program')
    random.seed(args.seed); np.random.seed(args.seed)
    with (run / 'worker.log').open('w', encoding='utf-8', buffering=1) as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        print('Starting', args.worker, args.seed, time.strftime('%Y-%m-%d %H:%M:%S'), flush=True)
        geography = {}
        for r in csv.DictReader(args.geography.open(encoding='utf-8-sig', newline='')):
            # Filled from reference extraction, not the stale Country Code units.
            geography[r['country']] = {'region': r['region'], '2020': float(r['population_2020']), '2050': float(r['population_2050'])}
        ns = load_model(root / 'program' / 'simulation_single_trade.py')
        def requested(path, conc_t, conc_w, n_sims):
            t20, w20, countries = ns['read_trade_matrix'](path, 'consump_trade matrix.xlsx')
            t30, w30, countries30 = ns['read_trade_matrix'](path, 'consump_trade matrix 2050.xlsx')
            if list(countries) != list(countries30) or set(countries) != set(geography):
                raise ValueError('Country sets differ')
            if args.quick:
                countries = [c for c in ('United States', 'Japan') if c in countries]
                n_sims = 3
            geo = {c: geography[c] for c in countries}
            original_dishes = ns['get_dishes']
            if args.quick:
                diet = ns['read_FAO_diet'](path, DIETS[0][1])
                for country in countries:
                    for matrix_t, matrix_w in ((None, None), (t20, w20), (t30, w30)):
                        for conc, matrix in ((conc_w, matrix_w), (conc_t, matrix_t)):
                            state = np.random.get_state(); rs = random.getstate()
                            full = ns['tradeing'](country, conc, diet, D_trade=matrix, N_sims=n_sims, all_blue=False)[country]
                            after = np.random.get_state()
                            np.random.set_state(state); random.setstate(rs)
                            fast = fast_trade(ns, country, conc, diet, matrix, n_sims)
                            last = np.random.get_state()
                            if set(full) != set(fast): raise ValueError('Validation labels differ')
                            for chem in full:
                                np.testing.assert_allclose(full[chem], fast[chem], rtol=1e-11, atol=1e-10)
                            if not (after[0] == last[0] and np.array_equal(after[1], last[1]) and after[2:] == last[2:]):
                                raise ValueError('Fast method RNG state differs')
                            print('Validated full arrays', country, 'identity' if matrix is None else 'trade', len(full), flush=True)
            rows = []
            for label, filename, branches in DIETS:
                diet = ns['read_FAO_diet'](path, filename)
                branch_records = {b: {} for b in branches}
                for country in countries:
                    aqua_dishes = original_dishes(diet, country, N_sims=n_sims, all_blue=False)
                    land_dishes = original_dishes(diet, country, N_sims=n_sims, all_blue=False)
                    state = np.random.get_state(); rs = random.getstate()
                    for branch_index, branch in enumerate(branches):
                        np.random.set_state(state); random.setstate(rs)
                        mt, mw = (None, None) if branch == 'notrade' else ((t20, w20) if branch == 'trade' else (t30, w30))
                        ns['get_dishes'] = lambda *a, **k: aqua_dishes
                        aquatic = fast_trade(ns, country, conc_w, diet, mw, n_sims)
                        ns['get_dishes'] = lambda *a, **k: land_dishes
                        terrestrial = fast_trade(ns, country, conc_t, diet, mt, n_sims)
                        ns['get_dishes'] = original_dishes
                        if branch_index == 0: next_state = np.random.get_state(); next_rs = random.getstate()
                        labels = sorted(set(aquatic) & set(terrestrial) & set(RFD))
                        if not labels: raise ValueError('No available PFAS: ' + country)
                        arrays = {'labels': np.asarray(labels, dtype='U20')}
                        for i, chemical in enumerate(labels):
                            arrays['aquatic_' + str(i)] = aquatic[chemical]
                            arrays['terrestrial_' + str(i)] = terrestrial[chemical]
                        directory = run / 'raw_components+org' / (label + '_' + branch)
                        directory.mkdir(parents=True, exist_ok=True)
                        destination = directory / (hashlib.sha256(country.encode()).hexdigest()[:20] + '+org.npz')
                        np.savez(destination, **arrays)
                        branch_records[branch][country] = destination
                    np.random.set_state(next_state); random.setstate(next_rs)
                for branch in branches:
                    scenario = label + '_' + branch
                    rows += aggregate_scenario(run, scenario, branch_records[branch], geo, args.worker, args.seed)
                pd.DataFrame(rows).to_csv(run / 'replicate_stats.partial.csv', index=False)
            return rows
        ns['_requested'] = requested
        rows = ns['flowwork_year']('PFAS', *[x[1] for x in (DIETS[0], DIETS[3], DIETS[2], DIETS[1])], path=(root / 'input_file').as_posix() + '/')
        expected = 8 * 3 * 9 * ((2 + 2 + 1) if args.quick else (47 + 10 + 1))
        if len(rows) != expected: raise ValueError('Unexpected row count: ' + str(len(rows)))
        pd.DataFrame(rows).to_csv(run / 'replicate_stats.csv', index=False)
        (run / 'replicate_stats.partial.csv').unlink()
        (run / 'complete.json').write_text(json.dumps({'replicate': args.worker, 'seed': args.seed, 'rows': len(rows), 'quick': args.quick, 'runner_sha256': digest(Path(__file__))}, indent=2), encoding='utf-8')
        print('Completed run', args.worker, time.strftime('%Y-%m-%d %H:%M:%S'), flush=True)


def launch(args):
    args.output.mkdir(parents=True, exist_ok=False)
    inputs = args.root / 'input_file'
    files = [x[1] for x in DIETS] + ['consump_trade matrix.xlsx', 'consump_trade matrix 2050.xlsx', 'PFAS in food data.csv', 'most significant periods.xlsx']
    metadata = dict(seeds=SEEDS, runs=7, body_weight_kg=62, n_diet=100, n_conc=1000, aquatic_factors=FACTORS,
                    diets={x[0]: x[1] for x in DIETS}, trade='2020 pattern', Metatrade='2030-derived pattern',
                    original_model_sha256=MODEL_HASH, runner_sha256=digest(Path(__file__)), pooling_sha256=digest(Path(__file__).with_name('weighted_median_fast.py')), input_sha256={name: digest(inputs/name) for name in files},
                    geography_sha256=digest(args.geography), mean_aggregation='Full modeled population denominator as 0105; missing contributions omitted and coverage reported',
                    median_geomean='Population-weighted pooled individual values for available countries; total/HI cross-compound joint pairing not validated',
                    independent_runs='Seven fresh seeds; shared concentration/diet draws within trade comparisons and concentration factors')
    (args.output / 'run_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    env = os.environ.copy(); env['PYTHONHASHSEED'] = '0'
    for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'): env[key] = '1'
    remaining = list(enumerate(SEEDS, 1)); active = {}; streams = []
    try:
        while remaining or active:
            while remaining and len(active) < args.jobs:
                index, seed = remaining.pop(0)
                stream = (args.output / ('launcher_' + str(index) + '.log')).open('w', encoding='utf-8'); streams.append(stream)
                cmd = [sys.executable, str(Path(__file__).resolve()), '--root', str(args.root), '--output', str(args.output),
                       '--geography', str(args.geography), '--worker', str(index), '--seed', str(seed)]
                active[index] = subprocess.Popen(cmd, stdout=stream, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, env=env)
                print('Started', index, seed, flush=True)
            for index, proc in list(active.items()):
                code = proc.poll()
                if code is not None:
                    if code: raise RuntimeError('Worker failed: ' + str(index))
                    print('Finished', index, flush=True); del active[index]
            if shutil.disk_usage(args.output).free < 8 * 1024**3: raise RuntimeError('Insufficient disk free space')
            if active: time.sleep(5)
        (args.output / 'COMPLETE.txt').write_text('Seven independent complete simulation replicates.\n', encoding='utf-8')
    except BaseException:
        for proc in active.values():
            if proc.poll() is None: proc.terminate()
        raise
    finally:
        for stream in streams: stream.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True); parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--geography', type=Path, required=True); parser.add_argument('--worker', type=int)
    parser.add_argument('--seed', type=int); parser.add_argument('--jobs', type=int, default=2); parser.add_argument('--quick', action='store_true')
    args = parser.parse_args()
    for key in ('root', 'output', 'geography'): setattr(args, key, getattr(args, key).resolve())
    if os.environ.get('PYTHONHASHSEED') != '0': raise ValueError('Set PYTHONHASHSEED=0')
    if args.worker: worker(args)
    else: launch(args)


if __name__ == '__main__': main()

"""Exact weighted median by value partition, with stable-sort fallback.

The ordinary case takes expected O(n) work rather than a full O(n log n)
sort.  Near a cumulative-weight boundary, floating-point accumulation can
affect the historical sorted-cumsum convention.  Those cases deliberately
fall back to that exact convention.  Inputs are never modified.
"""
from __future__ import annotations

import math

import numpy as np


def sorted_weighted_median(values, weights, total_weight):
    """Historical stable-sort/cumsum definition, including midpoint averaging."""
    order = np.argsort(values, kind="stable")
    cumulative = np.cumsum(weights[order])
    midpoint = total_weight / 2.0
    index = int(np.searchsorted(cumulative, midpoint, side="left"))
    if index >= values.size:
        raise ValueError("Population total exceeds the represented observation weights")
    median = float(values[order[index]])
    if index + 1 < values.size and np.isclose(float(cumulative[index]), midpoint,
                                             rtol=1e-12, atol=1e-12):
        median = (median + float(values[order[index + 1]])) / 2.0
    return median


def weighted_median(values, weights, total_weight=None, *, validate=True, return_info=False):
    """Return the historical weighted median using exact value partitions.

    Nonnegative finite weights and finite real values are required.  A supplied
    total_weight should be the original sum of country populations, matching
    the caller's historical calculation rather than a newly rounded weight sum.
    No bins, approximations, distribution fitting or subsampling are used.
    """
    original_values = np.asarray(values, dtype=np.float64)
    original_weights = np.asarray(weights, dtype=np.float64)
    if original_values.ndim != 1 or original_values.size == 0 or original_values.shape != original_weights.shape:
        raise ValueError("Weighted median needs nonempty one-dimensional matching arrays")
    if validate and (not np.isfinite(original_values).all() or not np.isfinite(original_weights).all()
                     or (original_weights < 0).any()):
        raise ValueError("Weighted median values/weights must be finite; weights must be nonnegative")
    if total_weight is None:
        total_weight = float(np.sum(original_weights))
    total_weight = float(total_weight)
    if not math.isfinite(total_weight) or total_weight <= 0:
        raise ValueError("Weighted median requires positive finite total weight")
    midpoint = total_weight / 2.0
    values, weights = original_values, original_weights
    discarded_weight = 0.0
    iterations = 0
    while True:
        iterations += 1
        # A count median bounds the retained number of observations by half.
        # np.partition copies here, preserving the caller's simulation arrays.
        pivot = float(np.partition(values, values.size // 2)[values.size // 2])
        less = values < pivot
        equal = values == pivot
        below_weight = float(np.sum(weights[less]))
        equal_weight = float(np.sum(weights[equal]))
        absolute_below = discarded_weight + below_weight
        absolute_through = absolute_below + equal_weight
        if midpoint <= absolute_below:
            values, weights = values[less], weights[less]
        elif midpoint <= absolute_through:
            candidate = pivot
            break
        else:
            greater = ~(less | equal)
            discarded_weight = absolute_through
            values, weights = values[greater], weights[greater]
        if not values.size:
            # This can only arise from inconsistent supplied total_weight or
            # an unusual floating-point boundary; use the original convention.
            median = sorted_weighted_median(original_values, original_weights, total_weight)
            info = {"iterations": iterations, "sorted_fallback": True, "reason": "empty_partition"}
            return (median, info) if return_info else median

    # Bound a sequential nonnegative cumsum's floating-point error.  If either
    # edge of the candidate's tie block is near half, replay the historical sort
    # so its index and isclose midpoint averaging remain exactly unchanged.
    below_weight = float(np.sum(original_weights[original_values < candidate]))
    through_weight = below_weight + float(np.sum(original_weights[original_values == candidate]))
    epsilon = float(np.finfo(np.float64).eps)
    product = original_values.size * epsilon
    gamma = product / (1.0 - product) if product < 1 else math.inf
    guard = (gamma + 1e-12 + 16 * epsilon) * abs(total_weight) + 1e-12
    ambiguous = abs(below_weight - midpoint) <= guard or abs(through_weight - midpoint) <= guard
    median = (sorted_weighted_median(original_values, original_weights, total_weight)
              if ambiguous else candidate)
    info = {"iterations": iterations, "sorted_fallback": bool(ambiguous),
            "reason": "cumulative_boundary" if ambiguous else "partition",
            "rounding_guard": guard}
    return (median, info) if return_info else median


def statistics(groups):
    """Drop-in aggregate statistics preserving the original arithmetic order."""
    vectors = [np.asarray(v, dtype=float) for v, population in groups]
    if not vectors or any(v.ndim != 1 or not v.size or not np.isfinite(v).all() or (v < 0).any() for v in vectors):
        raise ValueError("Invalid exposure vector")
    populations = [float(population) for vector, population in groups]
    if not all(math.isfinite(p) and p > 0 for p in populations):
        raise ValueError("Invalid population weight")
    covered = sum(populations)
    mean = sum(float(v.mean()) * p for v, p in zip(vectors, populations)) / covered
    if len(vectors) == 1:
        vector = vectors[0]
        return mean, float(np.median(vector)), (0.0 if (vector == 0).any() else float(np.exp(np.log(vector).mean()))), int(vector.size)
    zeros = any((v == 0).any() for v in vectors)
    geometric = (0.0 if zeros else float(np.exp(sum(float(np.log(v).mean()) * p
                                                  for v, p in zip(vectors, populations)) / covered)))
    values = np.concatenate(vectors)
    weights = np.concatenate([np.full(v.size, p / v.size) for v, p in zip(vectors, populations)])
    median = weighted_median(values, weights, covered, validate=False)
    return mean, median, geometric, int(values.size)

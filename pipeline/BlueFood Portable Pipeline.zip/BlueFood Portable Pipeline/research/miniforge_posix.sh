# Shared by the POSIX launchers. This file is sourced, not executed.

has_forge_package() {
    package_root=$1
    package_name=$2
    for record in "$package_root/conda-meta/$package_name"-[0-9]*.json; do
        if [ -f "$record" ] && grep -Eq '"(url|channel)"[[:space:]]*:[[:space:]]*"((https://(conda\.anaconda\.org|prefix\.dev)/)?conda-forge)(["/])' "$record"; then
            return 0
        fi
    done
    return 1
}

is_miniforge_root() {
    [ -n "$1" ] || return 1
    root=$(CDPATH= cd -- "$1" 2>/dev/null && pwd -P) || return 1
    [ -x "$root/bin/python" ] && [ -x "$root/bin/conda" ] &&
        has_forge_package "$root" python && has_forge_package "$root" conda || return 1
    if [ -f "$root/.installer.info" ] && grep -Eq '"name"[[:space:]]*:' "$root/.installer.info"; then
        grep -Eiq '"name"[[:space:]]*:[[:space:]]*"Miniforge3?"' "$root/.installer.info"
        return
    fi
    if [ -f "$root/conda-meta/history" ] &&
        grep -Eiq '^# cmd: .*constructor .*[/ ]Miniforge3?[/ ]' "$root/conda-meta/history"; then
        return 0
    fi
    # Older Miniforge shell installers can lack the explicit installer marker.
    case "${root##*/}" in
        miniforge|miniforge3|Miniforge|Miniforge3) return 0 ;;
        *) return 1 ;;
    esac
}

select_miniforge_root() {
    if [ -n "${BLUEFOOD_MINIFORGE_ROOT:-}" ]; then
        if ! is_miniforge_root "$BLUEFOOD_MINIFORGE_ROOT"; then
            printf '%s\n' 'BLUEFOOD_MINIFORGE_ROOT must point to a Miniforge installation.' >&2
            return 1
        fi
        CDPATH= cd -- "$BLUEFOOD_MINIFORGE_ROOT" && pwd -P
        return
    fi

    case "${CONDA_EXE:-}" in
        */bin/conda) active_conda_root=${CONDA_EXE%/bin/conda} ;;
        *) active_conda_root='' ;;
    esac
    for candidate in "$active_conda_root" "${HOME:-}/miniforge3" "${HOME:-}/Miniforge3"; do
        if is_miniforge_root "$candidate"; then
            CDPATH= cd -- "$candidate" && pwd -P
            return
        fi
    done
    printf '%s\n' 'Install Miniforge, or set BLUEFOOD_MINIFORGE_ROOT to its installation directory.' >&2
    return 1
}

"""Validate Miniforge setup and the dedicated BlueFood Python interpreter."""

import json
import os
from pathlib import Path
import re
import shutil


PYTHON_VERSION = '3.9.19'
APPLICATION = 'BlueFood portable pipeline'
MARKER_NAME = 'BLUEFOOD_ENVIRONMENT.json'
WINDOWS_LOCKED_PYTHON_MD5 = 'b6999bc275e0e6beae7b1c8ea0be1e85'


def read_record(path):
    try:
        record = path and json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):
        return {}
    return record if isinstance(record, dict) else {}


def package_from_forge(prefix, package, version=None):
    for path in (prefix / 'conda-meta').glob(package + '-*.json'):
        record = read_record(path)
        from_channel = any(
            re.fullmatch(r'(?:https://(?:conda\.anaconda\.org|prefix\.dev)/)?conda-forge(?:/[^/]+)?/?',
                         str(record.get(key, ''))) for key in ('channel', 'schannel')
        )
        from_offline_lock = (os.name == 'nt' and package == 'python'
                             and record.get('md5') == WINDOWS_LOCKED_PYTHON_MD5)
        if (record.get('name') == package and (version is None or record.get('version') == version)
                and (from_channel or from_offline_lock)):
            return True
    return False


def prefix_python(prefix):
    return prefix / ('python.exe' if os.name == 'nt' else 'bin/python')


def prefix_conda(prefix):
    return prefix / ('Scripts/conda.exe' if os.name == 'nt' else 'bin/conda')


def is_miniforge(prefix):
    if not (prefix_conda(prefix).is_file() and prefix_python(prefix).is_file()
            and package_from_forge(prefix, 'conda') and package_from_forge(prefix, 'python')):
        return False
    installer = read_record(prefix / '.installer.info')
    name = str(installer.get('name', '')).lower()
    if name:
        return name in {'miniforge', 'miniforge3'}
    if (prefix / 'Uninstall-Miniforge3.exe').is_file():
        return True
    history = prefix / 'conda-meta/history'
    try:
        with history.open(encoding='utf-8', errors='replace') as stream:
            first_command = next((line for line in stream if line.startswith('# cmd:')), '')
    except OSError:
        return False
    return (prefix.name.lower() in {'miniforge', 'miniforge3'} or
            bool(re.search(r'\bconstructor\b.*\bminiforge3?\b', first_command, re.IGNORECASE)))


def expanded_path(value):
    return Path(os.path.expandvars(str(value))).expanduser()


def find_miniforge(explicit=None, configured=None):
    if explicit:
        path = expanded_path(explicit).resolve()
        root = path.parent.parent
        if path == prefix_conda(root).resolve() and is_miniforge(root):
            return root
        raise ValueError('Specify Scripts/conda.exe or bin/conda from an official Miniforge installation.')
    root_candidates = [os.environ.get('BLUEFOOD_MINIFORGE_ROOT'), configured]
    for command in (os.environ.get('CONDA_EXE'), shutil.which('conda')):
        if command:
            root_candidates.append(expanded_path(command).resolve().parent.parent)
    home = Path.home()
    root_candidates.extend(home / name for name in ('miniforge3', 'Miniforge3'))
    if os.name == 'nt':
        for variable in ('LOCALAPPDATA', 'ProgramData'):
            if os.environ.get(variable):
                root_candidates.append(Path(os.environ[variable]) / 'Miniforge3')
    for candidate in root_candidates:
        if candidate:
            prefix = expanded_path(candidate).resolve()
            if is_miniforge(prefix):
                return prefix
    raise FileNotFoundError('Install Miniforge or set BLUEFOOD_MINIFORGE_ROOT to its installation folder. Then run Setup Environment.')


def managed_python(path):
    python = Path(os.path.abspath(path))
    prefix = python.parent if os.name == 'nt' else python.parent.parent
    marker = read_record(prefix / MARKER_NAME)
    if (python != prefix_python(prefix) or not python.is_file() or
            marker.get('application') != APPLICATION or marker.get('python') != PYTHON_VERSION or
            marker.get('created_by') != 'bootstrap.py' or
            not (prefix / 'conda-meta/history').is_file() or
            not package_from_forge(prefix, 'python', PYTHON_VERSION)):
        raise ValueError('Run Setup Environment first, then select its dedicated Miniforge Python 3.9.19: ' + str(python))
    return python


def verify_launcher_host(executable):
    python = Path(os.path.abspath(executable))
    base = python.parent if os.name == 'nt' else python.parent.parent
    if python == prefix_python(base) and is_miniforge(base):
        return
    managed_python(python)

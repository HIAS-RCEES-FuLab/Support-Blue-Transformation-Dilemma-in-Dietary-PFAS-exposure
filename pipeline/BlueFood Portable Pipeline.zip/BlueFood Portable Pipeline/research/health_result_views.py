"""Display the direction of modeled 2020 effects across outcome cohorts."""

import json
from pathlib import Path

import numpy as np


def population_shift_rows(summary, outcome_info, outcomes):
    fields = ["fraction_increase", "fraction_decrease", "fraction_unchanged"]
    world = summary[(summary["region"] == "World") & (summary["scenario"] == "2020_trade")]
    means = world.groupby("outcome")[fields].mean()
    if set(outcomes) != set(means.index):
        raise ValueError("The direction plot requires world results for all 36 outcomes.")
    np.testing.assert_allclose(means.sum(axis=1), 1, atol=1e-10, rtol=0)
    return [
        {
            "code": code,
            "name": outcome_info[code]["display_name"],
            "description": outcome_info[code]["description"],
            "unit": outcome_info[code]["unit"],
            "shares": [float(value) for value in means.loc[code, fields]],
        }
        for code in outcomes
    ]


def write_population_shift(out, summary, outcome_info, outcomes):
    rows = population_shift_rows(summary, outcome_info, outcomes)
    template = Path(__file__).with_name("assets") / "results_visuals" / "health_population_shift.template.html"
    data = json.dumps(rows, ensure_ascii=True, allow_nan=False).replace("<", "\\u003c")
    path = Path(out) / "health_population_shift.html"
    path.write_text(template.read_text(encoding="utf-8").replace("__SHIFT_DATA__", data), encoding="utf-8")

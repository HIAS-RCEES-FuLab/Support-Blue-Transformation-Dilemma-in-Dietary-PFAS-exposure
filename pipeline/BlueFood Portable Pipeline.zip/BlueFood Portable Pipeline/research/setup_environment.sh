#!/usr/bin/env sh
set -eu
pipeline_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
. "$pipeline_dir/miniforge_posix.sh"

# Accept the documented --conda argument only when it names Miniforge.
conda_path=''
read_conda=0
for arg do
    if [ "$read_conda" -eq 1 ]; then
        conda_path=$arg
        read_conda=0
    else
        case "$arg" in
            --conda) read_conda=1 ;;
            --conda=*) conda_path=${arg#--conda=} ;;
            --) break ;;
        esac
    fi
done
if [ "$read_conda" -eq 1 ]; then
    printf '%s\n' 'Give the full Miniforge bin/conda path after --conda.' >&2
    exit 1
fi
if [ -n "$conda_path" ]; then
    case "$conda_path" in
        */bin/conda) BLUEFOOD_MINIFORGE_ROOT=${conda_path%/bin/conda} ;;
        *) printf '%s\n' 'Use Miniforge bin/conda with --conda.' >&2; exit 1 ;;
    esac
fi
miniforge_root=$(select_miniforge_root)
unset PYTHONPATH PYTHONHOME
export BLUEFOOD_MINIFORGE_ROOT="$miniforge_root" PYTHONNOUSERSITE=1
exec "$miniforge_root/bin/python" "$pipeline_dir/bootstrap.py" --conda "$miniforge_root/bin/conda" "$@"

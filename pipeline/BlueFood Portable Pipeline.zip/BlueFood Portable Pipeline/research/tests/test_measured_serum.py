"""Check revised Data 3 schemas and retain mass-based serum measurements."""
from pathlib import Path
import sys
import unittest
from unittest.mock import MagicMock,patch
import pandas as pd

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import calculations

class MeasuredSerum(unittest.TestCase):
 def read(self,sheet,value_column,matrices=('Serum','Serum (ng/g)')):
  frame=pd.DataFrame({'Region/Country':['China','Italy'],'Analyte':['PFOS','PFOA'],
   'Metric':['Mean','Median'],'Years':['2020','2015-2016'],'Cohort Type':['Adults','Adults'],
   'Matrix':list(matrices),'Reference (link)':['reference-a','reference-b'],value_column:[2.,1.64]})
  book=MagicMock();book.__enter__.return_value.sheet_names=[sheet]
  with patch.object(calculations.pd,'ExcelFile',return_value=book),patch.object(calculations.pd,'read_excel',return_value=frame) as reader:
   result=calculations.measured_serum('not-opened.xlsx')
   self.assertEqual(reader.call_args.kwargs['sheet_name'],sheet)
  return result

 def test_updated_schema_keeps_mass_units_separate(self):
  data=self.read('reviewed measures','Value (ng/mL unless noted)')
  self.assertEqual(data.loc[0,'measured_ng_ml'],2.)
  self.assertEqual(data.loc[1,'reported_value'],1.64)
  self.assertEqual(data.loc[1,'reported_unit'],'ng/g')
  self.assertTrue(pd.isna(data.loc[1,'measured_ng_ml']))

 def test_legacy_schema_is_still_supported(self):
  data=self.read('reviewed meansures','Value (ng/mL)',('Serum','Plasma'))
  self.assertEqual(data.measured_ng_ml.tolist(),[2.,1.64])

 def test_other_explicit_units_are_not_assumed_ng_per_ml(self):
  data=self.read('reviewed measures','Value (ng/mL unless noted)',('Serum (pg/mL)','Serum (ng / g)'))
  self.assertTrue(data.measured_ng_ml.isna().all())
  self.assertEqual(data.reported_unit.tolist(),['pg/mL','ng/g'])

 def test_unknown_sheet_is_rejected(self):
  book=MagicMock();book.__enter__.return_value.sheet_names=['readme']
  with patch.object(calculations.pd,'ExcelFile',return_value=book):
   with self.assertRaisesRegex(ValueError,'reviewed measurements sheet'):
    calculations.measured_serum('not-opened.xlsx')

if __name__=='__main__':unittest.main()

import unittest

import numpy as np
import pandas as pd

from serum_comparison import COMBINED, SUM4, comparison_rows, period_distance, pick_country_points


def measurement(chemical, value, *, metric='Mean', period='2018', cohort='Adults',
                reference='Study A', unit='ng/mL'):
    return {'Region/Country': 'Netherland', 'Analyte': chemical, 'Metric': metric,
            'Years': period, 'Cohort Type': cohort, 'Matrix': 'Serum',
            'Reference (link)': reference, 'reported_unit': unit,
            'measured_ng_ml': value if unit == 'ng/mL' else np.nan,
            'reported_value': value}


class SerumComparison(unittest.TestCase):
    def setUp(self):
        self.predictions = pd.DataFrame([
            ('Netherlands', 'PFOA', 1, 1., .8, .6),
            ('Netherlands', 'PFOS', 1, 6., 5., 3.),
            ('Netherlands', 'PFOA', 2, 3., 1.2, 1.0),
            ('Netherlands', 'PFOS', 2, 10., 7., 5.),
            ('Netherlands', 'PFOA', 3, 26., 1., .8),
        ], columns=['country', 'chemical', 'replicate', 'mean', 'median', 'geometric_mean'])

    def test_all_individual_studies_and_same_replicate_combined_means(self):
        rows = comparison_rows(pd.DataFrame([
            measurement('PFOA', .3), measurement('PFOS', 5.),
            measurement('PFOA', 3., period='2020', metric='Median'),
            measurement('PFOA', 1., period='2021', metric='Geometric mean'),
            measurement('PFNA', .2),
        ]), self.predictions)
        self.assertEqual(rows.chemical.tolist(), ['PFOA', 'PFOS', 'PFOA', 'PFOA', COMBINED])
        np.testing.assert_allclose(rows.predicted_2020_ng_ml.iloc[:4], [10., 8., 1., .8])
        self.assertEqual(rows.iloc[-1].measured_ng_ml, 5.3)
        self.assertEqual(rows.iloc[-1].predicted_2020_ng_ml, 10.)

    def test_metric_subgroup_year_study_and_units_must_match(self):
        rows = comparison_rows(pd.DataFrame([
            measurement('PFOA', 1.), measurement('PFOS', 3., metric='Median'),
            measurement('PFOS', 4., cohort='Children'),
            measurement('PFOS', 5., reference='Study B'),
            measurement('PFOS', 6., period='2019'),
            measurement('PFOS', 7., unit='ng/g'),
            measurement('Sum_2', 7.),
        ]), self.predictions)
        self.assertEqual(len(rows), 6)
        self.assertNotIn(COMBINED, rows.chemical.tolist())
        self.assertEqual(rows.iloc[-1].status, 'unit_conversion_required')

    def test_conflicting_arithmetic_means_are_kept_without_guessing_pair(self):
        rows = comparison_rows(pd.DataFrame([
            measurement('PFOA', 1.), measurement('PFOA', 2.), measurement('PFOS', 3.),
        ]), self.predictions)
        self.assertEqual(rows.measured_ng_ml.tolist(), [1., 2., 3.])

    def test_medians_and_geometric_means_use_the_corresponding_model_statistics(self):
        rows = comparison_rows(pd.DataFrame([
            measurement('PFOA', 1., metric='Median'), measurement('PFOS', 2., metric='median'),
            measurement('PFOA', 5., metric='Geometric mean'), measurement('PFOS', 7., metric='gmean'),
        ]), self.predictions)
        summed = rows[rows.chemical == COMBINED].set_index('statistic')
        self.assertEqual(summed['measured_ng_ml'].to_dict(), {'median': 3., 'geometric_mean': 12.})
        self.assertAlmostEqual(summed.at['median', 'predicted_2020_ng_ml'], 7.)
        self.assertAlmostEqual(summed.at['geometric_mean', 'predicted_2020_ng_ml'], 4.8)

    def test_different_subgroups_or_reports_are_not_added(self):
        for mismatched in (measurement('PFOS', 3., metric='female gmean'),
                           measurement('PFOS', 3., metric='male gmean', reference='Study B'),
                           measurement('PFOS', 3., metric='male median')):
            records = [measurement('PFOA', 1., metric='male gmean'), mismatched]
            self.assertNotIn(COMBINED, comparison_rows(pd.DataFrame(records), self.predictions).chemical.tolist())

    def test_missing_link_resolves_from_same_exact_title_when_unambiguous(self):
        named = {'Reference (title)': 'Named serum report'}
        records = [dict(measurement('PFOA', 1., reference=''), **named),
                   dict(measurement('PFOS', 3., reference='Link A'), **named)]
        combined = comparison_rows(pd.DataFrame(records), self.predictions)
        self.assertEqual(combined.iloc[-1].reference, 'Link A')
        records.append(dict(measurement('PFOS', 3., reference='Link B'), **named))
        self.assertNotIn(COMBINED, comparison_rows(pd.DataFrame(records), self.predictions).chemical.tolist())

    def test_four_compound_means_use_the_same_cohort_and_complete_model_replicate(self):
        extra = pd.DataFrame([
            ('Netherlands', 'PFHxS', 1, 4., 4., 4.),
            ('Netherlands', 'PFNA', 1, 2., 2., 2.),
            ('Netherlands', 'PFHxS', 2, 50., 50., 50.),
        ], columns=self.predictions.columns)
        predicted = pd.concat([self.predictions, extra])
        records = [measurement('PFOA', 1.), measurement('PFOS', 2.),
                   measurement('pfhxs', 3.), measurement('PFNA', 4., cohort='Children')]
        self.assertNotIn(SUM4, comparison_rows(pd.DataFrame(records), predicted).chemical.tolist())
        records.append(measurement('PFNA', 5.))
        selected = pick_country_points(comparison_rows(pd.DataFrame(records), predicted))
        four = selected[selected.chemical == SUM4].iloc[0]
        self.assertEqual(four.measured_ng_ml, 11.)
        self.assertEqual(four.predicted_2020_ng_ml, 13.)

    def test_country_deduplication_uses_year_and_metric_not_numeric_agreement(self):
        selected = pick_country_points(comparison_rows(pd.DataFrame([
            measurement('PFOS', 8., period='2015'),
            measurement('PFOS', 28., period='2019–21', metric='Median'),
            measurement('PFOS', 25., period='2019-2021', metric='Mean'),
        ]), self.predictions))
        self.assertEqual(len(selected), 1)
        self.assertEqual(selected.measured_ng_ml.iloc[0], 25.)
        self.assertEqual(period_distance('2019–21'), 0)
        self.assertEqual(period_distance('2018'), 2)


if __name__ == '__main__':
    unittest.main()

"""Population-contract and stale-cache checks without running the PBK solver."""
from pathlib import Path
import csv
import importlib
import json
import os
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

class PBKPopulation(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.workspace=tempfile.TemporaryDirectory(prefix='BlueFood PBK workspace ')
  cls.environment=patch.dict(os.environ,{'BLUEFOOD_WORKSPACE':cls.workspace.name})
  cls.environment.start()
  cls.common=importlib.import_module('common')
  cls.app=importlib.import_module('app')

 @classmethod
 def tearDownClass(cls):
  cls.environment.stop();cls.workspace.cleanup()

 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(prefix='BlueFood PBK results ')
  self.out=Path(self.temp.name);self.results=self.out/'R_job/results'
  self.results.mkdir(parents=True)
  self.rows=[{'compound':c,'scenario':s,'period':f'{y}-{y+1}','n':100000}
   for c in ('PFOA','PFOS')
   for s in ('no_exposure','aquatic_only','terrestrial_only','aquatic_plus_terrestrial')
   for y in range(2003,2016,2)]
  self.settings={'population_n':{'PFOA':100000,'PFOS':100000}}
  self.write_results()
  (self.out/'COMPLETE.json').write_text('{}')

 def tearDown(self):self.temp.cleanup()

 def write_csv(self,path,rows):
  with path.open('w',newline='',encoding='utf-8') as handle:
   writer=csv.DictWriter(handle,fieldnames=['compound','scenario','period','n'])
   writer.writeheader();writer.writerows(rows)

 def write_results(self):
  (self.results/'settings.json').write_text(json.dumps(self.settings))
  for compound in ('PFOA','PFOS'):
   folder=self.results/compound;folder.mkdir(exist_ok=True)
   (folder/'settings.json').write_text(json.dumps({'n':self.settings['population_n'][compound]}))
  self.write_csv(self.results/'period_results.csv',self.rows)
  self.write_csv(self.out/'PFOA_PFOS_period_results.csv',self.rows)

 def test_accepts_both_fixed_100000_populations(self):
  check=self.common.validate_pbk_population(self.out)
  self.assertEqual(check,{'population_n':{'PFOA':100000,'PFOS':100000},'period_rows':56})

 def test_rejects_old_10000_person_pfos_results(self):
  self.settings['population_n']['PFOS']=10000
  for row in self.rows:
   if row['compound']=='PFOS':row['n']=10000
  self.write_results()
  with self.assertRaisesRegex(ValueError,'100,000'):self.common.validate_pbk_population(self.out)

 def test_rejects_one_incorrect_count_in_either_summary(self):
  self.rows[-1]['n']=10000
  for path in (self.results/'period_results.csv',self.out/'PFOA_PFOS_period_results.csv'):
   with self.subTest(path=path.name):
    self.write_csv(path,self.rows)
    with self.assertRaisesRegex(ValueError,'100,000'):self.common.validate_pbk_population(self.out)
    self.write_csv(path,[dict(row,n=100000) for row in self.rows])

 def test_rejects_missing_or_duplicate_scenario_period(self):
  for rows in (self.rows[:-1],self.rows[:-1]+[self.rows[0]]):
   with self.subTest(rows=len(rows)):
    self.write_csv(self.results/'period_results.csv',rows)
    with self.assertRaisesRegex(ValueError,'incomplete'):self.common.validate_pbk_population(self.out)

 def test_rejects_missing_population_metadata(self):
  for path in (self.results/'settings.json',self.results/'PFOS/settings.json'):
   with self.subTest(path=str(path)):
    original=path.read_text();path.write_text('{}')
    with self.assertRaises(ValueError):self.common.validate_pbk_population(self.out)
    path.write_text(original)

 def test_rejects_missing_or_invalid_summary_count(self):
  for value in (None,'NaN',100001):
   with self.subTest(value=value):
    self.rows[-1]['n']=value;self.write_csv(self.results/'period_results.csv',self.rows)
    with self.assertRaisesRegex(ValueError,'100,000'):self.common.validate_pbk_population(self.out)

 def test_cache_reuses_only_valid_population_results(self):
  app=self.app
  record={'out':str(self.out),'fingerprint':'same','run_id':'cached_pbk'}
  with patch.dict(app.STAGES,{'us_pbk':{'deps':[]}}),patch.object(app,'fingerprint',return_value='same'),patch.object(app,'latest',return_value={'us_pbk':record}),patch.object(app.shutil,'disk_usage',side_effect=RuntimeError('would start new run')):
   self.assertEqual(app.run_one('us_pbk',{'repeats':1}),record)
   self.rows[-1]['n']=10000;self.write_results()
   with self.assertRaisesRegex(RuntimeError,'would start new run'):
    app.run_one('us_pbk',{'repeats':1})

if __name__=='__main__':unittest.main(verbosity=2)

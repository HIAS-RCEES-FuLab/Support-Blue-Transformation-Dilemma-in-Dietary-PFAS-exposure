"""Meaningful portability/IO checks; no full simulations or network installs."""
from pathlib import Path
import importlib
import io
import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

class Portability(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(prefix='BlueFood paths 空间 ')
  self.folder=Path(self.temp.name)

 def tearDown(self):self.temp.cleanup()

 def run_python(self,code,extra=None):
  env=os.environ.copy()
  for name in list(env):
   if name.startswith('BLUEFOOD_'):env.pop(name)
  env.update(PYTHONPATH=str(ROOT),PYTHONUTF8='1')
  env.update(extra or {})
  reply=subprocess.run([sys.executable,'-c',code],cwd=self.folder,env=env,capture_output=True,text=True)
  self.assertEqual(reply.returncode,0,reply.stderr)
  return reply

 def test_configuration_from_unrelated_working_directory(self):
  config=self.folder/'custom config.json'
  config.write_text(json.dumps({'workspace':str(self.folder/'separate results'),'port':0,'max_workers':1}),encoding='utf-8')
  reply=self.run_python("import common,json;print(json.dumps({'workspace':str(common.WORKSPACE),'assets':str(common.ASSETS),'workers':common.options()['workers']}))",{'BLUEFOOD_CONFIG':str(config)})
  data=json.loads(reply.stdout)
  self.assertEqual(data['workspace'],str(self.folder/'separate results'))
  self.assertEqual(Path(data['assets']),ROOT/'assets')
  self.assertEqual(data['workers'],1)

 def test_archives_are_idempotent_and_cannot_escape(self):
  archive=self.folder/'input.zip';outside=self.folder/'escape.txt'
  with zipfile.ZipFile(archive,'w') as z:z.writestr('nested/inputs.csv','a,b\n1,2\n')
  code="from common import extract_zip;import json;print(json.dumps([extract_zip(r'%s',r'%s'),extract_zip(r'%s',r'%s')]))"%(archive,self.folder/'unpacked',archive,self.folder/'unpacked')
  results=json.loads(self.run_python(code,{'BLUEFOOD_WORKSPACE':str(self.folder/'work')}).stdout)
  self.assertEqual(results[0]['extracted'],1);self.assertEqual(results[1]['already_extracted'],1)
  with zipfile.ZipFile(archive,'w') as z:z.writestr('../escape.txt','outside')
  code="from common import extract_zip\ntry:extract_zip(r'%s',r'%s')\nexcept ValueError:print('rejected')"%(archive,self.folder/'unpacked')
  self.assertIn('rejected',self.run_python(code,{'BLUEFOOD_WORKSPACE':str(self.folder/'work')}).stdout)
  self.assertFalse(outside.exists())
  with zipfile.ZipFile(archive,'w') as z:z.writestr('nested/inputs.csv','changed')
  code="from common import extract_zip\ntry:extract_zip(r'%s',r'%s')\nexcept FileExistsError:print('preserved')"%(archive,self.folder/'unpacked')
  self.assertIn('preserved',self.run_python(code,{'BLUEFOOD_WORKSPACE':str(self.folder/'work')}).stdout)
  self.assertEqual((self.folder/'unpacked/nested/inputs.csv').read_text(),'a,b\n1,2\n')

 def test_http_results_and_relocated_index(self):
  # Import in a child so each test has an independent configuration and token.
  script='''
from pathlib import Path
import app,json,threading,urllib.request,urllib.error
from common import *
folder=RUNS/'saved_run';folder.mkdir()
(folder/'example.csv').write_bytes(b'mean\\n1.23\\n')
write_json(app.INDEX,{'diets':{'run_id':'saved_run','out':'Z:/old installation/runs/saved_run','fingerprint':'test'}})
server=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
url='http://127.0.0.1:'+str(server.server_address[1])
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def get(path):
 with opener.open(url+path) as r:return r.read()
try:
 state=json.loads(get('/api/state'));assert len(state['stages'])==8
 assert Path(state['latest']['diets']['out'])==folder
 html=get('/').decode();assert '__TOKEN__' not in html and 'Local workspace' in html
 files=json.loads(get('/api/files?stage=diets'));assert files['files'][0]['name']=='example.csv'
 assert get(files['files'][0]['url'])==b'mean\\n1.23\\n'
 for path in ['/results/../ASSET_MANIFEST.json','/results/%2e%2e/ASSET_MANIFEST.json']:
  try:get(path);raise AssertionError('path escape allowed')
  except urllib.error.HTTPError as e:assert e.code==404
 request=urllib.request.Request(url+'/api/run',data=b'{"stage":"prepare"}',headers={'Content-Type':'application/json'})
 try:opener.open(request);raise AssertionError('token missing')
 except urllib.error.HTTPError as e:assert e.code==403
 print(json.dumps({'stages':len(state['stages']),'rebased_results':True,'token_required':True,'path_escape_rejected':True}))
finally:server.shutdown();server.server_close();thread.join()
'''
  reply=self.run_python(script,{'BLUEFOOD_WORKSPACE':str(self.folder/'work')})
  self.assertEqual(json.loads(reply.stdout)['stages'],8)

 def test_setup_preserves_unrelated_existing_environment(self):
  env_folder=self.folder/'existing environment';env_folder.mkdir();sentinel=env_folder/'keep.txt';sentinel.write_text('preserve')
  result=subprocess.run([sys.executable,str(ROOT/'bootstrap.py'),'--conda',str(Path(sys.executable)),'--prefix',str(env_folder),'--dry-run'],capture_output=True,text=True)
  self.assertNotEqual(result.returncode,0);self.assertIn('unrelated files',result.stderr)
  self.assertEqual(sentinel.read_text(),'preserve')

 def test_launcher_avoids_other_servers_and_reuses_its_own(self):
  script='''
import http.server,json,os,signal,subprocess,sys,threading
from pathlib import Path
from common import *
class Other(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  self.send_response(200);self.end_headers();self.wfile.write(b'{"service":"bluefood-pipeline","instance_id":"other installation"}')
other=http.server.ThreadingHTTPServer(('127.0.0.1',0),Other)
thread=threading.Thread(target=other.serve_forever,daemon=True);thread.start()
command=[sys.executable,str(ROOT/'launch.py'),'--python',sys.executable,'--no-browser','--port',str(other.server_address[1])]
pid=None
try:
 first=subprocess.run(command,check=True,capture_output=True,text=True)
 record=read_json(STATE/'server.json');pid=record['pid']
 assert record['port']!=other.server_address[1]
 second=subprocess.run(command,check=True,capture_output=True,text=True)
 assert read_json(STATE/'server.json')['pid']==pid
 assert first.stdout==second.stdout
 stopped=subprocess.run(command+['--stop'],check=True,capture_output=True,text=True)
 assert 'Pipeline closed' in stopped.stdout
 pid=None
 print('correct installation reused; conflicting port avoided')
finally:
 if pid:os.kill(pid,signal.SIGTERM)
 other.shutdown();other.server_close();thread.join()
'''
  reply=self.run_python(script,{'BLUEFOOD_WORKSPACE':str(self.folder/'work')})
  self.assertIn('conflicting port avoided',reply.stdout)

if __name__=='__main__':unittest.main(verbosity=2)

BlueFood portable pipeline

Illustrated guide for Windows 64 bit

Release 10 November 2026

This guide explains how to install the BlueFood portable pipeline, run its eight workflows, and save the data and figures. It covers global scenarios and historical United States (US) exposure and physiologically based kinetic (PBK) serum calculations. Red frames and numbered markers identify where to click or enter a setting; the annotations remain editable in Word.

Quick start

1. Extract the outer ZIP once. Keep the three launchers, README.docx and research folder together in a writable location. All bundled inputs are ready to use; no other extraction is needed.

2. Install Miniforge for your user account. Choose Windows x86_64 on the official Miniforge download page (https://conda-forge.org/download/).

3. Run Setup Environment.cmd. Wait for setup to finish. Miniforge creates the dedicated Python 3.9.19 and R environment. Online setup needs internet access.

4. Run Start Pipeline.cmd. The local calculation interface opens in your browser.

5. Check Environment & data. Begin with 1 repeat and 1 worker on a computer with 8 GiB RAM. After verification, choose the calculation you need.

6. Save the results. Use the CSV/PDF links and retain each run folder, including its request, log and completion record.

Before you begin

Requirement | Recommended starting point

Operating system | Windows 64-bit; this is the exercised platform for this release.

Memory and disk | 8 GiB RAM; at least 12 GiB free for setup and an initial workflow. Reserve 50 GiB or more for extensive seven-repeat exposure runs.

Hardware and access | CPU

Internet | Needed for initial dependency installation. Scientific input assets are included in the portable source bundle.

Guide contents: installation (#install_environment); launch (#launch_pipeline); calculation settings (#calculation_settings); workflow outputs (#workflow_outputs); scientific settings (#scientific_settings); health outcomes and sources (#health_outcomes); folders (#project_folders); advanced setup (#advanced_setup); dependencies (#dependency_versions); troubleshooting (#troubleshooting). Click a section name to jump to its instructions.

Install the environment

1. Extract the archive. Right-click the outer portable ZIP in File Explorer and choose Extract All. Select a writable location and keep research with the three launchers and README.docx. Spaces and non-English folder names are supported. All bundled inputs are already prepared.

2. Download Miniforge. Open the official download page (https://conda-forge.org/download/) and select Windows x86_64. Run the installer, choose installation for your current user, and complete its prompts. The pipeline uses its own Python environment.

Official Miniforge download page (https://conda-forge.org/download/)

Setup checks that the dedicated Python 3.9.19 executable is present and can load a CA bundle. Conda, pip and R package downloads verify HTTPS certificates using that bundle. If your organization inspects HTTPS, use a trusted PEM bundle that includes its CA. In PowerShell, run `& '.\research\Setup Environment.ps1' -CABundle 'C:\path\trusted-ca.pem'` or set BLUEFOOD_CA_BUNDLE. Add -CheckOnline to test HTTPS to conda-forge, PyPI and CRAN. The ordinary Environment & data check also validates the bundle and R’s HTTPS capability without contacting those sites.

If the dedicated python.exe is empty or damaged, rerun Setup Environment to repair the Miniforge environment. The executable needs its matching packages and libraries.

Figure 1. Choose the Windows x86_64 installer on the official conda-forge page.

1  Click the Windows x86_64 tile. The release number can change; the pipeline setup still selects the versions recorded in its lock files.

3. Double-click Setup Environment.cmd. Leave the setup window open while Miniforge installs Python, R and the required packages. Continue only after the message “Setup complete. Run Start Pipeline.cmd”.

Miniforge installs Python 3.9.19 and R 4.5.2 in a dedicated per-user environment. CPU-only PyTorch is used. The default short BlueFood/environments path avoids Windows filename limits in deeply nested source folders.

If setup cannot find Miniforge, follow Specify a Miniforge installation or environment location (#advanced_conda). Run setup to install the required interpreter and R packages.

Launch the calculation window

Open the extracted folder. It contains three .cmd launchers, README.docx and research. Windows may hide filename extensions, so a launcher may appear without .cmd, as in this screenshot.

Figure 2. The three Windows launchers in File Explorer.

1  Run Setup Environment.cmd once on a new computer.

2  Run Start Pipeline.cmd whenever you want to open the pipeline.

3  Use Stop Pipeline.cmd when you want to close the application server.

Start Pipeline opens a local address such as http://127.0.0.1:8765/. The port can differ if another application already uses it. Start Pipeline, Stop Pipeline and all calculations use the Python 3.9.19 interpreter created during Miniforge setup. The launcher only reuses the server belonging to this installation and workspace.

Figure 3. The eight-workflow calculation window.

1  Start with Environment & data, or select another calculation and let its prerequisites run automatically.

2  Run full workflow submits all eight stages in their dependency order.

Choose calculation settings

Expand Calculation settings below the workflow cards before starting a calculation. Choose the number of repeats and workers. Saved results retain the settings used when they were calculated.

Figure 4. Settings below the workflow cards.

1  Repeats: choose 1 for an initial calculation, or 7 to measure variation between repeated exposure simulations.

2  Workers: choose how many calculation tasks the computer may run at the same time. Start with 1 on an 8 GiB computer.

What is a worker

A worker is one calculation task running on the computer. More workers can finish independent tasks sooner, but they also use more memory. Start with one worker. Increase the number only when the computer has enough memory and remains responsive; the program limits it to the available capacity.

What is a repeat

A repeat reruns an exposure simulation with a different seed, so results can vary. Keep the run records for comparisons.

The PBK stage uses the first US historical exposure repeat and samples its own virtual population. Choosing seven exposure repeats does not create seven separate PBK fits.

Verify the first calculation

Click Environment & data and wait for the Completed badge. This checks the scientific Python stack, R, PBK packages and the input files before the later workflows start.

Figure 5. A successful environment and data check.

1  “Environment ready” confirms that the stage completed.

2  The preview lists the source-file and software checks. The detailed verification record is saved with the run.

Figure 6. Download the verification plot and inspect the calculation log.

1  Click environment.pdf to open or save the plot. The detailed environment.json remains in the run folder.

2  Expand Calculation log. This successful example ends with “Environment and data checks passed” and “Calculation complete”.

If a stage fails, inspect the error and run.log before starting it again. Each run has a request and either COMPLETE.json or FAILED.json. A plot alone is not the completion record.

Viewing and stopping workflows

To view a saved result without starting a calculation, right-click its workflow card. A normal left-click runs that workflow again. Its prerequisite calculations reuse compatible completed results automatically.

During a running calculation, Stop appears beside the progress area and cancels the current job and its child processes. Stop Pipeline.cmd also closes the local application server. Closing only the browser tab is not the same as shutting down that server.

View and save calculation results

When a workflow completes, its plot appears in the Results panel. The diet screenshot below was produced through the current portable interface. Each workflow saves its own named CSV/PDF outputs in the workspace.

Figure 7. Completed diet results and their download controls.

1  View saved results display the currently selected stage’s latest saved result.

2  Use the plot tabs to switch between figures when a workflow produces several plots.

3  Click a CSV filename for numeric data or a PDF filename for the corresponding figure.

4  Expand Calculation log to see progress messages and any diagnostic details.

Workflow outputs for US and 2020 analyses

Choose a workflow by its name in the interface. The adapters inside research connect the original scientific programs to portable input paths. Start calculations through the interface rather than running archival scripts directly.

Environment and data

Entry: Environment & data. Adapter: calculations.py, prepare. Checks the installed packages and scientific input hashes. The bundled inputs are ready to use; additional ZIP files placed in research/workspace/imports are opened by this workflow.

environment.json
environment.png  |  environment.pdf

US historical EDI

Entry: US historical EDI. Adapter: calculations.py, us_stage, with run_us_exposure.py and aquatic_time_trends.xlsx. Calculates 2003–2016 intake using PFAS in food data and built-in aquatic time windows. Terrestrial samples use all available years and k = 1. Sampling uses 100 diet draws × 1,000 concentration draws. EDI is reported at 62 kg body weight.

US_EDI.csv  |  US_Sum7.csv
difference_from_historical_by_year.csv
US_EDI.png  |  US_EDI.pdf  |  annual NPZ arrays

The comparisons include compound geometric means and the annual mean, median and range of percentage differences from the historical reference. The annual EDI chart lists the US compound-specific CVs (SD divided by mean) from the seven independent 2020 Trade runs as a reference for uncertainty. The additional plots show source contributions to EDI, EDI and measured-serum composition, and the EDI–serum fit across NHANES cycles.

PBK for US PFOA and PFOS serum

Entry: PBK for US PFOA & PFOS serum. Adapters: calculations.py, pbk_stage; r_runner.R; original Fabrega R PBK model. Reads absolute daily intakes from US historical EDI, fits the 2003–2004 initial serum state, and compares no exposure, aquatic only, terrestrial only, and both food branches. Later NHANES measurements provide comparison data.

PBK implementation adapted from the original R validation script (https://github.com/ntua-unit-of-control-and-informatics/PFAS_PBK_models/blob/main/Fabrega%20et%20al.2015/PFAS_PBK_validation_Fabrega_2015.R) in the PFAS_PBK_models repository. From 2005 onward, the model applies the food bioavailability fractions and the historical compound-specific dose multipliers to the aquatic and terrestrial food branches. Rerun the PBK card to regenerate earlier saved plots with these settings.

Model reference: Fàbrega, F., Kumar, V., Benfenati, E., Schuhmacher, M., Domingo, J. L., and Nadal, M. (2015). Physiologically based pharmacokinetic modeling of perfluoroalkyl substances in the human body (https://doi.org/10.1080/02772248.2015.1060976). Toxicological & Environmental Chemistry, 97(6), 814–827.

PFOA_PFOS_period_results.csv  |  US_PBK_R.png/.pdf
R_job/results/period_results.csv
R_job/results/settings.json
The serum-source tab partitions PFOA + PFOS into the residual, aquatic-food and terrestrial-food shares from the four PBK runs (SI Fig. 5).

2020 exposure and HI

Entry: 2020 exposure & HI. Adapter: calculations.py, global_stage. Combines PFAS in food data, the 2020 diet and the supply matrices for Trade and no-trade. Saves individual EDI distributions at 62 kg body weight. HI is calculated for each country before population-weighted regional and world averages.

statistics.csv  |  individual_manifest.json  |  method.json
EDI_HI.png  |  EDI_HI.pdf
The map tabs show 2020 Trade HI and the change from No trade to Trade. The fish consumption tab shows the country geometric mean EDI, individual 25th–75th percentiles and a linear fit.

Workflow outputs for health diets and 2050

2020 health outcomes

Entry: 2020 health outcomes. Adapters: calculations.py, serum_stage; health.py. Uses curves obtained by regressing geometric means of intake against NHANES measured serum concentrations. The Serum vs measured tab shows PFOA, PFOS, PFOA + PFOS and the four-compound sum of PFOS, PFOA, PFHxS and PFNA using research/assets/health/data/Measured_serum.xlsx. Combined points sum matched compound means, medians or geometric means on each axis. Measured components come from the same country, report, cohort, subgroup, sampling period and sample type. A sum of compound medians or geometric means is a different statistic from a median or geometric mean of individual totals. Each series shows one point per country using the eligible record with sampling-period midpoint closest to 2020. Ties favor an arithmetic mean, geometric mean, then median, with study metadata used to resolve remaining ties. Predicts 34 health indicators and two disease outcomes, listed with descriptions and NHANES links in Health outcomes and data sources (#health_outcomes). The indicator dataset contains 9,026 records before cleaning and 7,618 afterward. The two disease outcomes use their prepared questionnaire datasets. The 2020 Health outcomes tab lists population-weighted mean differences from the near-zero serum reference, the direction of the mean difference, and the percentage of the modeled population with a change in that direction when available.

country_serum_concentrations.csv  |  regional_world_serum.csv
predicted_vs_measured_serum.csv
The workbook lists the Canadian 2018–2019 PFNA value of 0.44 under adults. Health Canada's report gives it for a broader age group, so Canada's four-compound point uses the 12–19-year cohort. The Swedish maternal study reports serum concentrations in ng/g and requires unit conversion before comparison. Sources are https://www.canada.ca/en/health-canada/services/environmental-workplace-health/reports-publications/environmental-contaminants/sixth-report-human-biomonitoring/page-3.html and https://doi.org/10.1016/j.envint.2025.109671.
country_health_outcomes.csv
regional_world_health_outcomes.csv
The Population shift tab shows modeled increase and decrease shares for 34 health indicators and two disease outcomes. Use the scrollbar on the right to see all 36. Hover over or focus a row to see the description and shares. The markers identify shares above 90% and 95% in one direction.

2050 diet pathways

The 2050 diet pathways workflow compares the 2020 diet, LR diet, BAU diet and HR diet. It exports diet composition, edible weights and population-weighted summaries.

country_diets.csv  |  country_food_composition.csv
population_weighted_diets.csv  |  diet_composition.png/.pdf
The Diet and trade map tab shows one map at a time. Use the Year and pathway selector above the map to choose 2020, LR, BAU or HR. Choose aquatic or terrestrial food and, for 2050, select Trade or Metatrade. The 2020 map uses the baseline Trade matrix. Hover over a country to see the five largest foreign suppliers and the domestic share. Click a country to keep it selected when changing scenarios.

2050 exposure and health

Entry: 2050 exposure & health. Adapters: global_stage and serum_stage in calculations.py; health.py. Uses PFAS in food data and the LR, BAU and HR diets. Trade uses the 2020 supply matrix. Metatrade uses the 2030-derived matrix. The Health outcomes tab shows how much higher or lower the modeled PFAS-attributable effect is in each 2050 scenario relative to 2020 Trade. Bars show the paired change divided by the magnitude of the 2020 Trade effect versus near-zero serum, expressed as a percentage. Both effects use the same 2050 population weights and NHANES covariates. A zero baseline is shown as N/A. The companion CSV gives each baseline, paired difference and percentage.

statistics.csv  |  EDI_HI.png/.pdf  |  future_serum.png/.pdf
country and regional/world serum and health outputs
health_outcome_percentage_changes.csv

These files identify the generating workflow for each analysis component. Keep the run request, input hashes and scientific settings with any tables or figures selected for a manuscript.

CO2 emissions and intensity

Entry: CO₂ emissions & intensity. Adapter: calculations.py, co2_stage. Reweights the archived Figure 4a emissions and edible-food estimates for 2020, LR, BAU and HR. Outputs distinguish g CO₂eq/person/day, kg/person/year, global Mt/year, and g CO₂eq/g edible animal food.

country_emissions_and_intensity.csv
population_weighted_emissions.csv  |  emissions.png/.pdf

Scientific settings and interpretation

Setting | Value in this release

Concentration input | PFAS in food data; aquatic concentration factor 1×.

Body weights | 62 kg for EDI calculations. US PBK physiology retains the original model’s 70 kg body weight; EDI reporting weight does not replace the physiological model parameters.

Diet inputs | The four diet inputs for exposure are in research/assets/global/input_file/diet. Scientific input paths and hashes are recorded with each run.

Trade matrices | Trade: 2020 matrix. Metatrade: distinct 2030-derived matrix.

Population weighting | Compute national HI first, then population-weight national values using the simulation-year population. Regional/world summaries record population coverage.

Compound coverage | Sum7 is exported as SUM_AVAILABLE_PFAS. Some country inputs lack one or more target PFAS. Check the compound and population coverage fields in the exposure outputs (#coverage_outputs) and each run’s statistics.csv before interpreting averages.

US PBK population | 100,000 virtual individuals for each of PFOA and PFOS. Incomplete populations are not accepted for result reuse.

Seed and repeats | The default seed is 301. Seven historical US runs use seeds 301–307 with year-specific substreams. Seven global EDI/HI runs use scenario-specific seeds.

HI reference values

All values below are in ng/kg bw/day. HI sums each compound EDI divided by its reference value within each country, then averages country values by population.

PFOS | PFHxS | PFOA | PFDA | PFDoDA | PFUnDA | PFNA

2 | 20 | 3 | 15 | 12 | 12 | 3

PFOA, PFOS, PFHxS and PFNA: ATSDR (2021), Toxicological Profile for Perfluoroalkyls, Table 1-2: intermediate-duration oral minimal risk levels (MRLs) (https://www.ncbi.nlm.nih.gov/books/NBK592148/table/ch1.tab3/?report=objectonly).
PFDA, PFDoDA and PFUnDA: TCEQ (2023), oral reference doses (RfDs); PFUnDA (PFUA) uses the PFDoDA (PFDoA) surrogate value (https://www.tceq.texas.gov/downloads/toxicology/pfc/pfcs.pdf).

Food bioavailability in the PBK model

Compound | Aquatic fraction | Terrestrial fraction

PFOA | 0.151 | 0.183

PFOS | 0.500 | 0.771

The water or solution fraction is 1. From 2005 onward, each food dose is multiplied once by its food bioavailability fraction and once by its historical compound multiplier (7.656725865487441 for PFOA and 0.3984242389525426 for PFOS). The 2003–2004 equilibrium and solution-dose calibration use the first NHANES geometric mean. The initial-state fitting and accelerated equations are checked against the original ODE implementation.

PFOA aquatic fraction 0.151: Li et al. (2015), Table 1: shrimp relative bioavailability in mice, 15.1%; applied to aquatic foods in this model (https://doi.org/10.1021/es505075z).

PFOA terrestrial fraction 0.183: Li et al. (2015), Table 1: beef relative bioavailability in mice, 18.3%; applied to terrestrial foods in this model (https://doi.org/10.1021/es505075z).

PFOS aquatic fraction 0.500: Great Lakes Consortium (2025), printed p. 22: approximate 50% central tendency discussed for gastrointestinal availability; this model uses 0.500. The guidance's final advisory calculations use 0.25 (https://www.health.mn.gov/communities/environment/fish/docs/consortium/bestpracticepfos.pdf).

PFOS terrestrial fraction 0.771: Zhu et al. (2023): 77.1% mean in vitro bioaccessibility in simulated animal foods; used here as a proxy for terrestrial food bioavailability (https://doi.org/10.1016/j.scitotenv.2023.161739).

Health outcomes and data sources

The health workflows model 34 continuous health indicators and two disease outcomes, hypertension and arthritis: 36 model targets in total. The tables use descriptions rather than internal codes for derived indicators. Links open the corresponding NHANES questionnaire or laboratory documentation. Indicators marked with + in SI Table 4 are excluded.

References and major findings come from the response-letter evidence table. A dash marks indicators for which that table lists no reference.

# | Continuous health indicator | NHANES source | Reference | Major evidence

1 | Total cholesterol. Total cholesterol measured by the dedicated cholesterol laboratory component. Unit: mg/dL. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/TCHOL_I.htm) | Puklová et al. 2023 (https://doi.org/10.21101/cejph.a7799) | PFHxS: higher total cholesterol, p = 0.005. This evidence also applies to serum cholesterol in row 9.

2 | Serum albumin. Albumin in refrigerated serum. Unit: g/dL. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | Omoike et al. 2021 (https://doi.org/10.1016/j.envres.2020.110361) | PFOA: reported model β=0.03 (CI 0.03–0.04); quintile trend p < 0.001.

3 | Hematocrit. Proportion of blood volume occupied by red blood cells. Unit: %. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/CBC_I.htm) | Yang et al. 2025 (https://doi.org/10.1016/j.jare.2024.04.022) | PFHxS: higher hematocrit, p < 0.001; highest versus lowest tertile.

4 | Serum creatinine (SI units). Creatinine in refrigerated serum, SI representation. Unit: umol/L. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | Jain and Ducatman 2019 (https://doi.org/10.1016/j.envres.2019.04.034) | PFOA, PFOS and PFHxS were associated with higher serum creatinine among participants with normal filtration. Both rows express the same analyte in different units. Applies to rows 4–5.

5 | Serum creatinine. Creatinine in refrigerated serum, conventional representation. Unit: mg/dL. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | See row 4. | See row 4.

6 | Total serum calcium. Total calcium concentration. Unit: mmol/L. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | Cakmak et al. 2022 (https://doi.org/10.1016/j.scitotenv.2022.153900) | PFDA: calcium +0.8% (CI 0.3–1.3) per 0.2 µg/L PFDA.

7 | Blood urea nitrogen. Blood urea nitrogen, SI representation. Unit: mmol/L. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | — | No row for blood urea nitrogen alone. The C_BCR reference concerns the BUN to creatinine ratio.

8 | Gamma-glutamyl transferase. Serum gamma-glutamyl transferase enzyme activity. Unit: U/L. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | Cakmak et al. 2022 (https://doi.org/10.1016/j.scitotenv.2022.153900) | PFOA: GGT +11.8% (CI 2.5–21.8) per 2.0 µg/L PFOA.

9 | Serum cholesterol. Cholesterol measured in the standard biochemistry profile. Unit: mg/dL. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | See row 1 | See the total cholesterol finding in row 1. This row uses a separate NHANES laboratory component.

10 | Serum uric acid. Uric acid concentration, conventional representation. Unit: mg/dL. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | Shankar et al. 2011 (https://doi.org/10.2147/CLEP.S21677) | The highest PFOA quartile had higher odds of hyperuricemia than the lowest (OR 1.97, CI 1.44–2.70). Both rows express serum uric acid in different units. Applies to rows 10–11.

11 | Serum uric acid (SI units). Uric acid concentration, SI representation. Unit: umol/L. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | See row 10. | See row 10.

12 | Total bilirubin. Total serum bilirubin, SI representation. Unit: umol/L. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | Cakmak et al. 2022 (https://doi.org/10.1016/j.scitotenv.2022.153900) | PFOA: bilirubin +3.6% (CI 2.7–4.5) per 2.0 µg/L PFOA.

13 | Red blood cell count. Red blood cell concentration. Unit: million cells/uL. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/CBC_I.htm) | Yang et al. 2025 (https://doi.org/10.1016/j.jare.2024.04.022) | PFHxS: higher RBC count, p = 0.011; highest versus lowest tertile.

14 | White blood cell count. White blood cell concentration. Unit: 1000 cells/uL. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/CBC_I.htm) | Lopez-Espinosa et al. 2021 (https://doi.org/10.1016/j.envint.2021.106599) | Per IQR: PFHxS +0.55% (CI 0.25–0.86); PFOS −0.55% (CI −0.84 to −0.26).

15 | Red cell distribution width. Variation in red blood cell size. Unit: %. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/CBC_I.htm) | Yang et al. 2025 (https://doi.org/10.1016/j.jare.2024.04.022) | PFHxS: lower RDW, p < 0.001; highest versus lowest tertile.

16 | Mean cell hemoglobin. Mean hemoglobin mass per red blood cell. Unit: pg. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/CBC_I.htm) | — | No row for mean cell hemoglobin. The table has related hemoglobin and other erythrocyte measures.

17 | Hemoglobin. Hemoglobin concentration in whole blood. Unit: g/dL. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/CBC_I.htm) | Yang et al. 2025 (https://doi.org/10.1016/j.jare.2024.04.022) | PFHxS: higher hemoglobin, p < 0.001; highest versus lowest tertile.

18 | Mean platelet volume. Mean platelet size. Unit: fL. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/CBC_I.htm) | Lin et al. 2022 (https://doi.org/10.1016/j.ecoenv.2022.113457) | PFOS: MPV increased significantly across quartiles in the adjusted model.

19 | Platelet count. Platelet concentration. Unit: 1000 cells/uL. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/CBC_I.htm) | Li et al. 2025 (https://doi.org/10.1016/j.ecoenv.2025.118849) | PFHxS: adjusted β=−11.27 (CI −14.86 to −7.68); significant after FDR correction.

20 | Serum globulin. Serum globulin concentration. Unit: g/dL. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | — | No row for serum globulin. The table has separate albumin evidence.

21 | Serum bicarbonate. Bicarbonate concentration. Unit: mmol/L. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | Curran et al. 2008 (https://doi.org/10.1080/15287390802361763) | PFOS: 20.80 vs. 24.53 mmol/L in male rats and 19.13 vs. 23.27 mmol/L in female rats, compared with controls. (p < 0.001) The cited bicarbonate finding is from male and female rats fed PFOS.

22 | Pulse rate. Pulse count standardized to 60 seconds. Unit: beats/minute. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BPX_I.htm) | Fan et al. 2023 (https://doi.org/10.1016/j.jhazmat.2023.131832) | 6:2 Cl-PFESA: ECG heart-rate difference −6.98 (CI −9.07 to −4.90), 95th versus 25th exposure percentile. The cited study analyzes ECG-derived heart rate with 6:2 Cl-PFESA. The NHANES variable records pulse rate.

23 | Maximum cuff inflation pressure. Maximum inflation level determined before blood pressure readings. Unit: mm Hg. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BPX_I.htm) | — | No row for maximum cuff inflation pressure. The table has separate systolic and diastolic blood-pressure evidence.

24 | Diastolic blood pressure: first reading. First diastolic blood pressure reading. Unit: mm Hg. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BPX_I.htm) | Pitter et al. 2020 (https://doi.org/10.1186/s12940-020-00656-0) | Per one-unit increase in ln serum PFOA, adjusted diastolic pressure was 0.34 mm Hg higher (95% CI 0.21–0.47) and systolic pressure was 0.37 mm Hg higher (95% CI 0.19–0.54). The estimates describe systolic and diastolic pressure by outcome, without separate estimates by reading number. Applies to rows 24–29.

25 | Systolic blood pressure: first reading. First systolic blood pressure reading. Unit: mm Hg. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BPX_I.htm) | See row 24. | See row 24.

26 | Diastolic blood pressure: second reading. Second diastolic blood pressure reading. Unit: mm Hg. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BPX_I.htm) | See row 24. | See row 24.

27 | Systolic blood pressure: second reading. Second systolic blood pressure reading. Unit: mm Hg. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BPX_I.htm) | See row 24. | See row 24.

28 | Diastolic blood pressure: third reading. Third diastolic blood pressure reading. Unit: mm Hg. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BPX_I.htm) | See row 24. | See row 24.

29 | Systolic blood pressure: third reading. Third systolic blood pressure reading. Unit: mm Hg. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BPX_I.htm) | See row 24. | See row 24.

30 | Albumin-to-globulin ratio. Calculated serum albumin-to-globulin ratio. Unit: ratio. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | — | No row for the albumin-to-globulin ratio. The table has separate albumin evidence.

31 | Calculated cholesterol index. Source-derived index labelled LDL cholesterol in the SI; the supplied formula and scale are retained. Unit: source-derived index. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | Puklová et al. 2023 (https://doi.org/10.21101/cejph.a7799) | Clinical LDL: higher with PFHxS, p = 0.008. The paper reports clinical LDL. The pipeline outcome is the source-derived LDL-labeled index.
Additional component (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/HDL_I.htm)

32 | Calculated total cholesterol-to-HDL ratio. Ratio using the source total-cholesterol conversion and measured HDL. Unit: source-derived ratio. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | Canova et al. 2020 (https://doi.org/10.1016/j.envint.2020.106117) | PFHxS: TC/HDL ratio +0.06 (CI 0.01–0.10), quartile 4 versus 1. The study directly reports a total cholesterol to HDL ratio, which the pipeline computes from source analytes.
Additional component (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/HDL_I.htm)

33 | Calculated cholesterol-index-to-HDL ratio. Ratio of the source-derived cholesterol index to measured HDL. Unit: source-derived ratio. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | Yang et al. 2021 (https://doi.org/10.1016/j.chemosphere.2020.128566) | PFOA: clinical LDL/HDL β=−0.042 (CI −0.075 to −0.009). The paper reports clinical LDL/HDL. The pipeline outcome is a source-derived LDL/HDL ratio.
Additional component (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/HDL_I.htm)

34 | Blood urea nitrogen-to-creatinine ratio. Calculated ratio after conversion of creatinine from umol/L to mmol/L. Unit: ratio. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BIOPRO_I.htm) | Hall et al. 2023 (https://doi.org/10.1016/j.scitotenv.2023.165091) | PFOS: significantly higher BUN:creatinine ratio in adjusted repeated-measures models. The study directly reports a BUN to creatinine ratio, which the pipeline computes from source analytes.

Disease outcomes

# | Disease outcome | NHANES source | Reference | Major evidence

1 | Hypertension diagnosis. Ever told by a health professional that the participant had high blood pressure. Prepared questionnaire cohort: 8,587 participants. Unit: probability difference. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/BPQ_I.htm#BPQ020) | Ding et al. 2022 (https://doi.org/10.1161/HYPERTENSIONAHA.121.18809) | PFOS: incident-hypertension HR 1.42 (CI 1.19–1.68), highest versus lowest tertile.

2 | Arthritis diagnosis. Ever told by a health professional that the participant had arthritis. Prepared questionnaire cohort: 8,749 participants. Unit: probability difference. | NHANES documentation (https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2015/DataFiles/MCQ_I.htm#MCQ160a) | Yang et al. 2024 (https://doi.org/10.1186/s12889-024-17879-2) / Qu et al. 2022 (https://doi.org/10.1016/j.envpol.2022.119505) | PFNA: arthritis OR 1.36 (CI 1.10–1.69). PFOA: Rheumatoid arthritis adjusted OR 1.998 (CI 1.623–2.361).

Folders results and moving the project

The research folder contains the programs, inputs and configuration. Generated data are saved under research/workspace by default; choose another writable location if more disk space is needed.

BlueFood Portable Pipeline/
  Setup Environment.cmd
  Start Pipeline.cmd
  Stop Pipeline.cmd
  README.docx
  research/
    programs and scientific adapters
    assets/                      scientific inputs and models
    ASSET_MANIFEST.json           input hashes
    SOURCE_PROVENANCE.json        original source names and hashes
    RELEASE_MANIFEST.json / RELEASE_INFO.json
    environment*.txt / environment.yml / requirements*.txt
    bluefood.example.json / bluefood.json
    validation/ / tests/
    workspace/
      runs/timestamp_stage_id/
        request.json / progress.json / run.log
        COMPLETE.json OR FAILED.json
        scientific CSV / PNG / PDF / NPZ outputs
      cache/ / imports/ / state/ / Rlibrary/

Select another disk

Before first setup, optionally copy research/bluefood.example.json to research/bluefood.json. Preserve the Python path recorded by setup when editing this file. Set workspace to the results location and optionally limit max_workers. Add these keys to the existing configuration rather than replacing the whole file:

{
  "workspace": "D:/BlueFoodResults",
  "max_workers": 1
}

The example drive is optional. Relative configuration paths resolve from research, rather than the terminal’s current directory. Restart the pipeline after changing configuration.

Move or share the project

Copy the complete pipeline folder and research/workspace, or point workspace to its new location. Saved locations are rebased by run ID. Recreate the environment on a new computer because Conda environments and compiled R libraries depend on their platform and installation path. Share the source ZIP rather than an installed environment, caches, old results, local research/bluefood.json or credentials.

Advanced setup and configuration

Normal Windows use starts with Setup Environment.cmd and Start Pipeline.cmd. If Miniforge is installed elsewhere, open PowerShell in the outer pipeline folder and pass the full path to its conda.exe with -Conda. Replace the example paths with your own. You can also set BLUEFOOD_MINIFORGE_ROOT to the Miniforge installation folder before running setup.

Specify a Miniforge installation or environment location

& '.\research\Setup Environment.ps1' -Conda 'C:\Tools\Miniforge3\Scripts\conda.exe'
& '.\research\Setup Environment.ps1' `
  -Conda 'C:\Tools\Miniforge3\Scripts\conda.exe' `
  -Prefix 'D:\BlueFoodEnv'

The backtick at the end of a PowerShell line continues the same command. You may instead type the command on one line. Use -Rscript to select an existing native R installation:

& '.\research\Setup Environment.ps1' `
  -Conda 'C:\Tools\Miniforge3\Scripts\conda.exe' `
  -Rscript 'C:\path\to\Rscript.exe'

Install CPU-only PyTorch if its download host is unreachable

On Windows x64, Setup Environment can download the pinned CPU-only PyTorch wheel from either of two official PyTorch hosts. If both are unreachable, create research/offline-wheels inside the pipeline folder. Copy torch-2.2.2+cpu-cp39-cp39-win_amd64.whl from a computer that can download it into that folder, then rerun Setup Environment.cmd. Setup checks the wheel against the SHA-256 in research/windows-offline-wheel-hashes.json before installing it. Other packages can still download normally. To install all Python packages from local files, use -Wheelhouse as shown below.

Install from verified local packages on Windows x64

Use the options below when you have a copy of the packages listed in research/environment-win64-explicit.txt and research/windows-offline-wheel-hashes.json. The packages are separate downloads. Setup checks the archive and wheel hashes before creating the environment. Either option can be supplied by itself to keep the other installer online.

& '.\research\Setup Environment.ps1' `
  -Conda 'C:\Tools\Miniforge3\Scripts\conda.exe' `
  -CondaArchives 'D:\BlueFoodPackages\conda' `
  -Wheelhouse 'D:\BlueFoodPackages\wheels'

CondaArchives accepts a folder of the original Conda package files or a cache with those files in its https/conda.anaconda.org/conda-forge directories. Wheelhouse accepts the exact wheel files, including pip and Windows x64 Python 3.9 CPU-only PyTorch. The locked Conda environment supplies setuptools and wheel. Add -DryRun to verify the package files and show the setup commands before installing. These options use the Windows lock's R packages. Use them without -Rscript.

Supported JSON settings

Key | Purpose

workspace | Root for runs, cache, imports and state.

assets_dir / asset_manifest | Bundled assets and their reviewed checksum manifest.

python / rscript / r_library | Python path recorded by Miniforge setup, plus optional native R executable and library paths.

port | Browser port; 0 chooses an available port.

max_workers | Explicit concurrency cap, subject to available CPU count.

Recognized environment overrides are BLUEFOOD_CONFIG, BLUEFOOD_WORKSPACE, BLUEFOOD_ASSETS, BLUEFOOD_MANIFEST, BLUEFOOD_RSCRIPT, BLUEFOOD_R_LIBRARY, BLUEFOOD_PORT, BLUEFOOD_MAX_WORKERS and BLUEFOOD_PYTHON. Use -Python or BLUEFOOD_PYTHON only to point to the dedicated Python 3.9.19 executable created by Miniforge setup. An external assets folder is checked against the bundled manifest. Replacing scientific inputs also requires a reviewed manifest.

Linux x64 and Intel macOS

Install Miniforge, then use these supplied launchers. Windows x64 is the scientifically exercised platform for this release; validate Linux/macOS execution before using its results for publication.

sh research/setup_environment.sh
sh research/start_pipeline.sh
sh research/start_pipeline.sh --stop

Apple Silicon and other ARM systems require an x64 environment or a separately validated dependency set. Miniforge setup creates the dedicated Python 3.9.19 interpreter that the launchers and calculations use.

Dependency versions and provenance

Windows setup uses environment-win64-explicit.txt for Conda/R builds and requirements-lock-win64.txt for the complete Python dependency set. The table lists the direct scientific packages; the full transitive lock remains authoritative.

Package | Version | Package | Version

Python | 3.9.19 | R | 4.5.2

numpy | 1.24.4 | pandas | 2.0.0

scipy | 1.8.1 | matplotlib | 3.9.0

openpyxl | 3.1.5 | econml | 0.15.0

scikit-learn | 1.4.2 | torch | 2.2.2+cpu

xgboost | 2.0.3 | numba | 0.60.0

joblib | 1.4.2 | psutil | 5.9.8

pyecharts | 2.0.6 | shap | 0.43.0

sparse | 0.15.4 | R deSolve | 1.42

R openxlsx | 4.2.9 | R jsonlite | 2.0.0

Inputs and calculation records

research/ASSET_MANIFEST.json records the scientific inputs and their SHA256 hashes. research/SOURCE_PROVENANCE.json retains original names and source revisions. research/RELEASE_INFO.json identifies the measured serum workbook. Earlier validation records apply to their stated source versions. Adapters supply the bundled paths, so historical drive letters are not required.

Each calculation keeps request.json, progress.json, run.log and COMPLETE.json or FAILED.json. Runtime and input fingerprints identify compatible saved runs; incompatible new environments recalculate. Inputs, existing outputs and environments are preserved. check_install.py checks imports, exact direct Python versions, R packages and asset hashes; setup_R.R records R package versions.

Historical execution of all eight workflows was checked on Windows ECS. The portable adapters have checks for relocation, diet and CO₂ consistency, exposure totals, population weighting, R solver acceleration and source effect calculations. Consult research/validation for the actual test scope. A successful software check does not establish epidemiological validity.

Source and setup references

Scientific source release on Zenodo (https://zenodo.org/records/20647037)

Miniforge installation and releases (https://github.com/conda-forge/miniforge)

Conda environment management (https://docs.conda.io/projects/conda/en/stable/user-guide/tasks/manage-environments.html)

PyTorch previous versions (https://pytorch.org/get-started/previous-versions/)

EconML CausalForestDML API (https://www.pywhy.org/EconML/_autosummary/econml.dml.CausalForestDML.html)

R startup and environment configuration (https://stat.ethz.ch/R-manual/R-devel/library/base/html/Startup.html)

Software and associated documentation are distributed under LICENSE.txt (MIT License; copyright 2026 HIAS-RCEES-FuLab). Retain the license notice when redistributing the release.

Troubleshooting and completion checks

Symptom | Action

Miniforge is not found | Install Miniforge for your user account. For a custom installation, pass the full path to its conda.exe with -Conda or set BLUEFOOD_MINIFORGE_ROOT. Run setup again.

Wrong Python or missing packages | Run Setup Environment.cmd again to restore the dedicated Miniforge environment, then use Start Pipeline.cmd.

Rscript is not found | Run setup again, or specify the existing Rscript.exe with -Rscript. Check deSolve, openxlsx and jsonlite.

Browser did not open | Inspect the launcher message and research/workspace/state/server.log. Use the local URL printed by the launcher; its port may differ from 8765.

A stage is already running | Wait for it to complete, or use the visible Stop control to cancel it before submitting another stage.

Memory pressure or low disk space | Reduce Workers. Move workspace to a larger disk and restart. Earlier results are preserved; extensive exposure repeats need substantially more storage.

Input checksum mismatch | Restore assets from the matching release. Do not bypass the manifest or mix input files from different versions.

A prerequisite result is reused | Prerequisites reuse compatible completed results automatically. Left-click the workflow card to calculate that workflow again, or right-click it to view its saved result.

Result differs from a historical number | Compare input version, seed, repeats, diet, matrix, body weight, RfDs, compound coverage and weighting in request/method files before interpreting the difference.

A ZIP is not extracted | Only the outer portable ZIP needs manual extraction. For an additional archive, place its ZIP file in research/workspace/imports and run Environment & data; the program opens it automatically.

Safe archive handling

Matching previously extracted files are skipped. Conflicting files are preserved and reported rather than overwritten. Absolute Windows paths, parent-directory escapes and archive symlinks are rejected. These checks also prevent accidental mixing of releases.

Confirm a usable completed run

1. Check completion. The Results panel says Completed and the corresponding run folder contains COMPLETE.json.

2. Open the numeric output. Verify the scenario, body weight, units, country/compound coverage and population weights before using a summary.

3. Retain provenance. Keep the run folder and its request, log, source hashes and method/settings records with exported tables and figures.

4. Close the server when finished. Use Stop Pipeline.cmd; on Linux or macOS use sh research/start_pipeline.sh --stop. The portable launcher does not register a startup service.

Historical global simulation

Run the standalone simulation from assets/global/program. It uses the packaged LR diet by default. To reproduce the original standalone run, extract FAOSTAT_diet_2050_LR_reference.csv from the original ZIP and supply its path with --low-road-diet.

Measured ECS benchmark

The pipeline completed all eight stages on 12 November 2026 on Alibaba ECS with Windows Server 2025, 4 vCPUs, and 8 GiB RAM. The run used one repeat, one worker, seed 301, and 36 verified fitted health models in a fresh results workspace.

Stage | Measured wall time | Verified result

Environment & data | 13.7 s | Python and R checks passed and 96 input files matched their checksums. See environment.json.

2050 diet pathways | 5.5 s | National diets and population-weighted food consumption for 2020, LR, BAU, and HR. See population_weighted_diets.csv.

CO2 emissions & intensity | 5.6 s | Population-weighted emissions totals and intensity for 2020, LR, BAU, and HR. See population_weighted_emissions.csv.

2020 exposure & HI | 3 min 7.1 s | Trade and No-trade EDI and HI for 47 countries, regions, and the world. See statistics.csv.

US historical EDI | 3 min 53.9 s | Annual US PFAS exposure for 2003–2016 and comparison with historical estimates. See US_EDI.csv and US_Sum7.csv.

US PFOA & PFOS serum (PBK) | 10 min 27.0 s | 100,000 simulations per compound and 56 compound, scenario, and period summaries. See PFOA_PFOS_period_results.csv.

2020 health outcomes | 8 min 40.3 s | Modeled serum concentrations compared with measured values and projections for 36 health outcomes. See predicted_vs_measured_serum.csv and regional_world_health_outcomes.csv.

2050 exposure & health | 1 h 45 min 35.9 s | EDI, HI, serum burden, and 36 health outcome projections across six pathway and trade-mode scenarios. See statistics.csv, regional_world_total_serum_burden.csv, and regional_world_health_outcomes.csv.

Full workflow | 2 h 12 min 10.6 s | All eight stages completed. Total elapsed time was measured from submission through completion.

Clean environment setup through smoke checks took 1 h 7 min 44.5 s from the corrected retry, including download delays and recovery with verified offline wheels. Fitting and verifying the 36 health models took 2 h 34 min in a separate ECS run. Staging the verified models took 10.0 s before the measured workflow.

The ECS benchmark saved stage-timings.csv, pipeline-timing.json, and setup-timings-all-attempts.csv.

"""US historical intake and PBK result plots used by the portable Results panel."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats


PFAS = ("PFDA", "PFDoDA", "PFHxS", "PFNA", "PFOA", "PFOS", "PFUnDA")
YEARS = list(range(2003, 2017))
PERIODS = YEARS[::2]
COLORS = ("#488f8c", "#9c8734", "#7b71ab", "#b55b56", "#4c7e9d", "#b47831", "#698948")
AQUATIC = "#168c82"
TERRESTRIAL = "#c38d41"


def historical_cv_note(figure, assets_us):
    """Place the observed 2020 CV alongside the annual plots as context."""
    path = Path(assets_us) / "inputs/geometric_mean_edi_cv_2020.csv"
    cv = pd.read_csv(path).set_index("chemical").loc[list(PFAS)]
    if not cv["runs"].eq(7).all() or not np.isfinite(cv["cv_percent"]).all():
        raise ValueError("US EDI context requires seven verified 2020 runs per compound.")
    for axis in figure.axes:
        if axis.axison:
            axis.set_xticks([2003, 2006, 2009, 2012, 2016])
    summary = "   ".join(f"{chemical} {value:.2f}%" for chemical, value in cv.cv_percent.items())
    figure.text(
        0.01, 0.0,
        "Reference CV of geometric mean EDI · US 2020 Trade, unchanged concentration, seven independent runs\n"
        + summary
        + "\nCV = run SD ÷ run mean. These CVs give 2020 context only. Annual error bars show SD when the historical run is repeated.",
        ha="left", va="top", fontsize=8.5, color="#333333", linespacing=1.35,
    )


def _period_label(year):
    return f"{year}–{str(year + 1)[-2:]}"


def _source_plot(out, rows, savefig):
    available = rows.loc[rows.status.eq("available")]
    annual = (
        available.groupby(["year", "replicate", "component"])["mean_EDI"]
        .sum().groupby(["year", "component"]).mean().unstack()
        .reindex(index=YEARS, columns=["aquatic", "terrestrial"])
    )
    if annual.isna().any().any() or (annual.sum(axis=1) <= 0).any():
        raise ValueError("The annual aquatic and terrestrial EDI series are incomplete.")
    shares = annual.div(annual.sum(axis=1), axis=0).mul(100)
    figure, axis = plt.subplots(figsize=(12, 5))
    bottom = np.zeros(len(annual))
    for component, color in [("aquatic", AQUATIC), ("terrestrial", TERRESTRIAL)]:
        bars = axis.bar(
            annual.index, annual[component], bottom=bottom, color=color,
            label=component.capitalize(), width=0.74,
        )
        labels = [f"{pct:.0f}%" if pct >= 10 else "" for pct in shares[component]]
        axis.bar_label(bars, labels=labels, label_type="center", fontsize=8, color="white")
        if component == "terrestrial":
            for bar, pct, total in zip(bars, shares[component], annual.sum(axis=1)):
                if pct < 10:
                    axis.annotate(
                        f"{pct:.0f}%", (bar.get_x() + bar.get_width() / 2, total),
                        xytext=(0, 3), textcoords="offset points",
                        ha="center", fontsize=8, color="#604216",
                    )
        bottom += annual[component].to_numpy()
    axis.set(
        title="US annual PFAS intake by food source",
        ylabel="Mean EDI (ng/kg bw/day)", xticks=YEARS,
    )
    axis.tick_params(axis="x", labelrotation=35)
    axis.margins(y=0.1)
    axis.legend(frameon=False, ncol=2)
    axis.grid(axis="y", alpha=0.2)
    figure.text(
        0.01, 0, "Bars sum arithmetic mean EDI across available PFAS. Labels show shares of annual EDI.",
        fontsize=8.5, va="top",
    )
    savefig(out, "US_EDI_by_food_source")


def _composition_plot(out, rows, reference, savefig):
    edi = rows.loc[rows.status.eq("available") & rows.component.eq("total")].copy()
    edi["period_start"] = edi.year - (edi.year - 2003) % 2
    edi = (
        edi.groupby(["year", "period_start", "chemical"])["mean_EDI"].mean()
        .groupby(["period_start", "chemical"]).mean().unstack()
        .reindex(index=PERIODS, columns=PFAS)
    )
    serum = reference.loc[PERIODS, list(PFAS)]
    if edi.isna().any().any() or serum.isna().any().any():
        raise ValueError("US EDI and measured serum need all seven PFAS in each period.")
    figure, axis = plt.subplots(figsize=(11, 5))
    x = np.arange(len(PERIODS))
    for data, offset, texture, label in [
        (edi, -0.20, None, "EDI"), (serum, 0.20, "//", "Serum"),
    ]:
        shares = data.div(data.sum(axis=1), axis=0).mul(100)
        bottom = np.zeros(len(PERIODS))
        for chemical, color in zip(PFAS, COLORS):
            axis.bar(
                x + offset, shares[chemical], bottom=bottom, width=0.38,
                color=color, hatch=texture, edgecolor="white", linewidth=0.35,
                label=chemical if label == "EDI" else None,
            )
            bottom += shares[chemical].to_numpy()
        for position in x + offset:
            axis.text(position, 101, label, fontsize=8, ha="center")
    axis.set(
        title="PFAS composition in US dietary intake and measured serum",
        ylabel="Composition (%)", ylim=(0, 109), xticks=x,
        xticklabels=[_period_label(year) for year in PERIODS],
    )
    axis.set_yticks(np.arange(0, 101, 20))
    axis.legend(frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.10), ncol=7)
    figure.text(
        0.01, -0.02,
        "EDI uses calculated arithmetic means. Measured serum composition uses compound geometric means from Fig. 1e.",
        fontsize=8.5, va="top",
    )
    savefig(out, "US_EDI_and_serum_composition")


def _annual_quartiles(out, sums, body_weight):
    records = []
    complete = sums.loc[sums.status.eq("available")]
    if complete.duplicated(["year", "replicate"]).any():
        raise ValueError("Unexpected duplicate annual US exposure replicate.")
    for row in complete.itertuples(index=False):
        with np.load(
            Path(out) / "annual" / str(row.year) / f"{row.case}_r{row.replicate}.npz",
            allow_pickle=False,
        ) as arrays:
            total = np.zeros_like(arrays["expo_total^" + PFAS[0]], dtype=float)
            for chemical in PFAS:
                total += arrays["expo_total^" + chemical]
        p25, p75 = np.percentile(total / body_weight, [25, 75])
        records.append((row.year, row.true_total_gmean, p25, p75))
    annual = pd.DataFrame(records, columns=["year", "edi_gmean", "edi_p25", "edi_p75"])
    if set(annual.year) != set(YEARS):
        raise ValueError("Combined EDI is incomplete for the seven measured serum periods.")
    annual = annual.groupby("year").mean()
    annual["period_start"] = annual.index - (annual.index - 2003) % 2
    return annual.groupby("period_start").mean()


def _correlation_plot(out, sums, body_weight, reference, savefig):
    edi = _annual_quartiles(out, sums, body_weight)
    data = edi.join(reference[["serum_gmean", "serum_p25", "serum_p75"]], how="inner")
    if len(data) != 7 or not np.isfinite(data.to_numpy()).all():
        raise ValueError("Expected seven finite biennial EDI and serum comparisons.")
    x = data.edi_gmean.to_numpy()
    y = data.serum_gmean.to_numpy()
    if np.ptp(x) == 0:
        raise ValueError("Cannot fit an EDI–serum line to constant EDI.")
    fitted = stats.linregress(x, y)
    line_x = np.linspace(x.min(), x.max(), 100)
    line_y = fitted.intercept + fitted.slope * line_x
    residual = y - (fitted.intercept + fitted.slope * x)
    n = len(data)
    t_value = stats.t.ppf(0.975, n - 2)
    se = np.sqrt(np.sum(residual ** 2) / (n - 2))
    ci = t_value * se * np.sqrt(1 / n + (line_x - x.mean()) ** 2 / np.sum((x - x.mean()) ** 2))
    figure, axis = plt.subplots(figsize=(8.3, 5))
    # Draw interval endpoints directly, since a geometric mean can fall outside
    # the middle 50% of a skewed distribution.
    axis.hlines(y, data.edi_p25, data.edi_p75, color="#7a7f84", linewidth=1.0)
    axis.vlines(x, data.serum_p25, data.serum_p75, color="#7a7f84", linewidth=1.0)
    axis.fill_between(line_x, line_y - ci, line_y + ci, color="#ad5358", alpha=0.16)
    axis.plot(line_x, line_y, "--", color="#ad5358", label=f"Linear fit (r = {fitted.rvalue:.2f}, n = {n})")
    axis.scatter(x, y, color="#253746", zorder=4)
    axis.set(
        title="US dietary PFAS intake and measured serum",
        xlabel="Total EDI geometric mean (ng/kg bw/day)",
        ylabel="Measured total serum geometric mean (ng/mL)",
    )
    axis.legend(frameon=False)
    axis.grid(alpha=0.2)
    figure.text(
        0.01, 0,
        "Each dot is a two-year period. Bars span the 25th–75th percentiles. Shading is the 95% confidence band for the fitted mean.",
        fontsize=8.5, va="top",
    )
    savefig(out, "US_EDI_and_serum_correlation")


def historical_edi_views(out, rows, sums, body_weight, assets_us, savefig):
    """Render Fig. 1c–e counterparts using the current EDI and measured reference."""
    out = Path(out)
    rows = pd.DataFrame(rows)
    sums = pd.DataFrame(sums)
    reference = pd.read_csv(Path(assets_us) / "inputs/figure1_serum_reference.csv").set_index("period_start")
    _source_plot(out, rows, savefig)
    _composition_plot(out, rows, reference, savefig)
    _correlation_plot(out, sums, body_weight, reference, savefig)


def pbk_composition_view(out, period_results, savefig):
    """Use SI Fig. 5 scenario differences to partition combined PFOA and PFOS."""
    columns = ["no_exposure", "terrestrial_only", "aquatic_plus_terrestrial"]
    used = period_results.loc[period_results.scenario.isin(columns)].copy()
    if set(used.compound) != {"PFOA", "PFOS"} or used.duplicated(["compound", "scenario", "period"]).any():
        raise ValueError("Unexpected PBK period coverage for PFOA and PFOS.")
    grouped = used.groupby(["period", "scenario"])["arithmetic_mean"]
    if not grouped.count().eq(2).all():
        raise ValueError("Each PBK scenario-period needs both compound means.")
    means = grouped.sum().unstack().reindex(columns=columns).sort_index().drop("2003-2004")
    if means.shape != (6, 3) or means.isna().any().any() or (means.aquatic_plus_terrestrial <= 0).any():
        raise ValueError("PBK source decomposition requires all six post-calibration cycles.")
    parts = pd.DataFrame({
        "Carryover from 2004": means.no_exposure,
        "Terrestrial foods": means.terrestrial_only - means.no_exposure,
        "Aquatic foods": means.aquatic_plus_terrestrial - means.terrestrial_only,
    })
    shares = parts.div(means.aquatic_plus_terrestrial, axis=0).mul(100)
    figure, axis = plt.subplots(figsize=(10.2, 5))
    x = np.arange(len(shares))
    positive = np.zeros(len(shares))
    negative = positive.copy()
    for source, color in zip(parts, ("#9b9fa3", TERRESTRIAL, AQUATIC)):
        values = shares[source].to_numpy()
        is_positive = values >= 0
        bars = axis.bar(x, values, bottom=np.where(is_positive, positive, negative), color=color, label=source)
        labels = [f"{value:.1f}%" if abs(value) >= 4 else "" for value in values]
        axis.bar_label(bars, labels=labels, label_type="center", fontsize=8, color="white")
        positive += np.maximum(values, 0)
        negative += np.minimum(values, 0)
    axis.set(
        title="Sources of modeled PFOA + PFOS in US serum",
        ylabel="Share of combined-food scenario (%)", xticks=x,
        xticklabels=[period.replace("-", "–") for period in shares.index],
    )
    axis.grid(axis="y", alpha=0.2)
    axis.legend(frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.0), ncol=3)
    axis.margins(y=0.13)
    figure.text(
        0.01, 0,
        "Carryover = no exposure after 2004. Terrestrial = terrestrial only minus carryover.\n"
        "Aquatic = both food sources minus terrestrial only. Each scenario sums the arithmetic means for PFOA and PFOS.",
        fontsize=8.5, va="top",
    )
    savefig(out, "US_PBK_serum_sources")

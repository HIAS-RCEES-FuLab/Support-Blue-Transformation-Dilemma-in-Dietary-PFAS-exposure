param(
    [string]$Python,
    [int]$Port = -1,
    [switch]$NoBrowser,
    [switch]$Stop
)

$ErrorActionPreference = 'Stop'

function Resolve-ManagedPython([string]$Location) {
    if (-not $Location) { return }
    $Location = [Environment]::ExpandEnvironmentVariables($Location.Trim('"'))
    if ($Location -match '^~[\\/]') { $Location = Join-Path $env:USERPROFILE $Location.Substring(2) }
    if (-not [IO.Path]::IsPathRooted($Location)) { $Location = Join-Path $PSScriptRoot $Location }
    if (-not (Test-Path -LiteralPath $Location -PathType Leaf)) { return }
    $path = (Resolve-Path -LiteralPath $Location).ProviderPath
    if ((Split-Path -Leaf $path) -ne 'python.exe') { return }
    $prefix = Split-Path -Parent $path
    $marker = Join-Path $prefix 'BLUEFOOD_ENVIRONMENT.json'
    $condaMeta = Join-Path $prefix 'conda-meta'
    if (-not (Test-Path -LiteralPath $marker -PathType Leaf) -or
        -not (Test-Path -LiteralPath (Join-Path $condaMeta 'history') -PathType Leaf)) { return }

    try {
        $ownership = Get-Content -LiteralPath $marker -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($ownership.application -ne 'BlueFood portable pipeline' -or
            $ownership.python -ne '3.9.19' -or $ownership.created_by -ne 'bootstrap.py') { return }
        $packages = @(Get-ChildItem -LiteralPath $condaMeta -Filter 'python-3.9.19-*.json' -File)
        foreach ($item in $packages) {
            $package = Get-Content -LiteralPath $item.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($package.name -ne 'python' -or $package.version -ne '3.9.19') { continue }
            $forgeChannel = '^(?:https://(?:conda\.anaconda\.org|prefix\.dev)/)?conda-forge(?:/[^/]+)?/?$'
            $fromCondaForge = $package.channel -match $forgeChannel -or $package.schannel -match $forgeChannel
            $fromOfflineLock = $package.md5 -eq 'b6999bc275e0e6beae7b1c8ea0be1e85'
            if ($fromCondaForge -or $fromOfflineLock) { return $path }
        }
    } catch {
        return
    }
}

$override = $Python
if (-not $override) { $override = $env:BLUEFOOD_PYTHON }
if ($override) {
    $pipelinePython = Resolve-ManagedPython $override
    if (-not $pipelinePython) {
        throw 'The Python override must select a managed BlueFood environment created by Setup Environment.cmd.'
    }
} else {
    $configPath = $env:BLUEFOOD_CONFIG
    if (-not $configPath) { $configPath = Join-Path $PSScriptRoot 'bluefood.json' }
    elseif (-not [IO.Path]::IsPathRooted($configPath)) { $configPath = Join-Path $PSScriptRoot $configPath }
    $configured = $null
    if (Test-Path -LiteralPath $configPath -PathType Leaf) {
        $configured = (Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json).python
    }
    $pipelinePython = Resolve-ManagedPython $configured
    if (-not $pipelinePython) {
        $pipelinePython = Resolve-ManagedPython (Join-Path $PSScriptRoot '.environment\python.exe')
    }
    if (-not $pipelinePython) { throw 'Run Setup Environment.cmd first to create the managed BlueFood environment.' }
}

$pipelineArguments = @((Join-Path $PSScriptRoot 'launch.py'), '--python', $pipelinePython)
if ($Port -ge 0) { $pipelineArguments += @('--port', [string]$Port) }
if ($NoBrowser) { $pipelineArguments += '--no-browser' }
if ($Stop) { $pipelineArguments += '--stop' }

$previousPythonHome = $env:PYTHONHOME
$previousPythonPath = $env:PYTHONPATH
try {
    $env:PYTHONHOME = $null
    $env:PYTHONPATH = $null
    & $pipelinePython -E -s @pipelineArguments
} finally {
    $env:PYTHONHOME = $previousPythonHome
    $env:PYTHONPATH = $previousPythonPath
}
if ($LASTEXITCODE -ne 0) {
    if ($Stop) { throw 'The calculation window did not close. See the message above.' }
    throw 'The calculation window did not start. See the message above.'
}

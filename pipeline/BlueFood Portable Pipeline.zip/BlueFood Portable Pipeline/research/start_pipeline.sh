#!/usr/bin/env sh
set -eu
pipeline_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
. "$pipeline_dir/miniforge_posix.sh"
miniforge_root=$(select_miniforge_root)
unset PYTHONPATH PYTHONHOME
export BLUEFOOD_MINIFORGE_ROOT="$miniforge_root" PYTHONNOUSERSITE=1
exec "$miniforge_root/bin/python" "$pipeline_dir/launch.py" "$@"

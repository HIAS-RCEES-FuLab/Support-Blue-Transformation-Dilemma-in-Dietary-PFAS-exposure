"""Machine-local configuration; scientific inputs remain in the source bundle."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import sys
from certificate_trust import certificate_bundle, certificate_environment, certificate_tools

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = Path(os.environ.get('BLUEFOOD_CONFIG', ROOT / 'bluefood.json')).expanduser()
if not CONFIG_PATH.is_absolute():
    CONFIG_PATH = ROOT / CONFIG_PATH
CONFIG = json.loads(CONFIG_PATH.read_text(encoding='utf-8-sig')) if CONFIG_PATH.exists() else {}
if not isinstance(CONFIG, dict):
    raise ValueError('bluefood.json must contain a JSON object')
unknown = set(CONFIG) - {'workspace', 'assets_dir', 'asset_manifest', 'rscript', 'r_library', 'port', 'max_workers', 'python', 'miniforge_root', 'ca_bundle'}
if unknown:
    raise ValueError('Unknown configuration setting: ' + ', '.join(sorted(unknown)))

def configured_path(key, env, default):
    value = os.environ.get(env) or CONFIG.get(key) or default
    path = Path(os.path.expandvars(str(value))).expanduser()
    return (ROOT / path).resolve() if not path.is_absolute() else path.resolve()

ASSETS = configured_path('assets_dir', 'BLUEFOOD_ASSETS', 'assets')
MANIFEST = configured_path('asset_manifest', 'BLUEFOOD_MANIFEST', 'ASSET_MANIFEST.json')
WORKSPACE = configured_path('workspace', 'BLUEFOOD_WORKSPACE', 'workspace')
if WORKSPACE == ROOT or ASSETS == WORKSPACE or ASSETS in WORKSPACE.parents:
    raise ValueError('Choose a separate workspace folder outside the input assets')
RUNS, CACHE, STATE, IMPORTS = (WORKSPACE / name for name in ('runs', 'cache', 'state', 'imports'))
R_LIBRARY = configured_path('r_library', 'BLUEFOOD_R_LIBRARY', WORKSPACE / 'Rlibrary')
PORT = int(os.environ.get('BLUEFOOD_PORT', CONFIG.get('port', 8765)))
if not 0 <= PORT <= 65535:
    raise ValueError('Port must be between 0 and 65535; use 0 to choose a free port')
INSTANCE_ID = hashlib.sha256((str(ROOT) + '\n' + str(WORKSPACE)).encode()).hexdigest()[:20]

def ensure_workspace():
    for folder in (RUNS, CACHE, STATE, IMPORTS, R_LIBRARY):
        folder.mkdir(parents=True, exist_ok=True)

def asset_file(record):
    relative = Path(record['path'])
    relative = relative.relative_to('assets')
    path = (ASSETS / relative).resolve()
    path.relative_to(ASSETS)
    return path

def find_rscript(required=False):
    explicit = os.environ.get('BLUEFOOD_RSCRIPT') or CONFIG.get('rscript')
    candidates = []
    if explicit:
        located = shutil.which(str(explicit))
        candidates.append(Path(located) if located else configured_path('rscript', 'BLUEFOOD_RSCRIPT', explicit))
    else:
        located = shutil.which('Rscript')
        if located:
            located = Path(located)
            candidates.extend([located.parent/'x64/Rscript.exe', located.parent.parent/'Lib/R/bin/x64/Rscript.exe', located])
        for prefix in (Path(sys.prefix), ROOT / '.environment', ROOT / '.tools/R'):
            candidates.extend(prefix / item for item in ('bin/Rscript', 'Lib/R/bin/x64/Rscript.exe', 'Lib/R/bin/Rscript.exe', 'bin/Rscript.exe', 'Scripts/Rscript.exe', 'Library/bin/Rscript.exe'))
        if os.environ.get('R_HOME'):
            candidates.extend(Path(os.environ['R_HOME']) / 'bin' / name for name in ('Rscript', 'Rscript.exe'))
        if os.name == 'nt':
            try:
                import winreg
                for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                    for key_name in (r'Software\R-core\R', r'Software\R-core\R64'):
                        try:
                            with winreg.OpenKey(hive, key_name) as key:
                                candidates.append(Path(winreg.QueryValueEx(key, 'InstallPath')[0]) / 'bin/Rscript.exe')
                        except OSError:
                            pass
            except ImportError:
                pass
            for env, suffix in (('ProgramFiles', 'R'), ('LOCALAPPDATA', 'Programs/R')):
                if os.environ.get(env):
                    parent = Path(os.environ[env]) / suffix
                    candidates.extend(sorted(parent.glob('R-*/bin/Rscript.exe'), reverse=True))
        elif sys.platform == 'darwin':
            candidates.append(Path('/Library/Frameworks/R.framework/Resources/bin/Rscript'))
    for candidate in candidates:
        if candidate.is_file() and (os.name == 'nt' or os.access(candidate, os.X_OK)):
            return candidate.resolve()
    if required:
        raise FileNotFoundError('Rscript was not found. Run Setup Environment again, or set rscript in bluefood.json to your Rscript executable.')
    return None

def resource_limits():
    cpus = max(1, os.cpu_count() or 1)
    total = available = None
    try:
        import psutil
        memory = psutil.virtual_memory()
        total, available = memory.total, memory.available
    except ImportError:
        pass
    memory_limit = max(1, int(total / (3 * 1024**3))) if total else 1
    cap = min(cpus, memory_limit)
    requested = os.environ.get('BLUEFOOD_MAX_WORKERS') or CONFIG.get('max_workers')
    if requested is not None:
        if isinstance(requested, bool) or int(requested) < 1:
            raise ValueError('max_workers must be a positive integer')
        cap = min(cpus, int(requested))
    default = min(cap, max(1, int(available / (3 * 1024**3)))) if available else 1
    return {'cpu_count': cpus, 'memory_gib': round(total / 1024**3, 1) if total else None,
            'max_workers': cap, 'default_workers': default}

def r_environment(executable=None):
    executable = executable or find_rscript(required=True)
    bundle, _ = certificate_bundle(sys.prefix, CONFIG.get('ca_bundle'))
    env = certificate_tools(certificate_environment(os.environ.copy(), bundle), sys.prefix)
    env['BLUEFOOD_R_LIBRARY'] = str(R_LIBRARY)
    if os.name == 'nt':
        # POSIX locale names inherited from a launcher are invalid in Windows R.
        for name in ('LANG','LC_ALL','LC_CTYPE','LC_COLLATE','LC_MONETARY','LC_TIME'):
            env.pop(name,None)
        env['LC_CTYPE']='English_United States.UTF-8'
    for candidate in executable.parents:
        if (candidate / 'etc').is_dir() and (candidate / 'library/base/DESCRIPTION').is_file():
            env['R_HOME'] = str(candidate)
            break
    folders = [Path(sys.prefix), Path(sys.prefix) / 'Library/bin', executable.parent]
    env['PATH'] = os.pathsep.join(str(p) for p in folders if p.exists()) + os.pathsep + env.get('PATH', '')
    return env

def environment_signature():
    versions = {}
    for name in ('numpy', 'pandas', 'scipy', 'scikit-learn', 'econml', 'torch', 'joblib', 'shap', 'numba'):
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = 'not installed'
    return {'python': platform.python_version(), 'system': platform.system(), 'machine': platform.machine(), 'packages': versions}

@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0research\Setup Environment.ps1" %*
if errorlevel 1 pause

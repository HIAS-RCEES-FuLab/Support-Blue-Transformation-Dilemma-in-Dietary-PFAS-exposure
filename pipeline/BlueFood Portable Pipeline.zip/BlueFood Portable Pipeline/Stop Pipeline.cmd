@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0research\Start Pipeline.ps1" -Stop %*
if errorlevel 1 pause

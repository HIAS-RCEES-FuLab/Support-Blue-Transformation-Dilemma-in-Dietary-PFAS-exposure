# -*- coding: utf-8 -*-
"""
Created on Wed Apr  9 13:51:27 2025

this file aimed to compute the food demand till 2050
@author: Admin
1. compute the elaticity for each food type/country
2. model the elaticity by coverging it to 0.4 till 2050
3. compute the demand
"""

D_pop2050 = {'Argentina':52459076,
'Australia':32182606,
'Austria':	8995574,
'Belgium':	12132032,
'Brazil':	230885725,
'Bulgaria':	4985789,
'Canada':	46752256,
'Chile':	20675378,
'China':	1290240256,
'Colombia':	56987651,
'Costa Rica':	5702525,
'Croatia'	:3190718,
'Czechia':	10899003,
'Denmark':	6444416,
'Estonia':	1207679,
'Finland':	5471409,
'France'	:68680064,
'Germany':	79249960,
'Greece':	9103500,
'Hungary':	8418599,
'Iceland':	425291,
'India':1670490596,
'Indonesia':	317225213,
'Ireland':	5905610,
'Israel':	13721822,
'Italy':	51632796,
'Japan'	:104636408,
'Korea':	44986800,
'Latvia':	1479032,
'Lithuania':	2317540,
'Luxembourg':	788551,
'Mexico':	143772364,
'Netherlands':	18020858,
'New Zealand':	5897603,
'Norway':	6371574,
'Poland':	31472578,
'Portugal':	9437329,
'Romania':	16831136,
'Slovak Republic':	4902988,
'Slovenia':	1990098,
'South Africa':	73529753,
'Spain':	44513132,
'Sweden':	11767838,
'Switzerland':	9709108,
'Turkiye':	94999240,
'United Kingdom':	71819576,
'United States':	367795232
}
import sys
sys.path.append('./')
import read_file as dataset
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit
import pandas as pd
import math
import copy

def alinedata(L_Dict, L_country):
    def get_common_year(L_Dict, country):
        year_new = np.arange(40)+1983
        for D in L_Dict:
            for key in D:
                if key == country or country in key:
                    year_record = D[key][0]
                    year_new = [year for year in year_record if year in year_new]
        year_new.sort()
        return [int(y) for y in year_new]
    def alineBYyear(L_Dict, D_common_year):
        L_dict_new = []
        for D in L_Dict:
            D_new = dict()
            for key in D:
                try:
                    if type(key) == str:
                        common_year = D_common_year[key]
                    else:
                        for subkey in key:
                            try:
                                common_year = D_common_year[subkey]
                                break
                            except KeyError:
                                pass
                    D_byyear = dict()
                    a,b = np.shape(D[key])
                    for i in range(b):
                        D_byyear[D[key][0,i]] = D[key][1,i]
                    D_new[key] = np.array([ common_year, [D_byyear[y] for y in common_year] ])
                except KeyError:
                    pass
            L_dict_new.append(D_new)
        return L_dict_new
    D_common_year = dict()
    for country in L_country:
        D_common_year[country] = get_common_year(L_Dict, country)
    L_dict_new = alineBYyear(L_Dict, D_common_year)
    return L_dict_new
    
def add_totals(D_FAOfood, L_country, FAO_fooditem):
    for country in L_country:
        for food in FAO_fooditem:
            try:
                arr = D_FAOfood[country, food].copy()
            except KeyError:
                continue
            if food in ['Mutton & Goat Meat', 'Eggs', 'Meat, Other',  'Poultry Meat', 'Bovine Meat', 'Pigmeat']:
                try:
                    D_FAOfood[country, 'terri'][1] = D_FAOfood[country, 'terri'][1]+arr[1]
                except KeyError:
                    D_FAOfood[country, 'terri'] = arr
            elif food in ['Marine Fish, Other', 'Aquatic Animals, Others', 'Crustaceans', 'Pelagic Fish', 'Molluscs, Other',  'Freshwater Fish', 'Demersal Fish']:
                try:
                    D_FAOfood[country, 'blue'][1] = D_FAOfood[country, 'blue'][1]+arr[1]
                except KeyError:
                    D_FAOfood[country, 'blue'] = arr
            '''
            try:
                plt.scatter(D_FAOfood[country, 'terri'][0], D_FAOfood[country, 'terri'][1])
            except:
                pass
            try:
                plt.scatter(D_FAOfood[country, 'blue'][0], D_FAOfood[country, 'blue'][1])
            except:
                pass
            plt.title(food)
            plt.show()
            '''
        D_FAOfood[country, 'all'] = D_FAOfood[country, 'blue'] + D_FAOfood[country, 'terri']
        D_FAOfood[country, 'all'][0] = arr[0]
        
    return D_FAOfood


def elaticitybyreg(D_income, D_pop, D_FAOfood, country, food):
    def linear(x,a,b):
        return a*x + b

    def fit(model, income, demand):
        x = np.log(income)
        y = np.log(demand)
        parms = curve_fit(model, x, y)
        a,b = parms[0]
        #print(a,b)
        y_est = model(x,a,b)
        return a
    
    try:
        t = D_income[country][0]
        C_t = [x for x in D_FAOfood[country,food][1]]
        #plt.plot(t[:-1]+1, (np.array(C_t1)-np.array(C_t))/np.array(C_t))
        #plt.show()
        
        Y_t = [x for x in D_pop[country][1]]
        #plt.plot(t[:-1]+1, (np.array(Y_t1)-np.array(Y_t))/np.array(Y_t))
        #plt.show()
        
        G_t = [x for x in D_income[country][1]]
        #plt.plot(t[:-1]+1, (np.array(G_t1)-np.array(G_t))/np.array(G_t))
        #plt.show()
        a = min( len(G_t), len(C_t))
        #a = 5
        eph = fit(linear, np.array(G_t)[-a:],np.array(C_t)[-a:] )
        return eph
    except:
        print(country, food, 'has no data for eph')
        return None

def elaticitybytime(D_income, D_pop, D_FAOfood, country, food):
    Gs = [np.average(D_income[country][1,0:5]), np.average(D_income[country][1,-5:]) ]
    Cs = [np.average(D_FAOfood[country, food][1,0:5]), np.average(D_FAOfood[country, food][1,-5:]) ]
    #Ps = D_pop[country][1,[0,-1]]
    eph = (Cs[1] - Cs[0])/Cs[0]/((Gs[1] - Gs[0])/Gs[0])
    return round(eph, 4)
    
def get_eph(D_income, D_pop, D_FAOfood, L_country, FAO_fooditem, mode = 'reg', caliber=0.56):
    D_eph = dict()
    for country in L_country:
        if mode == 'reg':
            eph1 = elaticitybyreg(D_income, D_pop, D_FAOfood, country, 'all')
            eph2 = elaticitybyreg(D_income, D_pop, D_FAOfood, country, 'terri')
            eph3 = elaticitybyreg(D_income, D_pop, D_FAOfood, country, 'blue')
        else:
            eph1 = elaticitybytime(D_income, D_pop, D_FAOfood, country, 'all')
            eph2 = elaticitybytime(D_income, D_pop, D_FAOfood, country, 'terri')
            eph3 = elaticitybytime(D_income, D_pop, D_FAOfood, country, 'blue')+ caliber  #0.56 for business as usuall, - 0.1617 for low load average calib
        L_other_eph = []
        for food in ['Mutton & Goat Meat', 'Eggs', 'Meat, Other',  'Poultry Meat', 'Bovine Meat', 'Pigmeat'] + ['Marine Fish, Other', 'Aquatic Animals, Others', 'Crustaceans', 'Pelagic Fish', 'Molluscs, Other',  'Freshwater Fish', 'Demersal Fish']:
            L_other_eph.append(elaticitybytime(D_income, D_pop, D_FAOfood, country, food))
        print(country, round(eph1,3),round(eph2,3),round(eph3,3) )
        D_eph[country] = {'all':eph1, 'terri':eph2, 'blue':eph3, "other food":L_other_eph}
    return D_eph

def get_food_reg(income, income_0, consum_0, eph):
    return np.exp(eph*np.log(income/income_0) + np.log(consum_0))

def get_food_time(income, income_0, consum_0, eph):
    return (income-income_0)/income_0*eph*consum_0 + consum_0

def prepare_values(arr_income, arr_food):
    year_0, consum_0 = arr_food[:,-1]
    pred_income = arr_income[1,arr_income[0]>year_0]
    income_0 = arr_income[1,arr_income[0]==year_0]
    return pred_income, income_0, consum_0

def predict(D_income, D_FAOfood, D_eph, L_country, FAO_fooditem, mode='reg'):
    for country in L_country:
        # predict for 'all'
        income, income_0, consum_0 = prepare_values(D_income[country], D_FAOfood[country,'all'])
        if mode == 'reg':
            pred_food = get_food_reg(income, income_0, consum_0, D_eph[country]['all'])
        else:
            pred_food = get_food_time(income, income_0, consum_0, D_eph[country]['all'])
        D_FAOfood[country,'all'] = np.concatenate( [D_FAOfood[country,'all'], np.array([np.arange(D_FAOfood[country,'all'][0,-1]+1, 2051,1), pred_food])], axis=1)
        # predict for blue food and terri food
        income, income_0, consum_0 = prepare_values(D_income[country], D_FAOfood[country,'blue'])
        if mode == 'reg':
            pred_food = get_food_reg(income, income_0, consum_0, D_eph[country]['blue'])
        else:
            pred_food = get_food_time(income, income_0, consum_0, D_eph[country]['blue'])
        D_FAOfood[country,'blue'] = np.concatenate( [D_FAOfood[country,'blue'], np.array([np.arange(D_FAOfood[country,'blue'][0,-1]+1, 2051,1), pred_food])], axis=1)
        income, income_0, consum_0 = prepare_values(D_income[country], D_FAOfood[country,'terri'])
        if mode == 'reg':
            pred_food = get_food_reg(income, income_0, consum_0, D_eph[country]['terri'])
        else:
            pred_food = get_food_time(income, income_0, consum_0, D_eph[country]['terri'])
        D_FAOfood[country,'terri'] = np.concatenate( [D_FAOfood[country,'terri'], np.array([np.arange(D_FAOfood[country,'terri'][0,-1]+1, 2051,1), pred_food])], axis=1)
        k = 1/(D_FAOfood[country,'blue'][1]+D_FAOfood[country,'terri'][1])*D_FAOfood[country,'all'][1]
        # devide the food amount by ratio sum/'all'
        def predict_eachfood(food):
            income, income_0, consum_0 = prepare_values(D_income[country], D_FAOfood[country,food])
            if food in ['Mutton & Goat Meat', 'Eggs', 'Meat, Other', 'Poultry Meat', 'Bovine Meat', 'Pigmeat']:
                if mode == 'reg':
                    pred_food = get_food_reg(income, income_0, consum_0, D_eph[country]['blue'])
                else:
                    pred_food = get_food_time(income, income_0, consum_0, D_eph[country]['blue'])#blue food    
                pred_food = pred_food*k[-len(pred_food):]
            elif food in ['Aquatic Animals, Others', 'Crustaceans', 'Marine Fish, Other', 'Pelagic Fish', 'Molluscs, Other',  'Freshwater Fish', 'Demersal Fish']:
                if mode == 'reg':
                    pred_food = get_food_reg(income, income_0, consum_0, D_eph[country]['terri'])
                else:
                    pred_food = get_food_time(income, income_0, consum_0, D_eph[country]['terri'])#terri food
                pred_food = pred_food*k[-len(pred_food):]
            D_FAOfood[country,food] = np.concatenate( [D_FAOfood[country,food], np.array([np.arange(D_FAOfood[country,food][0,-1]+1, 2051,1), pred_food])], axis=1)
            return
        def calibrate():
            k_terris = D_FAOfood[country,'terri'][1]/np.sum( np.array([D_FAOfood[country,'Mutton & Goat Meat'][1],D_FAOfood[country,'Eggs'][1],
                                                                       D_FAOfood[country,'Meat, Other'][1],D_FAOfood[country,'Poultry Meat'][1],
                                                                       D_FAOfood[country,'Bovine Meat'][1],D_FAOfood[country,'Pigmeat'][1]]), axis=0)
            k_blues = D_FAOfood[country,'blue'][1]/np.sum( np.array([D_FAOfood[country,'Aquatic Animals, Others'][1],D_FAOfood[country,'Crustaceans'][1],
                                                                       D_FAOfood[country,'Marine Fish, Other'][1],D_FAOfood[country,'Pelagic Fish'][1],
                                                                       D_FAOfood[country,'Molluscs, Other'][1],D_FAOfood[country,'Freshwater Fish'][1],D_FAOfood[country,'Demersal Fish'][1]]), axis=0)
            for food in ['Mutton & Goat Meat', 'Eggs', 'Meat, Other',  'Poultry Meat', 'Bovine Meat', 'Pigmeat']:
                D_FAOfood[country,food][1] = D_FAOfood[country,food][1]*k_terris
            for food in ['Aquatic Animals, Others', 'Crustaceans', 'Marine Fish, Other', 'Pelagic Fish', 'Molluscs, Other',  'Freshwater Fish', 'Demersal Fish']:
                D_FAOfood[country,food][1] = D_FAOfood[country,food][1]*k_blues
            return
        for food in FAO_fooditem:
            #print(D_FAOfood[country, 'Mutton & Goat Meat'][1])
            if food not in ['all','blue','terri']:
                predict_eachfood(food)
            else:
                pass
        '''
        plt.plot( D_FAOfood[country, 'blue'][0], D_FAOfood[country, 'blue'][1] )
        plt.plot( D_FAOfood[country, 'terri'][0], D_FAOfood[country, 'terri'][1] )
        plt.title(food)
        plt.show()
        '''
        calibrate()
        
    return D_FAOfood

def save_D_eph(D_eph, path, filename):
    L_other_food = ['Mutton & Goat Meat', 'Eggs', 'Meat, Other',  'Poultry Meat', 'Bovine Meat', 'Pigmeat'] + ['Marine Fish, Other', 'Aquatic Animals, Others', 'Crustaceans', 'Pelagic Fish', 'Molluscs, Other',  'Freshwater Fish', 'Demersal Fish']
    D_save = {"country":[], "Aquatic":[], "Territorial":[]}
    for item in L_other_food:
        D_save[item] = []
    for country in D_eph:
        D_save['country'].append(country)
        D_save['Aquatic'].append(D_eph[country]['blue'])
        D_save['Territorial'].append(D_eph[country]['terri'])
        for i in range(len(L_other_food)):
            D_save[L_other_food[i]].append(D_eph[country]['other food'][i])
    df = pd.DataFrame(D_save)
    df.to_excel(path+filename)
    return
    
def policy_predict(D_income, D_FAOfood, D_eph, L_country, FAO_fooditem, mode='reg'):
    D_FAOfood = predict(D_income, D_FAOfood, D_eph, L_country, FAO_fooditem, mode=mode)
    for country in L_country:
        # force control 'blue' by increase additional meal
        add_ratio = np.array([max(x,0) for x in (D_FAOfood[country,'all'][0]-2022)/(2050-2022)*0.0507])
        add_amount = add_ratio*D_FAOfood[country,'all'][1]
        D_FAOfood[country,'blue'][1] = add_amount + D_FAOfood[country,'blue'][1]
        D_FAOfood[country,'terri'][1] = -add_amount + D_FAOfood[country,'terri'][1]
        # compute 'terri' for rest
        def calibrate():
            k_terris = D_FAOfood[country,'terri'][1]/np.sum( np.array([D_FAOfood[country,'Mutton & Goat Meat'][1],D_FAOfood[country,'Eggs'][1],
                                                                       D_FAOfood[country,'Meat, Other'][1],D_FAOfood[country,'Poultry Meat'][1],
                                                                       D_FAOfood[country,'Bovine Meat'][1],D_FAOfood[country,'Pigmeat'][1]]), axis=0)
            k_blues = D_FAOfood[country,'blue'][1]/np.sum( np.array([D_FAOfood[country,'Aquatic Animals, Others'][1],D_FAOfood[country,'Crustaceans'][1],
                                                                       D_FAOfood[country,'Marine Fish, Other'][1],D_FAOfood[country,'Pelagic Fish'][1],
                                                                       D_FAOfood[country,'Molluscs, Other'][1],D_FAOfood[country,'Freshwater Fish'][1],D_FAOfood[country,'Demersal Fish'][1]]), axis=0)
            for food in ['Mutton & Goat Meat', 'Eggs', 'Meat, Other',  'Poultry Meat', 'Bovine Meat', 'Pigmeat']:
                D_FAOfood[country,food][1] = D_FAOfood[country,food][1]*k_terris
            for food in ['Aquatic Animals, Others', 'Crustaceans', 'Marine Fish, Other', 'Pelagic Fish', 'Molluscs, Other',  'Freshwater Fish', 'Demersal Fish']:
                D_FAOfood[country,food][1] = D_FAOfood[country,food][1]*k_blues
            return
        calibrate()
    return D_FAOfood

TERRI_FOODS = [
    'Mutton & Goat Meat', 'Eggs', 'Meat, Other',
    'Poultry Meat', 'Bovine Meat', 'Pigmeat'
]

BLUE_FOODS = [
    'Marine Fish, Other', 'Aquatic Animals, Others', 'Crustaceans',
    'Pelagic Fish', 'Molluscs, Other', 'Freshwater Fish', 'Demersal Fish'
]


def patch_lowroad_total_as_bau_keep_blue(
        D_lowroad,
        D_bau,
        L_country,
        terri_foods=TERRI_FOODS,
        blue_foods=BLUE_FOODS
):
    """
    Patch low-road projection so that:
        lowroad all animal-sourced food = BAU all animal-sourced food
        lowroad blue food = original low-road blue food
        lowroad terrestrial food = BAU all - original low-road blue food

    Blue food subcategories are kept unchanged.
    Terrestrial food subcategories are rescaled proportionally.
    """

    D_patched = copy.deepcopy(D_lowroad)

    for country in L_country:

        # Keep the original low-road blue food unchanged
        low_blue = D_patched[country, 'blue'][1].copy()

        # Use BAU total animal-sourced food as the target total
        bau_all = D_bau[country, 'all'][1].copy()

        # New terrestrial food is the residual
        new_terri = bau_all - low_blue

        # Avoid negative terrestrial values
        # If this warning appears, blue food exceeds BAU total in that country/year.
        if np.any(new_terri < 0):
            print(
                f'Warning: negative terrestrial residual in {country}. '
                'Values were clipped to zero.'
            )
            new_terri = np.maximum(new_terri, 0)

        # Patch aggregate groups
        D_patched[country, 'all'][1] = bau_all
        D_patched[country, 'blue'][1] = low_blue
        D_patched[country, 'terri'][1] = new_terri

        # Rescale terrestrial sub-foods proportionally
        terri_sum = np.sum(
            np.array([D_patched[country, food][1] for food in terri_foods]),
            axis=0
        )

        k_terri = np.divide(
            new_terri,
            terri_sum,
            out=np.zeros_like(new_terri, dtype=float),
            where=terri_sum != 0
        )

        for food in terri_foods:
            D_patched[country, food][1] = D_patched[country, food][1] * k_terri

        # Blue sub-foods are intentionally not rescaled,
        # because total blue food should remain exactly as in low road.

    return D_patched

def main():
    D_income, D_pop, D_FAOfood, L_country, FAO_fooditem = dataset.read_all_data()
    #D_income = {country: array(years, incomes)}
    #D_pop = {country: array(years, populations)}
    #D_FAOfood = {country, food: array(years, amount (kg/yr/cap) )}
    #print(D_income['Slovak Republic'])
    FAO_fooditem = ['Mutton & Goat Meat', 'Eggs', 'Meat, Other', 'Marine Fish, Other', 'Poultry Meat', 'Bovine Meat', 'Pigmeat',
                    'Aquatic Animals, Others', 'Crustaceans', 'Pelagic Fish', 'Molluscs, Other',  'Freshwater Fish', 'Demersal Fish']
    L_Dict = [D_income, D_FAOfood]
    L_Dict_exp = alinedata(L_Dict, L_country)
    D_income_exp, D_FAOfood = L_Dict_exp
    D_FAOfood = add_totals(D_FAOfood, L_country, FAO_fooditem)
    D_eph = get_eph(D_income, D_pop, D_FAOfood, L_country, FAO_fooditem, mode='time')
    
    path = 'G:/projects/BLUE FOOD/food estimation till 2050/'
    foodfile = 'food projection 2050 (high road).xlsx'
    #filename = 'price elasticity.xlsx'
    #save_D_eph(D_eph, path, filename)
    
    #print(D_eph)
    #FAO_fooditem = ['Mutton & Goat Meat']
    #D_FAOfood_pred = predict(D_income, D_FAOfood, D_eph, L_country, FAO_fooditem, mode='time')
    D_FAOfood_pred = policy_predict(D_income, D_FAOfood, D_eph, L_country, FAO_fooditem, mode='time')
    arr = np.array([D_FAOfood_pred[c, 'blue'][1,-1]*D_pop2050[c]*0.000000001 for c in L_country])
    print('total', round( np.sum(arr),2,), "ave", round( np.sum(arr)/np.sum(np.array([D_pop2050[c]*0.000000001 for c in L_country])),2,))
    path = 'H:/projects/BLUE FOOD/food estimation till 2050/'
    dataset.save_countryitemvalue(D_FAOfood_pred, foodfile, path)
    
    D_eph = get_eph(D_income, D_pop, D_FAOfood, L_country, FAO_fooditem, mode='time', caliber = 0.56)
    D_FAOfood_bau = predict(D_income, D_FAOfood, D_eph, L_country, FAO_fooditem, mode='time')
    arr = np.array([D_FAOfood_bau[c, 'blue'][1,-1]*D_pop2050[c]*0.000000001 for c in L_country])
    print('total', round( np.sum(arr),2,), "ave", round( np.sum(arr)/np.sum(np.array([D_pop2050[c]*0.000000001 for c in L_country])),2,))
    foodfile = 'food projection 2050 (business as usuall).xlsx'
    dataset.save_countryitemvalue(D_FAOfood_bau, foodfile, path)
    
    D_eph = get_eph(D_income, D_pop, D_FAOfood, L_country, FAO_fooditem, mode='time', caliber = -0.1617)
    D_FAOfood_lowroad  = predict(D_income, D_FAOfood, D_eph, L_country, FAO_fooditem, mode='time')
    arr = np.array([D_FAOfood_lowroad [c, 'blue'][1,-1]*D_pop2050[c]*0.000000001 for c in L_country])
    print('total', round( np.sum(arr),2,), "ave", round( np.sum(arr)/np.sum(np.array([D_pop2050[c]*0.000000001 for c in L_country])),2,))
    
    D_FAOfood_lowroad_patched = patch_lowroad_total_as_bau_keep_blue( D_lowroad=D_FAOfood_lowroad, D_bau=D_FAOfood_bau, L_country=L_country)
    foodfile = 'food projection 2050 (low road).xlsx'
    dataset.save_countryitemvalue(D_FAOfood_lowroad_patched, foodfile, path)
    return

main()
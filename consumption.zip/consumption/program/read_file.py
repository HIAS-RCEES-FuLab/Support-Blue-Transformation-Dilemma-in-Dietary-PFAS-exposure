# -*- coding: utf-8 -*-
"""
Created on Wed Sep 18 16:34:26 2024
clean data
@author: Admin
"""

import pandas as pd
import csv
import numpy as np

def float_year(L_pair):
    L_linear = [[],[]]
    for pair in L_pair:
        try:
            Value = float(pair[1])
            if not np.isnan(Value):
                L_linear[0].append(pair[0])
                L_linear[1].append(Value)
        except ValueError:
            pass
    return np.array(L_linear)

def read_WBdata(path, filename):
    df = pd.read_excel(path+filename)
    L_country = df['Country Name']
    L_countrycode = df['Country Code']
    D_countryincome = dict()
    for col in df.columns:
        try:
            year = int(col)
            for i in range(len(df[col])):
                try:
                    D_countryincome[L_country[i]].append([year, df[col][i]])
                except KeyError:
                    D_countryincome[L_country[i]] = [[year, df[col][i]]]
            
        except ValueError:
            pass
    
    for i in range(len(L_country)):
        country = L_country[i]
        D_countryincome[country] = float_year(D_countryincome[country])
        if len( D_countryincome[country][0] ) < 5:
            # delete the years which has little
            del( D_countryincome[country] )
            L_countrycode.pop(i)
    
    return D_countryincome, [country for country in D_countryincome], L_countrycode

def read_FAOdata(path, L_file):
    D_FAOfood = dict()
    D_pop = dict()
    L_country = set()
    L_fooditem = set()
    for filename in L_file:
        with open(path+filename, mode='r', encoding='utf-8-sig') as file:
            data = csv.reader(file)
            head = True
            for line in data:
                if head:
                    head = False
                else:
                    #Domain Code	Domain	Area Code (M49)	Area	Element Code	Element	Item Code (FBS)	Item	Year Code	Year	Unit	Value	Flag	Flag Description	Note
                    Area = line[3]
                    Element = line[5]
                    Item = line[7]
                    Year = int(line[9])
                    Value = float(line[11])
                    L_country.add(Area)
                    if Element == 'Total Population - Both sexes':
                        try:
                            D_pop[Area].append([Year, Value])
                        except KeyError:
                            D_pop[Area] = [[Year, Value]]
                    elif Element == 'Food supply quantity (kg/capita/yr)':
                        try:
                            D_FAOfood[Area,Item].append([Year, Value])
                        except KeyError:
                            D_FAOfood[Area,Item] = [[Year, Value]]
                            L_fooditem.add(Item)
        #may have repetitive years
    for Area in D_pop:
        D_pop[Area] = float_year(D_pop[Area])
    for key in D_FAOfood:
        D_FAOfood[key] = float_year(D_FAOfood[key])
    
    return D_pop, D_FAOfood, list(L_country), list(L_fooditem)

def read_OCED_GDP(path, filename):
    #csv file
    D_GDP = dict()
    L_country = []
    with open(path+filename, mode='r', encoding='utf-8-sig') as file:
        data = csv.reader(file)
        head = True
        for line in data:
            if head:
                head = False
            else:
                country = line[5]
                year = int(line[12])
                value = float(line[14])
                try:
                    D_GDP[country].append([year, value])
                except KeyError:
                    D_GDP[country] = [[year, value]]
                    if country not in L_country:
                        L_country.append(country)
                        
    for country in D_GDP:
        D_GDP[country] = float_year(D_GDP[country])
    return D_GDP, L_country

def read_translation(path, filename):
    D_FAO = dict()
    D_WB = dict()
    L_country = set()
    with open(path+filename, mode='r', encoding='utf-8-sig') as file:
        data = csv.reader(file)
        head = True
        for line in data:
            if head:
                head = False
            else:
                if line[0] != '' and line[1] != '' and line[2] != '':
                    D_FAO[line[1]] = line[0]
                    D_WB[line[2]] = line[0]
                    L_country.add(line[0])
    return D_FAO, D_WB, list(L_country)

def L_union(L1, L2):
    return [x for x in L1 if x in L2]

def L_difference(L1, L2):
    union = L_union(L1, L2)
    return [x for x in L1 if x not in union], [x for x in L2 if x not in union]

def cleanarr(arr):
    def takefirst(l):
        return l[0]
    D_yearvalue = dict()
    a,b = np.shape(arr)
    for i in range(b):
        year = arr[0,i]
        value = arr[1,i]
        try:
            D_yearvalue[year].append(value)
        except KeyError:
            D_yearvalue[year] = [value]
    arr_new = []
    for year in D_yearvalue:
        arr_new.append([year, D_yearvalue[year][-1]])
    arr_new.sort(key=takefirst, reverse=False)
    return np.array(arr_new).T

def save_translation(L_heterocountry, path):
        N = max(len(L_heterocountry[0]), len(L_heterocountry[1]))
        while len(L_heterocountry[0]) < N:
            L_heterocountry[0].append('')
        while len(L_heterocountry[1]) < N:
            L_heterocountry[1].append('')
        df = pd.DataFrame({'FAO country':L_heterocountry[0],
                           'Income country': L_heterocountry[1]})
        df.to_excel(path+'FAO-Income country translation.xlsx')
        return

def aline_year(D1, D2, mode = '1D'):
    L1 = [key1 for key1 in D1]
    L2 = [key2 for key2 in D2]
    L_country = L_union(L1, L2)
    D1_new = dict()
    D2_new = dict()
    for country in L_country:
        L_year = L_union([y for y in D1[country][0]], [y for y in D2[country][0]])
        L_year.sort()
        D_a = dict()
        for i in range(len(D1[country][0])):
            D_a [ D1[country][0,i] ]= D1[country][1,i]
        D_b = dict()
        for i in range(len(D2[country][0])):
            D_b [ D2[country][0,i] ]= D2[country][1,i]
        L_a = [D_a[year] for year in L_year]
        L_b = [D_b[year] for year in L_year]
        D1_new[country] = np.array([L_year, L_a])
        D2_new[country] = np.array([L_year, L_b])
    return D1_new, D2_new
        
def get_income(D_pop, D_GDP, pop_country, GDP_country, D_trans_pop, D_trans_GDP):
    L_heterocountry = L_difference(pop_country, GDP_country)
    for c in L_heterocountry[0]:
        try:
            D_pop[D_trans_pop[c]] = np.concatenate((D_pop[D_trans_pop[c]], D_pop[c]), axis=1)
        except KeyError:
            try:
                D_pop[D_trans_pop[c]] = D_pop[c]
            except KeyError:
                pass
    for c in L_heterocountry[1]:
        try:
            D_GDP[D_trans_GDP[c]] = np.concatenate((D_GDP[D_trans_GDP[c]], D_GDP[c]), axis=1)
        except KeyError:
            try:
                D_GDP[D_trans_GDP[c]] = D_GDP[c]
            except KeyError:
                pass
    for dictionery in [D_pop, D_GDP]:
        for item in dictionery:
            dictionery[item] = cleanarr(dictionery[item])
    D_pop, D_GDP = aline_year(D_pop, D_GDP)
    D_income = dict()
    L_country = set()
    for country in D_pop:
        D_income[country] = np.array( [D_pop[country][0], (D_GDP[country][1]/D_pop[country][1])] )
        L_country.add(country)
    return D_income, list(L_country), D_pop, D_GDP
    
    
def read_all_data():
    
    path = '../raw data/'
    WBdatafile = 'WorldBank population projection -2050.xlsx'
    D_WBpop, WB_country, WB_countrycode = read_WBdata(path, WBdatafile)
    
    L_FAOfile = ['FAOSTAT_data_en_9-18-2024 food and pop 2010-.csv','FAOSTAT_data_en_9-18-2024 food and pop -2013.csv']
    D_FAOpop, D_FAOfood, FAO_country, FAO_fooditem = read_FAOdata(path, L_FAOfile)
    
    # read GDP and find income
    OCED_GDPfile = 'OCED baseline GDP projection -2050.csv' #energytrans
    D_GDP, OCED_country = read_OCED_GDP(path, OCED_GDPfile)
    
    transltionfile = 'OCED-WB country translation.csv'
    D_trans_OCED, D_trans_WB, L_country_add = read_translation(path, transltionfile)
    
    D_income, income_country, D_pop, D_GDP = get_income(D_WBpop, D_GDP, WB_country, OCED_country, D_trans_WB, D_trans_OCED)
    
    # add food info
    transltionfile = 'FAO-Income country translation.csv'
    D_trans_FAO, D_trans_income, L_country_add = read_translation(path, transltionfile)
    
    L_intersectcountry = L_union(FAO_country, income_country)
    L_heterocountry = L_difference(FAO_country, income_country)
    #L_heterocountry = [FAO_country,WB_country]
    #save_translation(L_heterocountry, path)
    
    for FAOcountry in L_heterocountry[0]:
        try:
            L_pair = [pair for pair in D_FAOfood]
            for pair in L_pair:
                if FAOcountry in pair:
                    D_FAOfood[ D_trans_FAO[FAOcountry], pair[1] ] = np.concatenate((D_FAOfood[ D_trans_FAO[FAOcountry], pair[1] ], D_FAOfood[pair]) , axis=1)
            
        except KeyError:
            try:
                L_pair = [pair for pair in D_FAOfood]
                for pair in L_pair:
                    if FAOcountry in pair:
                        D_FAOfood[ D_trans_FAO[FAOcountry], pair[1] ] = D_FAOfood[pair]
            except KeyError:
                pass
            
    for Incomecountry in L_heterocountry[1]:
        try:
            D_income[D_trans_income[Incomecountry]] = np.concatenate((D_income[D_trans_income[Incomecountry]], D_income[Incomecountry]), axis=1)
        except KeyError:
            try:
                D_income[D_trans_income[Incomecountry]] = D_income[Incomecountry]
            except KeyError:
                pass
            
    L_country = L_intersectcountry+L_country_add
    #L_country.sort() 
    for dictionery in [D_income, D_pop, D_FAOfood]:
        for item in dictionery:
            dictionery[item] = cleanarr(dictionery[item])
    
    return D_income, D_pop, D_FAOfood, L_country, FAO_fooditem

#D_income, D_pop, D_FAOfood, L_country, FAO_fooditem = read_all_data()
def save_countryvalue(D, filename, path):
    with open(path+filename, mode='w', newline='') as file:
        data = csv.writer(file)
        headline = ['country','year','value']
        data.writerow(headline)
        for item in D:
            arr = D[item].T
            for pair in arr:
                line = [item, pair[0], pair[1]]
                data.writerow(line)
        
    return

def save_countryitemvalue(D, filename, path):
    D_file = {'country':[],'food':[],'year':[],'value':[]}
    for item in D:
        arr = D[item].T
        for pair in arr:
            D_file['country'].append(item[0])
            D_file['food'].append(item[1])
            D_file['year'].append(pair[0])
            D_file['value'].append(pair[1])
    df = pd.DataFrame(D_file)
    df.to_excel(path+filename)
    return

# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import codecs
import re
import csv
import numpy as np
import scipy.stats as stat
import scipy
import statistics as stats
import random
import os
import matplotlib.pyplot as plt
from pyecharts import options as opts
from pyecharts.charts import Map
import math
import pandas as pd
from scipy.stats import gmean
from scipy.stats import ttest_ind
import pwlf
from sklearn.metrics import r2_score, mean_absolute_error

D_contaminatedregion = ['US,Mississippi River(MR 11)',
                        'China,Xiaoqing River',
                        #'France,Loire River/France,North Atlantic',
                        'Canada,Etobicoke Creek River/Lake Ontario',
                        'China,Lake Baiyangdian',
                        #'South Africa,Vaal River',
                        #'Canada,Arctric Lakes',
                        #'Austria/Belgium/Cyprus/Czech/France/German/Greece/Ireland/Italy/Norway/Slovenia/Spain/UK',
                        #'China,South China Sea/China,Pearl River',
                        'Netherlands(village market)',
                        'US,Mississippi River(2008 hotsite)',
                        #'US,Mississippi River',
                        #'Denmark,North Sea/Denmark,Baltic Sea',
                        'Spain,Ebro river',
                        #'Norway,Norwegian Sea',
                        #'US,Lake Ontario',
                        #'Canada,Lake Ontario',
                        #'France,Loire River/France,Rhone River/France,Seine River/France,Garonne River/France,Dorgogne River/France,Rhine River',
                        #'US,Lake Michigan',
                        'US,Lake Little Pine',
                        #'US,Lake Erie',
                        'China(Lake Baiyangdian)',
                        #'Canada,Binbrook Reservoir',
                        'Canada,Welland Canal'
                        ]

def read_PollInFood(path, filename):
    '''
    Pollutant Name/ PollutantName.ABB/ Sample Type/ Sample Fish Type/ Sample Region/ Sample Size/ 0-5
    Sample Name/ Sampling Time/ Site/ Mean(ng/g)/ Median(ng/g)/ Data Type/ SD/ 6-12
    Max/ Min/ LOD(ng/g)/ LOQ(ng/g)
    '''
    D_trans = read_datatrans(path, 'aq and lip fraction.csv')
    D_pollutant_distribution = dict()
    D_summary_pollutants = dict()
    L_sites = set()
    L_pollutant = set()
    with open(path+filename, mode='r', encoding='utf-8-sig', errors='ignore') as file:
        data = csv.reader(file)
        headline = True
        ind_line = 0
        for line in data:
            ind_line = 1 +ind_line
            #print(ind_line)
            if headline:
                headline = False
            else:
                # loading data
                SampleTPs = []
                if line[8] not in D_contaminatedregion:
                    L_Site = line[8].split('/')
                    #pollname = re.sub('\xa0','',line[0])
                    if '{' in line[1]:
                        PollABB = line[1].split('{')[0]
                    else:
                        PollABB = line[1]
                    L_years = get_years(line[7])
                    for year in L_years:
                        SampleName = line[6]
                        Mean = line[9]
                        Mid = line[10]
                        DataTP = line[11]
                        SD = line[12]
                        Min = line[14]
                        Max = line[13]
                        LOD = line[15]
                        LOQ = line[16]
                        thLOD = 0.1*2
                        try:
                            if float(LOD) >= thLOD:
                                continue
                        except ValueError:
                            pass
                        try:
                            if float(LOQ) >= thLOD*3.3:
                                continue
                        except ValueError:
                            pass
                        if '/' not in line[2]:
                            SampleSize = int(line[5])
                            SampleTP = line[2]
                            if SampleTP == 'Fishery Product':
                                Sample_fishTP = line[3]
                                fish_region = line[4]
                            #
                            #check data
                            r, ind1, ind2, Distri, SampleSize = check_data(SampleTP, DataTP, Mean, Mid, SD, Min, Max, LOD, LOQ, SampleSize, D_trans)
                            if SampleTP == 'Fishery Product':
                                if Sample_fishTP == 'Marine/FreshWater' or Sample_fishTP == 'Marine,FreshWater':
                                    SampleTPs = [tuple(['Marine',fish_region]), tuple(['FreshWater',''])]
                                else:
                                    SampleTP = tuple([Sample_fishTP,fish_region])
                            if len(SampleTPs)==0:
                                SampleTPs = [SampleTP]
                            for Site in L_Site:
                                for SampleTP in SampleTPs:
                                    try:
                                        D_pollutant_distribution[year, PollABB, SampleTP, SampleName].append([Distri, ind1, ind2, SampleSize, r])
                                    except KeyError:
                                        D_pollutant_distribution[year, PollABB, SampleTP, SampleName] = [[Distri, ind1, ind2, SampleSize, r]]
                                    try:
                                        D_summary_pollutants[Site].append( [PollABB, SampleTP, SampleName] )
                                    except KeyError:
                                        D_summary_pollutants[Site] = [[PollABB, SampleTP, SampleName]]
                                    L_sites.add(Site)
                                    L_pollutant.add(PollABB)
                        else:
                            L_SampleTP = line[2].split('/')
                            L_SampleSize = line[5].split('/')
                            L_SampleSize = [int(n) for n in L_SampleSize]
                            #has several ints in a list
                            
                            if len(L_SampleTP)==len(L_SampleSize):
                                for i in range(len(L_SampleTP)):
                                    SampleTPs = []
                                    if L_SampleTP[i] == 'Fishery Product':
                                        Sample_fishTP = line[3]
                                        fish_region = line[4]
                                        if Sample_fishTP == 'Marine/FreshWater' or Sample_fishTP == 'Marine,FreshWater':
                                            SampleTPs = [tuple(['Marine',fish_region]), tuple(['FreshWater',''])]
                                        else:
                                            SampleTP = tuple([Sample_fishTP,fish_region])
                                        
                                    else:
                                        SampleTP =L_SampleTP[i]
                                    if len(SampleTPs)==0:
                                        SampleTPs = [SampleTP]
                                    r, ind1, ind2, Distri, SampleSize = check_data(SampleTP, DataTP, Mean, Mid, SD, Min, Max, LOD, LOQ, L_SampleSize[i], D_trans)
                                    for Site in L_Site:
                                        for SampleTP in SampleTPs:
                                            try:
                                                D_pollutant_distribution[year, PollABB, SampleTP, SampleName].append([Distri, ind1, ind2, SampleSize, r])
                                            except KeyError:
                                                D_pollutant_distribution[year, PollABB, SampleTP, SampleName] = [[Distri, ind1, ind2, SampleSize, r]]
                                            try:
                                                D_summary_pollutants[year].append( [PollABB, SampleTP, SampleName, Site] )
                                            except KeyError:
                                                D_summary_pollutants[year] = [[PollABB, SampleTP, SampleName, Site]]
                                            L_sites.add(Site)
                                            L_pollutant.add(PollABB)
                            else:
                                #print('lenSampleTP is not lenSampleSize:', len(L_SampleTP), len(L_SampleSize))
                                for i in range(len(L_SampleTP)):
                                    SampleTPs = []
                                    if L_SampleTP[i] == 'Fishery Product':
                                        Sample_fishTP = line[3]
                                        fish_region = line[4]
                                        if Sample_fishTP == 'Marine/FreshWater' or Sample_fishTP == 'Marine,FreshWater':
                                            SampleTPs = [tuple(['Marine',fish_region]), tuple(['FreshWater',''])]
                                        else:
                                            SampleTP = tuple([Sample_fishTP,fish_region])
                                    else:
                                        SampleTP = L_SampleTP[i]
                                    if len(SampleTPs)==0:
                                        SampleTPs = [SampleTP]
                                    r, ind1, ind2, Distri, SampleSize = check_data(L_SampleTP[i], DataTP, Mean, Mid, SD, Min, Max, LOD, LOQ, 1, D_trans)
                                    for Site in L_Site:
                                        for SampleTP in SampleTPs:
                                            try:
                                                D_pollutant_distribution[year, PollABB, SampleTP, SampleName].append([Distri, ind1, ind2, SampleSize, r])
                                            except KeyError:
                                                D_pollutant_distribution[year, PollABB, SampleTP, SampleName] = [[Distri, ind1, ind2, SampleSize, r]]
                                            try:
                                                D_summary_pollutants[year].append( [PollABB, SampleTP, SampleName, Site] )
                                            except KeyError:
                                                D_summary_pollutants[year] = [[PollABB, SampleTP, SampleName, Site]]
                                            L_sites.add(Site)
                                            L_pollutant.add(PollABB)
                        #if year == 2014 and PollABB=='PFDA' and SampleTP in ['Pork', 'Beef', 'Meat, Other', 'Mutton', 'Egg', 'Poultry'] and Distri in ['Uniform','Normal', 'LogNormal']:
                        #    print(PollABB, SampleTP, SampleName, Distri, ind1, ind2, SampleSize, r, Site)
                else:
                    pass #print(line[7],line[8])
                        
    return D_pollutant_distribution, D_summary_pollutants, list(L_sites), list(L_pollutant)

def get_years(L_years):
    if '/' in L_years:
        Ys = L_years.split('/')
    elif L_years == '':
        return [9999]
    else:
        Ys = [L_years]
    Y_ = []
    for Y in Ys:
        try:
            Y_ = Y_ + [y for y in range(int(Y.split('-')[0]), int(Y.split('-')[1]), 1)]
        except:
            Y_ = Y_ + [int(y) for y in Y.split('-')]
    return Y_

def read_datatrans(path, filename):
    '''
    read the file for lipid/dry weight/water weight in different type of food
    '''
    D_trans = dict()
    with open(path + filename, mode='r', encoding='UTF-8-sig') as file:
        data = csv.reader(file)
        head = True
        for line in data:
            if head:
                head = False
            else:
                D_trans[line[0], 'aq'] = float(line[1])
                D_trans[line[0], 'lip'] = float(line[2])
    return D_trans

def check_data(SampleTP, DataTP, Mean, Mid, SD, Min, Max, LOD, LOQ, n, D_trans):
    #print(Mean, SD)
    '''_______________________ transform dw/fw/ww _________________________'''
    if DataTP == 'ww':
        r = 1
    elif DataTP == 'dw':
        r = 1 - D_trans[SampleTP, 'aq']
    elif DataTP == 'fw' or DataTP == 'lw':
        r = D_trans[SampleTP, 'lip']
    else:
        print('Data Type Error: need dw/fw/ww')
        r=0
    
    '''_______________________ check LOD/LOQ ______________________________'''
    IsLOD = False
    try:
        LOD = float(LOD)
        IsLOD = True
    except:
        pass
    IsLOQ = False
    try:
        LOQ = float(LOQ)
        IsLOQ = True
    except:
        pass
    if IsLOD and IsLOQ:
        pass
    elif IsLOD:
        LOQ = LOD/3*10
        IsLOQ = True
    elif IsLOQ:
        LOD = LOQ/10*3
        IsLOD = True
    else:
        pass
        #print('No LOD, LOQ')
    '''_______________________ check Min/Max ______________________________'''
    IsMinMax = False
    try:
        Max = float(Max)
        IsMinMax = True
    except:
        if '<' in Max:
            Max = LOQ
            Min = LOD
            IsMinMax = True
        elif 'nd' in Max or 'ND' in Max:
            Max = LOD
            Min = LOD/3
            IsMinMax = True
        else:
            pass
    try:
        Min = float(Min)
        IsMinMax = True
    except:
        if '<' in Min:
            Min = LOD
            IsMinMax = True
        elif 'nd' in Min or 'ND' in Min:
            Min = LOD/2+LOD/6
            IsMinMax = True
        else:
            pass
    
    '''_______________________ check Mean/SD ______________________________'''
    IsMean = False
    SoloMean = False
    try:
        Mean = float(Mean)
        IsMean = True
    except:
        if '<' in Mean:
            if IsLOD or IsLOQ:
                Min = LOD
                Max = LOQ
                IsMinMax = True
            else:
                print('No LOD/LOQ for Mean subsititution')
        elif 'nd' in Mean or 'ND' in Mean:
            if IsLOD or IsLOQ:
                Mean = LOD/2
                SD = LOD/3
                IsMean = True
        else:
            pass
            #print(Mean,': Mean value error')
    IsSD = False
    try:
        SD = float(SD)
        IsSD = True
    except:
        if IsMean:
            if IsLOD:
                SD = LOD/3
            else:
                SoloMean = True
        else:
            if IsLOD:
                pass
            elif IsMinMax:
                pass
            else:
                try:
                    Mid = float(Mid)
                except:
                    print('Value for conc. missed')
    
    '''_______________________ check Mid vs Mean ______________________________'''
    IsMid = False
    try:
        Mid = float(Mid)
        IsMid = True
    except:
        if '<' in Mid:
            Mid = (LOQ-LOD)/2 + LOD
            IsMid = True
        elif Mid == 'nd' or Mid == 'ND':
            Mid = LOD/3
            IsMid = True
        else:
            pass
        
    if IsMid and IsMean and IsSD:
        if Mid < Mean:
            sigma_a_square = 2*(np.log(Mean) - np.log(Mid))
            sigma_b_square = np.log( 1/2 + np.sqrt(SD**2/Mean**2 + 1/4) )
            if sigma_a_square > sigma_b_square:
                kai_a2b = sigma_a_square/sigma_b_square*(n-1)
            else:
                kai_a2b = sigma_b_square/sigma_a_square*(n-1)
            p095 = stat.chi2.ppf(0.95, n)
            if p095 < kai_a2b:
                Distri = 'LogNormal'
                ind1 = np.log(Mid)
                ind2 = np.exp((np.log(sigma_a_square)+np.log(sigma_b_square))/4)
            else:
                Distri = 'Normal'
                ind1 = Mean
                ind2 = SD
        else:
            Distri = 'Normal'
            ind1 = Mean
            ind2 = SD        
    elif IsMean and IsSD:
        Distri = 'Normal'
        ind1 = Mean
        ind2 = SD
    elif IsMid and IsSD:
        Distri = 'Normal'
        ind1 = Mid
        ind2 = SD
    elif SoloMean:
        Distri = 'Mono'
        ind1 = Mean
        ind2 = np.nan
    elif IsMid or IsMean and not IsSD:
        Distri = 'Mono'
        if IsMid:
            ind1 = Mid
        elif IsMean:
            ind1 = Mean
        ind2 = np.nan
    elif IsMinMax:
        Distri = 'Uniform'
        ind1 = Min
        ind2 = Max
    else:
        print( 'UnknonwDistributionError' )
    '''_________________________reweight by LOD/LOQ________________________________'''
    if IsLOD or IsLOQ:
        ndweight = math.ceil(3*(0.02/LOD))
    elif Distri == 'Uniform':
        ndweight = 3
    else:
        ndweight = 1
    return r, ind1, ind2, Distri, ndweight*n

def random_choice(Distri, ind1, ind2, n):
    if Distri == 'Uniform':
        L = []
        for i in range(n):
            a = 0
            while a <= 0:
                a = random.uniform(ind1, ind2)
            L.append(a)
        return L
    elif Distri == 'Mono':
        L = []
        for i in range(n):
            L.append(ind1)
        return L
    elif Distri == 'Normal':
        L = []
        for i in range(n):
            a = 0
            while a <= 0:
                a = random.normalvariate(ind1, ind2)
            L.append(a)
        return L
    elif Distri == 'LogNormal':
        L = []
        for i in range(n):
            L.append(random.lognormvariate(ind1, ind2))
        return L

def MontCarloStats(period,D_pollutant_distribution, N_samples=1000, save_period = False):
    D_poll_distri = dict()
    D_poll_totalN = dict()
    for year, PollABB, SampleTP, SampleName in D_pollutant_distribution:
        if year <= period[1] and year >= period[0]:
            for analysis_result in D_pollutant_distribution[year, PollABB, SampleTP, SampleName]:
                try:
                    D_poll_distri[ year, PollABB, SampleTP ].append(analysis_result)
                    D_poll_totalN[ year, PollABB, SampleTP ] = D_poll_totalN[ year, PollABB, SampleTP ] + analysis_result[-2]
                except KeyError:
                    D_poll_distri[ year, PollABB, SampleTP ] = [analysis_result]
                    D_poll_totalN[ year, PollABB, SampleTP ] = analysis_result[-2]
    D_pool = dict()
    for Sample in D_poll_distri:
        D_pool[Sample] = []
        for analysis_result in D_poll_distri[Sample]:
            Distri, ind1, ind2, N, r = analysis_result
            N_sims_analysis = int(N_samples*N/D_poll_totalN[Sample])
            L = random_choice(Distri, ind1, ind2, N_sims_analysis)
            D_pool[Sample] = D_pool[Sample] + [r*conc for conc in L]
        year, PollABB, SampleTP = Sample
        if save_period:
            try:
                D_pool[tuple(period), PollABB, SampleTP] = D_pool[tuple(period), PollABB, SampleTP] + D_pool[Sample]
            except KeyError:
                D_pool[tuple(period), PollABB, SampleTP] = D_pool[Sample]
    return D_pool

def save_D_pool(D_pool, path, file):
    DF_ = {'year':[],'Chemical':[],'FoodType':[],'ave':[],'gmean':[],'sd':[],'med':[],'975':[],'025':[]}
    D_merged_year = {}
    for sample in D_pool:
        year, PollABB, SampleTP = sample
        a = np.array(D_pool[sample])
        DF_['year'].append(year)
        DF_['Chemical'].append(PollABB)
        DF_['FoodType'].append(SampleTP)
        DF_['ave'].append( np.mean(a) )
        DF_['gmean'].append(gmean(a))
        DF_['sd'].append( np.std(a) )
        DF_['med'].append( np.percentile(a,[50])[0])
        DF_['975'].append(np.percentile(a,[97])[0])
        DF_['025'].append(np.percentile(a,[3])[0])
    
    DF = pd.DataFrame(DF_)
    DF.to_excel(path+file)

def corr_by_year_old(D_pool, PollABB, SampleTP, N_size = 1000):
    if type(PollABB) ==  str:
        arr_years = []
        arr_concs = []
        if type(SampleTP) ==  str or type(SampleTP) ==  tuple:
            for sample in D_pool:
                if PollABB in sample and SampleTP in sample:
                    year = sample[0]
                    N = len(D_pool[sample])
                    arr_years = arr_years + [year for i in range(N)]
                    arr_concs = arr_concs + D_pool[sample]
        else:
            for sample in D_pool:
                for sampletp in SampleTP:
                    if PollABB in sample and sampletp in sample:
                        year = sample[0]
                        N = len(D_pool[sample])
                        arr_years = arr_years + [year for i in range(N)]
                        arr_concs = arr_concs + D_pool[sample]
    elif type(PollABB) ==  list:
        L_years = list(set([ sample[0] for sample in D_pool ]))
        L_years.sort()
        arr_years = []
        for year in L_years:
            arr_years = arr_years + [year for i in range(N_size)]
        arr_concs = np.zeros_like(arr_years)
        if type(SampleTP) ==  str or type(SampleTP) ==  tuple:
            for Poll in PollABB:
                poll_arr_concs = []
                for year in L_years:
                    try:
                        poll_arr_concs = poll_arr_concs + list( np.random.choice(D_pool[year,Poll,SampleTP], N_size) )
                    except KeyError:
                        poll_arr_concs = poll_arr_concs + list( np.zeros(N_size) )
                arr_concs = arr_concs + np.array(poll_arr_concs)
        else:
            for Poll in PollABB:
                poll_arr_concs = []
                for year in L_years:
                    med_pool = []
                    for sampletp in SampleTP:
                        try:
                            med_pool = med_pool + list( D_pool[year,Poll,sampletp] )
                        except KeyError:
                            pass
                    try:
                        poll_arr_concs = poll_arr_concs + list( np.random.choice(med_pool,N_size) )
                    except:
                        print(Poll, year, 'has no aquatic food')
                        poll_arr_concs = poll_arr_concs + list( np.zeros(N_size) )
                arr_concs = arr_concs + np.array(poll_arr_concs)
        arr_years = np.array(arr_years)
        arr_years = arr_years[arr_concs != 0]
        arr_concs = arr_concs[arr_concs != 0]
    
    L_years = list(set(arr_years))
    if len(L_years)>5:
        plt.scatter(arr_years, np.log10(arr_concs), alpha=0.1)
        plt.title(PollABB)
        
        L_logconc = [np.mean(np.log10(arr_concs[arr_years==y])) for y in L_years]
        r, p = stat.pearsonr(L_years, L_logconc)
        plt.scatter(L_years, L_logconc)
        plt.show()
    else:
        r,p = np.nan, np.nan
    return arr_years, np.log10(arr_concs), r, p

def corr_by_year(D_pool, PollABB, SampleTP, N_size=1000):
    arr_years = []
    arr_concs = []

    if isinstance(PollABB, str):
        if isinstance(SampleTP, (str, tuple)):
            for sample in D_pool:
                # Better to check specific indices to avoid partial string matches
                if sample[1] == PollABB and sample[2] == SampleTP:
                    year = sample[0]
                    N = len(D_pool[sample])
                    arr_years.extend([year] * N)
                    arr_concs.extend(D_pool[sample])
        else:
            for sample in D_pool:
                for stp in SampleTP:
                    if sample[1] == PollABB and sample[2] == stp:
                        year = sample[0]
                        N = len(D_pool[sample])
                        arr_years.extend([year] * N)
                        arr_concs.extend(D_pool[sample])
                        
    elif isinstance(PollABB, list):
        L_years = sorted(list(set([sample[0] for sample in D_pool])))
        # Initialize as float to avoid truncation
        arr_concs = np.zeros(len(L_years) * N_size, dtype=float) 
        
        # Populate arr_years correctly
        for year in L_years:
            arr_years.extend([year] * N_size)
        
        temp_concs = np.zeros_like(arr_concs)
        
        for Poll in PollABB:
            poll_arr_concs = []
            for year in L_years:
                med_pool = []
                # Handle single or multiple SampleTP
                targets = [SampleTP] if isinstance(SampleTP, (str, tuple)) else SampleTP
                for stp in targets:
                    try:
                        med_pool.extend(D_pool[year, Poll, stp])
                    except KeyError:
                        pass
                
                if med_pool:
                    poll_arr_concs.extend(np.random.choice(med_pool, N_size))
                else:
                    poll_arr_concs.extend([0.0] * N_size)
            
            temp_concs += np.array(poll_arr_concs)
        arr_concs = temp_concs

    # Data Cleaning
    arr_years = np.array(arr_years)
    arr_concs = np.array(arr_concs)
    
    mask = arr_concs > 0 # Use mask to filter both arrays
    arr_years = arr_years[mask]
    arr_concs = arr_concs[mask]
    
    unique_years = sorted(list(set(arr_years)))
    
    if len(unique_years) > 5:
        log_concs = np.log10(arr_concs)
        
        # FIXED: Use int16 or standard int to avoid overflow
        arr_years = arr_years.astype(int) 
        
        L_logconc = [np.mean(log_concs[arr_years == y]) for y in unique_years]
        r, p = stat.pearsonr(unique_years, L_logconc)
        
        if len(unique_years)>12:
            plt.scatter(arr_years, log_concs, alpha=0.1)
            #plt.title(str(PollABB))
            plt.scatter(unique_years, L_logconc, color='red')
            plt.show()
            #print(f"R: {r:.4f}, p-value: {p:.4f}")
    else:
        r, p = np.nan, np.nan
        
    return arr_years, np.log10(arr_concs), r, p

def fit_exp(year, conc):
    from scipy.optimize import curve_fit
    def linear(x, a, b):
        return a*x + b
    param, pcov = curve_fit(linear, year, conc)
    a,b = param
    years = np.array(year)
    x = np.arange(np.min(years), np.max(years)+1, 1)
    #plt.plot(x, linear(x, a, b))
    #print(a, b, pcov[0,0], pcov[1,1])
    return a, b, pcov[0,0], pcov[1,1]

def update_dict(D_save,period,PollABB,SampleTP,r,p,a,b,var_a,var_b ):
    D_save['period'].append(period)
    D_save['chem'].append(PollABB)
    D_save['sample'].append(SampleTP)
    D_save['corr_r'].append(r)
    D_save['corr_p'].append(p)
    D_save['a'].append(a)
    D_save['b'].append(b)
    D_save['var_a'].append(var_a)
    D_save['var_b'].append(var_b)
    D_save['sign'].append(p<0.002)
    D_save['changed'].append(int(np.abs(r)>0.05))
    return D_save
    
def update_piecewise_dict(D_save,period,PollABB,SampleTP,a,b, r2, fix_year='2000-2009-2015-2023'):
    D_save['period'].append(period)
    D_save['chem'].append(PollABB)
    D_save['sample'].append(SampleTP)
    D_save['a'].append(a)
    D_save['b'].append(b)
    D_save['r2'].append(r2)
    D_save['fix_year'].append(fix_year)
    return D_save

def main_aquatic_food_conc_by_time(MajorCatPoll, concpath, savepath):
    N_samples = 1000; poll_filename = MajorCatPoll + ' in food (1113).csv' #1113
    for i in range(8):
        year1, year2 = [1999+3*i, 2002+3*i]
        poolfile = f'PFAS concs by year summary ({year1}-{year2-1}).xlsx'
        L_period = []
        L_chem = ['PFHxS','PFOS','PFOA','PFDA','PFDoDA','PFNA','PFUnDA']
        #L_sampleTP = ['Crustacean','Mollusc',tuple(['FreshWater','']),('Marine','Pelagic'),('Marine','Demersal')]
        #L_sampleTP = ['Pork', 'Beef', 'Meat, Other', 'Mutton', 'Egg', 'Poultry']
        period = np.arange(year1,year2,1)
        D_pollutant_distribution, D_summary_pollutants, L_sites, L_pollutant = read_PollInFood(concpath, poll_filename)
        D_pool = MontCarloStats([period[0], period[-1]], D_pollutant_distribution, N_samples=N_samples, save_period=True)
        D_pool_merge = {}
        def merge_L_sample(L_sampleTP, nameTP,s_times = set()):
            for year, poll, sampleTP in D_pool:
                s_times.add(year)    
                if poll in L_chem:
                    if sampleTP in L_sampleTP:
                        try:
                            D_pool_merge[year, poll, nameTP] = D_pool_merge[year, poll, nameTP] + D_pool[year, poll, sampleTP]
                        except KeyError:
                            D_pool_merge[year, poll, nameTP] = D_pool[year, poll, sampleTP]
                    else:
                        pass
                        #print('no',sampleTP)
            for year in s_times:
                D_pool_merge[year, 'Sum7PFAS', nameTP] = np.zeros(N_samples)
                for poll in L_chem:
                    try:
                        D_pool_merge[year, 'Sum7PFAS', nameTP] = D_pool_merge[year, 'Sum7PFAS', nameTP] + np.random.choice(D_pool_merge[year, poll, nameTP], size=N_samples)
                    except KeyError:
                        print(f'"{year}" has no "{poll}" record in "{nameTP}"')
                #print(year,nameTP, np.mean(D_pool_merge[year, 'Sum7PFAS', nameTP]))
            return
        
        merge_L_sample(['Crustacean', 'Mollusc'], 'Other Marine food')
        #merge_L_sample(['Mollusc'], 'Mollusc')
        merge_L_sample([('Marine','Pelagic'),('Marine','Demersal'),('Marine','Mix')], 'Marine Fish')
        merge_L_sample([tuple(['FreshWater',''])], 'Freshwater Fish')
        #merge_L_sample(['Crustacean','Mollusc',tuple(['FreshWater','']),('Marine','Pelagic'),('Marine','Demersal'),('Marine','Mix')], 'All Aquatics')
        #merge_L_sample(['Pork', 'Beef', 'Mutton', 'Poultry'], 'All Terrestrial Animal')
        #merge_L_sample(['Egg'], 'Egg')
    
        def compare_whole_period(D_pool_merge, chem='Sum7PFAS'):
            s_sample = set()
            s_year = set()
            for year, poll, sample in D_pool_merge:
                s_sample.add(sample)
                if type(year) == tuple:
                    s_year.add(year)
            s_sample = list(s_sample)
            n = len(s_sample)
            t_arr, p_arr = np.zeros([n,n]), np.ones([n,n])
            period = list(s_year)[0]
            for i in range(n):
                for j in range(n-i):
                    a = D_pool_merge[period, chem, s_sample[i]]
                    b = D_pool_merge[period, chem, s_sample[i+j]]
                    t_arr[i, i+j], p_arr[i, i+j] = ttest_ind(a, b)
            DF_t = pd.DataFrame(t_arr)
            DF_p = pd.DataFrame(p_arr)
            DF_t.columns = s_sample
            DF_p.columns = s_sample
            DF_t.index = s_sample
            DF_p.index = s_sample
            DF_p.to_excel(savepath + 't test_p' + poolfile)
            DF_t.to_excel(savepath + 't test_t' + poolfile)
            return
        compare_whole_period(D_pool_merge)
        D_save = {'year':[], 'chem':[], 'sample':[],'gmean':[], 'g-std':[], 'mean':[], 'std':[], '5%':[], '25%':[], '50%':[], '75%':[], '95%':[]}
        def stats_values(D_pool_merge):
            
            for year, poll, sample in D_pool_merge:
                D_save['year'].append(year)
                D_save['chem'].append(poll)
                D_save['sample'].append(sample)
                arr = D_pool_merge[year, poll, sample]
                D_save['mean'].append(np.mean(arr))
                D_save['std'].append(np.std(arr))
                D_save['gmean'].append(np.exp(np.mean(np.log(arr))))
                D_save['g-std'].append(np.std(np.log(arr)))
                _5, _25, _50, _75, _95 = np.percentile(arr, q=[5,25,50,75,95])
                D_save['5%'].append(_5)
                D_save['25%'].append(_25)
                D_save['50%'].append(_50)
                D_save['75%'].append(_75)
                D_save['95%'].append(_95)
        stats_values(D_pool_merge)
        df_save = pd.DataFrame(D_save)
        df_save.to_excel(savepath + poolfile)
    return

def main_corr_analysis(MajorCatPoll, concpath, savepath):
    N_samples = 1000; poll_filename = MajorCatPoll + ' in food (1113 NA EU).csv' #1113
    poolfile = 'PFAS concs by year in Terr.xlsx'
    D_save = {'period':[], 'chem':[], 'sample':[], 'corr_r':[], 'corr_p':[],'a':[], 'b':[], 'var_a':[], 'var_b':[], 'sign':[], 'changed':[]}
    L_period = []
    for i in range(2010, 2024-5, 1):
        for j in range(i+5, 2024, 1):
            L_period.append([i,j])
    #L_chem = ['PFHxS','PFOS','PFOA','PFDA','PFDoDA','PFNA','PFUnDA']
    L_chem = ['PFOA']
    L_sampleTP = ['Crustacean','Mollusc',tuple(['FreshWater','']),('Marine','Pelagic'),('Marine','Demersal'),('Marine','Mix')]
    #L_sampleTP = ['Pork', 'Beef', 'Meat, Other', 'Mutton', 'Egg', 'Poultry']
    L_sampleTP = [('Marine','Pelagic')]
    for period in L_period:
        print(period)
        D_pollutant_distribution, D_summary_pollutants, L_sites, L_pollutant = read_PollInFood(concpath, poll_filename)
        D_pool = MontCarloStats(period, D_pollutant_distribution, N_samples=N_samples)
        save_D_pool(D_pool, savepath, poolfile)
        for PollABB in L_chem:
            for SampleTP in L_sampleTP:
                try:
                    year, lgconc, r, p = corr_by_year(D_pool, PollABB, SampleTP, N_samples)
                    a, b, var_a, var_b = fit_exp(year, lgconc)
                    D_save = update_dict(D_save,period,PollABB,SampleTP,r,p,a,b,var_a,var_b )
                except ValueError:
                    pass
            #plt.show()
            #year, lgconc, r, p = corr_by_year(D_pool, PollABB, L_sampleTP, N_samples)
            #a, b, var_a, var_b = fit_exp(year, lgconc)
            #D_save = update_dict(D_save,period,PollABB,'Terr Foods',r,p,a,b,var_a,var_b )
        '''
        year, lgconc, r, p = corr_by_year(D_pool, L_chem, L_sampleTP, N_samples)
        a, b, var_a, var_b = fit_exp(year, lgconc)
        D_save = update_dict(D_save,period,L_chem,'Terr Foods',r,p,a,b,var_a,var_b )
        '''    
    df = pd.DataFrame(D_save)
    #df.to_excel(savepath+'time trend analysis Terr foods 260309 (geomeans loged EA).xlsx')
    #plt.show()
    
    return

def fit_piecewise(x, y, title, n):
    model = pwlf.PiecewiseLinFit(x, y)
    str_year = None
    if np.min(x) < 2003:
        fix_year = [np.min(x), 2003, 2016, np.max(x)]
        #model.fit_with_breaks(fix_year)
        fix_year = model.fit(n)
        # Plot
        x_pred = np.linspace(np.min(x),np.max(x))
        y_pred = model.predict(x_pred)
        plt.scatter(x+np.random.normal(0,0.1,len(x)), y, s=3, label="Data", alpha=0.05)
        plt.plot(x_pred, y_pred, color="red", label="Piecewise regression")
        plt.vlines(fix_year[1:-1], ymin=min(y), ymax=max(y),
                   color="green", linestyles="dashed")
        plt.legend()
        plt.title(title)
        plt.show()
        
        # Predict
        ys = []
        ts = []
        #print(x)
        for yr in np.arange(np.min(x),np.max(x)+1,1):
            #print(yr)
            if len(y[x == yr]) > 0:
                ys.append(np.average(y[x == yr] ))
                ts.append(yr)
        ts = np.array(ts)    
        ys_pred = model.predict(ts)
        #print(ys_pred)
        #print(ys)
        #print(ts)
        #str_year = f'{fix_year[0]}-{fix_year[1]}-{fix_year[2]}-{fix_year[3]}'
        return str_year, model.slopes, model.intercepts, r2_score(ys, ys_pred), mean_absolute_error(ys, ys_pred)
    else:
        fix_year = [np.min(x), 2016, np.max(x)]
        #model.fit_with_breaks(fix_year)
        fix_year = model.fit(1)
        # Plot
        x_pred = np.linspace(np.min(x),np.max(x))
        y_pred = model.predict(x_pred)
        plt.scatter(x+np.random.normal(0,0.1,len(x)), y, s=3, label="Data", alpha=0.1)
        plt.plot(x_pred, y_pred, color="red", label="Piecewise regression")
        plt.vlines(fix_year[1:-1], ymin=min(y), ymax=max(y),
                   color="green", linestyles="dashed")
        plt.legend()
        plt.title(title)
        plt.show()
        
        # Predict
        ys = []
        ts = []
        #print(x)
        for yr in np.arange(np.min(x),np.max(x)+1,1):
            #print(yr)
            if len(y[x == yr]) > 0:
                ys.append(np.average(y[x == yr] ))
                ts.append(yr)
        ts = np.array(ts)    
        ys_pred = model.predict(ts)
        #print(ys_pred)
        #print(ys)
        #print(ts)
        #str_year = f'{fix_year[0]}-{fix_year[1]}-{fix_year[2]}-{fix_year[3]}'
        return str_year, model.slopes, model.intercepts, r2_score(ys, ys_pred), mean_absolute_error(ys, ys_pred)
    

def main_aqua(MajorCatPoll, concpath, savepath, n=3):
    N_samples = 1000; poll_filename = MajorCatPoll + ' in food (1113).csv'
    #L_chem = ['PFOS','PFOA','PFHxS','PFDA','PFDoDA','PFNA','PFUnDA']
    L_chem = ['PFOA']
    L_sampleTP = ['Crustacean','Mollusc',tuple(['FreshWater','']),('Marine','Pelagic'),('Marine','Demersal')]
    #L_sampleTP = [('Marine','Pelagic')] #,('Marine','Demersal')
    D_pollutant_distribution, D_summary_pollutants, L_sites, L_pollutant = read_PollInFood(concpath, poll_filename)
    D_pool = MontCarloStats([2000,2023], D_pollutant_distribution, N_samples=N_samples)
    
    #L_sub_period = [[2000,2008], [2009,2015], [2016,2025]]
    D_save = {'period':[], 'chem':[], 'sample':[],'a':[], 'b':[], 'r2':[], 'fix_year':[]}
    for PollABB in L_chem:
        
        for SampleTP in L_sampleTP:
            try:
                title = PollABB + ' in ' + SampleTP
            except:
                L = list(SampleTP)
                title = PollABB + ' in ' + L[0] + L[1]
            year, lgconc, r, p = corr_by_year(D_pool, PollABB, SampleTP)
            str_year, slopes3, inters3, r2, mae = fit_piecewise(year, lgconc, title, n)
            print(f'title:{title}, str_year:{str_year}, r2:{r2}, mae:{mae}')
            for i in range(len(slopes3)):
                period = [str_year.split('-')[i], str_year.split('-')[i+1]]
                a = slopes3[i]
                b = inters3[i]
                #update_piecewise_dict(D_save,period,PollABB,SampleTP,a,b,r2, str_year)
        
        year, lgconc, r, p = corr_by_year(D_pool, PollABB, L_sampleTP)
        str_year, slopes3, inters3, r2, mae = fit_piecewise(year, lgconc, PollABB+' in  Aquatic', n)
        print(f'title:{PollABB} in Total Aquatic, str_year:{str_year}, r2:{r2}, mae:{mae}')
        for i in range(len(slopes3)):
            period = [str_year.split('-')[i], str_year.split('-')[i+1]]
            a = slopes3[i]
            b = inters3[i]
            #update_piecewise_dict(D_save,period,PollABB,'Blue Foods',a,b,r2, str_year)L_sampleTP
        
    year, lgconc, r, p = corr_by_year(D_pool, L_chem, L_sampleTP)
    print(r, p)
    #str_year, slopes3, inters3, r2, mae = fit_piecewise(year, lgconc, 'PFOA in aquatic food', n)
    df = pd.DataFrame(D_save)
    df.to_excel(savepath+'piecewise time trend analysis aquatic foods.xlsx')
    
    return

from scipy.optimize import curve_fit
def fit_piecewise_terri(x, y, poll, title):
    def linear(x,a,b):
        return a*x+b
    #fix_year = [np.min(x), 2009, 2015, np.max(x)]
    #model = pwlf.PiecewiseLinFit(x, y)
    #model.fit_with_breaks(fix_year)
    #fix_year = model.fit(4)
    model = linear
    param, var = curve_fit(linear,x,y)
    a,b = param
    # Predict
    x_pred = np.linspace(min(x), max(x), 50)
    y_pred = model(x_pred, a, b)
    #y_pred = model.predict(x_pred)
    # Plot
    plt.title(poll)
    plt.scatter(x, y, s=10, label="Data", alpha=0.3)
    plt.plot(x_pred, y_pred, color="red", label="linear regression")
    plt.title(title)
    plt.legend()
    plt.show()
    x=np.array(x, dtype=np.float32)
    y_pred = model(x, a, b)
    #y_pred = model.predict(x)
    print(poll, "r2", round( r2_score(y, y_pred), 3) )
    return [a], [b], r2_score(y, y_pred), mean_absolute_error(y, y_pred)

def main_terri(MajorCatPoll, concpath, savepath):
    N_samples = 1000; poll_filename = MajorCatPoll + ' in food (1113).csv'
    L_chem = ['PFHxS','PFOS','PFOA','PFDA','PFDoDA','PFNA','PFUnDA']
    #L_sampleTP = ['Crustacean','Mollusc',tuple(['FreshWater','']),('Marine','Pelagic'),('Marine','Demersal')]
    L_sampleTP = ['Pork', 'Beef', 'Mutton', 'Egg', 'Poultry'] #, 'Meat, Other'
    D_pollutant_distribution, D_summary_pollutants, L_sites, L_pollutant = read_PollInFood(concpath, poll_filename)
    D_pool = MontCarloStats([2000,2025], D_pollutant_distribution, N_samples=N_samples)
    
    L_sub_period = [[2000,2008], [2009,2015], [2016,2025]]
    D_save = {'period':[], 'chem':[], 'sample':[],'a':[], 'b':[], 'r2':[]}
    for PollABB in L_chem:
        for SampleTP in L_sampleTP:
            try:
                title = PollABB + ' in ' + SampleTP
            except:
                L = list(SampleTP)
            year, lgconc, r, p = corr_by_year(D_pool, PollABB, SampleTP)
            slopes3, inters3, r2, mae = fit_piecewise(year, lgconc,title)
            for i in range(3):
                period = L_sub_period[i]
                a = slopes3[i]
                b = inters3[i]
                update_piecewise_dict(D_save,period,PollABB,SampleTP,a,b,r2)
        
        year, lgconc, r, p = corr_by_year(D_pool, PollABB, L_sampleTP)
        slopes3, inters3, r2, mae = fit_piecewise_terri(year, lgconc, PollABB, PollABB+' in  Terrestrial')
        for i in range(3):
            period = L_sub_period[i]
            a = slopes3[i]
            b = inters3[i]
            update_piecewise_dict(D_save,period,PollABB,'Terri Foods',a,b,r2)
    
    #df = pd.DataFrame(D_save)
    #df.to_excel(savepath+'piecewise time trend analysis terri foods 1210.xlsx')
    return



class PiecewiseFunction:
    def __init__(self, breaks, slopes, intercepts):
        """
        breaks: list of breakpoints [x0, x1, x2, ...]
        slopes: list of slopes for each segment
        intercepts: list of intercepts for each segment
        """
        self.breaks = np.array(breaks)
        self.slopes = np.array(slopes)
        self.intercepts = np.array(intercepts)

    def __call__(self, x):
        """
        Makes the object callable: y = f(x)
        Works for scalars, lists, and numpy arrays.
        """
        x = np.asarray(x)
        y = np.zeros_like(x, dtype=float)

        for i in range(len(self.slopes)):
            left = self.breaks[i]
            right = self.breaks[i+1]

            mask = (x >= left) & (x <= right)
            y[mask] = self.slopes[i] * x[mask] + self.intercepts[i]

        # Return scalar if input was scalar
        return y if y.size > 1 else float(y)

def read_piecewise(path,file='piecewise time trend analysis aquatic foods 1210.xlsx'):
    # setup piecewise functions for all aquatic foods to caliberate
    df = pd.read_excel(path+file)
    D_params = {}
    for i in df['index']:
        try:
            D_params[df['sample'][i], df['chem'][i]] = D_params[df['sample'][i], df['chem'][i]] + [df['a'][i], df['b'][i]]
        except KeyError:
            D_params[df['sample'][i], df['chem'][i]] = [df['a'][i], df['b'][i]]
    D_functions = {}
    for item in D_params:
        a1, b1, a2, b2, a3, b3 = D_params[item]
        fix_year = [2000, 2009, 2015, 2025]
        D_functions[item] = PiecewiseFunction(fix_year, [a1,a2,a3], [b1,b2,b3])
    
    return D_functions

def test_hit0():
    D_functions = read_piecewise(savepath)
    for item in D_functions:
        f = D_functions[item]
        x = np.linspace(2000, 2025)
        k = 10**(f(2019)-np.min(f(x)))
        
        if k > 3 or k < -3:
            print(item, k, int(x[ f(x) == np.min(f(x)) ]))
    return

#test_hit0()
savepath = 'G:/projects/BLUE FOOD/simulation for diet HI/time trend analysis/'
concpath = 'G:/projects/BLUE FOOD/simulation for diet HI/input_file/'
#main_aquatic_food_conc_by_time('PFAS', concpath, savepath)
main_corr_analysis("PFAS", concpath, savepath ) #correlation analysis for terrestrial, equatic, EU+US vs Asia pelagic fish
main_aqua('PFAS', concpath, savepath, 3) #time trend with piecewise regression
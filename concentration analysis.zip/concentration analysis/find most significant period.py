# -*- coding: utf-8 -*-
"""
Created on Mon Dec 29 14:21:24 2025

@author: huboy
"""

path = 'G:/projects/BLUE FOOD/simulation for diet HI/time trend analysis/'
file = 'time trend analysis Aquatic foods 260203.xlsx'
savefile = 'most significant periods 260203.xlsx'
import pandas as pd

df = pd.read_excel(path+file, sheet_name='Sheet1')
D_periods = {}
for i in range(len(df['corr_p'])):
    try:
        D_periods[ df['chem'][i], df['sample'][i]]
    except KeyError:
        D_periods[ df['chem'][i], df['sample'][i]] = [df['period'][i], df['corr_r'][i], df['corr_p'][i], df['a'][i], df['b'][i]]

df_save = {"chem":[], "sample":[], "period":[], "corr_r":[], 'p':[], 'a':[], 'b':[] }
for chem, sample in D_periods:
    period, corr_r, p, a, b = D_periods[chem, sample]
    df_save['chem'].append(chem)
    df_save['sample'].append(sample)
    df_save['period'].append(period)
    df_save['corr_r'].append(corr_r)
    df_save['p'].append(p)
    df_save['a'].append(a)
    df_save['b'].append(b)
df_save = pd.DataFrame(df_save)
df_save.to_excel(path+savefile)

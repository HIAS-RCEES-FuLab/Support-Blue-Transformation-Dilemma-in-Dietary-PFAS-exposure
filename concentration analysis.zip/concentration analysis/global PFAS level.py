import pandas as pd
import numpy as np
import os
import glob

# --- CONFIGURATION ---
# UPDATE THIS PATH to your actual local folder containing the country .xlsx files
CONCENTRATION_DATA_DIR = r"G:\projects\BLUE FOOD\simulation for diet HI\input_file\water_conc 0105"

# File names for weights (Assumes these are in the directory where you run the script)
PRODUCTION_DATA_DIR = 'G:/projects/BLUE FOOD/simulation for diet HI/international trade values/international trade values/OCED estimation for 2050/'
FILE_PRODUCTION = PRODUCTION_DATA_DIR + '2030 export and production.xlsx'

DIET_DATA_DIR = 'G:/projects/BLUE FOOD/simulation for diet HI/input_file/'
FILE_DIET = DIET_DATA_DIR + 'FAOSTAT_diet_2050 (high load 250716).csv'
#'FAOSTAT_diet_2020 (baseline).csv'
#
# (high load 250716)(business as usuall 250716)

# Simulation Settings
N_SAMPLES = 100000
TARGET_CONGENERS = ['PFOA', 'PFOS', 'PFNA', 'PFHxS', 'PFDoDA', 'PFDA', 'PFUnDA']
TARGET_CONGENERS = ['PFUnDA']
# Food Name Mapping (FAOSTAT Name -> Excel Column Prefix)
food_mapping = {
    'Freshwater Fish': 'Freshwater Fish',
    'Demersal Fish': 'Demersal Fish',
    'Pelagic Fish': 'Pelagic Fish',
    'Marine Fish, Other': 'Marine Fish, Other',
    'Crustaceans': 'Crustaceans',
    'Molluscs, Other': 'Molluscs, Other',
    'Aquatic Animals, Others': 'Aquatic Animals, Others'
}
aquatic_keys = list(food_mapping.keys())

def run_simulation():
    print("--- Starting Global PFAS Simulation ---")
    
    # 1. Load Weights Data
    try:
        df_prod = pd.read_excel(FILE_PRODUCTION)
        df_diet = pd.read_csv(FILE_DIET)
    except FileNotFoundError as e:
        print(f"Error: Could not find config files ({e}). Make sure export/diet CSVs are accessible.")
        return

    # 2. Prepare Country Probability (P_country) from Production Data
    # Clean numbers and remove zero production
    catig = 'Production quantity 2030'
    df_prod[catig] = pd.to_numeric(df_prod[catig], errors='coerce').fillna(0)
    df_prod = df_prod[df_prod[catig] > 0] #Production
    
    # Align countries: We need countries that exist in Production, Diet, AND have a file in the folder
    # Get list of available .xlsx files in the directory
    #available_files = glob.glob(os.path.join(CONCENTRATION_DATA_DIR, "*.xlsx"))
    # Extract country names from filenames (assuming "Brazil.xlsx" -> "Brazil")
    #available_countries_files = set(os.path.basename(f).replace('.xlsx', '') for f in available_files)
    available_countries_files = set(['Australia','Austria','Belgium','Bulgaria','Canada','Chile','Croatia','Czechia','Denmark','Estonia','Finland','France',
                 'Germany','Greece','Iceland','Ireland','Israel','Italy','Japan','Korea','Latvia','Lithuania','Luxembourg','Netherlands',
                 'New Zealand','Norway','Poland','Portugal','Romania','Slovak Republic','Slovenia','Spain','Sweden','Switzerland',
                 'United Kingdom','United States','India','Indonesia','Argentina','Brazil','China','Colombia','Costa Rica','Hungary',
                 'Mexico','South Africa','Turkiye'])
    available_countries_files = set(['China', 'Canada','United States', 'Germany', 'Norway'])
    # Intersect all three lists
    common_countries = set(df_prod['Country']) & set(df_diet['country']) & available_countries_files
    
    if not common_countries:
        print("CRITICAL ERROR: No countries matched between Production file, Diet file, and the folder path.")
        print(f"Checked folder: {CONCENTRATION_DATA_DIR}")
        return

    print(f"Found {len(common_countries)} valid countries with data files.")
    #print( [ c for c in available_countries_files if c not in common_countries ] )
    # Filter and Normalize Country Weights
    df_prod = df_prod[df_prod['Country'].isin(common_countries)]
    country_weights = df_prod.set_index('Country')[catig]
    P_country = country_weights / country_weights.sum()

    # 3. Assign Sample Counts per Country
    # We draw the countries first to know how many samples we need from each file
    country_draws = np.random.choice(P_country.index, size=N_SAMPLES, p=P_country.values)
    country_counts = pd.Series(country_draws).value_counts()

    # List to store all individual results
    all_results = []

    # 4. Process Each Country Individually
    for country, count in country_counts.items():
        print(f"Processing {country}: {count} samples...")
        
        # A. Load Country Specific Concentration File
        file_path = os.path.join(CONCENTRATION_DATA_DIR, f"{country}.xlsx")
        try:
            df_conc = pd.read_excel(file_path)
        except Exception as e:
            print(f"  -> Error reading {country}.xlsx: {e}. Skipping.")
            continue
        
        # B. Get Diet Weights for this Country
        sub_diet = df_diet[df_diet['country'] == country]
        diet_weights = []
        valid_foods = []
        
        for food in aquatic_keys:
            val = sub_diet.loc[sub_diet['food'] == food, 'value']
            weight = val.values[0] if not val.empty else 0.0
            diet_weights.append(weight)
            valid_foods.append(food)
        
        diet_weights = np.array(diet_weights)
        
        if diet_weights.sum() == 0:
            print(f"  -> No aquatic diet data for {country}. Skipping.")
            continue
            
        diet_probs = diet_weights / diet_weights.sum()

        # C. Select Food Types for these samples
        food_choices = np.random.choice(valid_foods, size=count, p=diet_probs)
        
        # D. Sample Concentrations
        # We collect values for this country's batch
        country_concentrations = np.zeros(count)
        
        for food in valid_foods:
            # Find which samples are this food type
            mask = (food_choices == food)
            n_food = np.sum(mask)
            
            if n_food == 0:
                continue
            
            # Sum congeners
            sum_vals = np.zeros(n_food)
            prefix = food_mapping[food]
            
            for cong in TARGET_CONGENERS:
                col_name = f"{prefix}^{cong}"
                
                # Check if column exists in this country's file
                if col_name in df_conc.columns:
                    # Get valid pool
                    pool = df_conc[col_name].dropna().values
                    if len(pool) > 0:
                        draws = np.random.choice(pool, size=n_food, replace=True)
                        sum_vals += draws
                        
                    # Else treat as 0
                else:
                    # Missing congener treated as 0
                    pass 
            
            country_concentrations[mask] = sum_vals
            
        # Store data
        batch_df = pd.DataFrame({
            'Country': [country] * count,
            'Food_Type': food_choices,
            'Total_PFAS_Concentration': country_concentrations
        })
        all_results.append(batch_df)

    # 5. Aggregate and Save
    if not all_results:
        print("No samples generated.")
        return

    print("Aggregating results...")
    final_df = pd.concat(all_results, ignore_index=True)
    
    # Sort
    final_df = final_df.sort_values(by='Total_PFAS_Concentration', ascending=False)

    # Calculate Statistics
    stats_list = []
    
    # Total Stats
    desc = final_df['Total_PFAS_Concentration'].describe(percentiles=[0.05, 0.25, 0.5, 0.75, 0.95, 0.99])
    stats_list.append(pd.Series(desc, name='Total Aquatic Food'))
    
    # Per Food Stats
    for food in aquatic_keys:
        sub = final_df[final_df['Food_Type'] == food]['Total_PFAS_Concentration']
        if len(sub) > 0:
            s = sub.describe(percentiles=[0.05, 0.25, 0.5, 0.75, 0.95, 0.99])
            s.name = food
            stats_list.append(s)

    stats_df = pd.concat(stats_list, axis=1)

    # Export
    output_filename = PRODUCTION_DATA_DIR + 'World_PFAS_Distribution_Result (production 2030 HR top 5 countries PFUnDA).xlsx'
    with pd.ExcelWriter(output_filename) as writer:
        final_df.to_excel(writer, sheet_name='Sample Data', index=False)
        stats_df.to_excel(writer, sheet_name='Statistics')

    print(f"Done! Results saved to {output_filename}")

if __name__ == "__main__":
    run_simulation()